import java.io.*;
import java.nio.file.*;
import java.util.*;

import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/**
 * Patch bytecode tinh cho "Tinh Van Truyen Thuyet" - Viet hoa.
 *   java -cp asm.jar:asm-tree.jar:. Patch <ban: 240|320|360> <in_dir> <out_dir> <patch_log>
 * in_dir = thu muc goc jar (da repack), chua src/*.class. Chi ghi class co sua; class khac giu nguyen byte.
 * Giu version class, ten/descriptor/access flag; COMPUTE_MAXS; bo StackMap cu (ProGuard -microedition sinh lai).
 * Moi patch phai khop DUNG so lan mong doi, sai -> exit 1.
 */
public class Patch {
    static final String G = "javax/microedition/lcdui/Graphics";
    static final String STR = "Ljava/lang/String;";
    static final String VH = "src/VH";
    static final String GD = "L" + G + ";";
    static PrintWriter log;
    static boolean failed = false;

    /** Cau hinh tung ban: class ve chu, ten field Graphics/gradient/bang mau, tam man hinh, so drawString. */
    static class Cfg {
        String cls, fG, fGrad, fCtab, boot, midlet, loader, menu;
        boolean v360;
        String mModule = "a", mHeight = null;
        String bPlayer = "a", bMidlet = "a", bVol = "a", bInit = "a", loaderName = "a", menuInit = "(Lsrc/b;)V";
        int menuDrop = 8;
        int[][] menuArrays = {{1, 8, 2, 3, 4, 5}, {1, 0, 8, 2, 3, 4, 5}};
        String[][] extraDrawString = new String[0][];   // {lop, so call-site}
        /** chinh hang so bo cuc: {lop, method, desc, cu, moi, so lan} */
        String[][] consts = new String[0][];
        int cx, drawStrings;
        String mDrawG, mDrawC, mLines, mLinesTW, mLinesFade, mWidth, mWidthRaw, mTw, mWrap;
    }

    static Cfg cfg(String v) {
        Cfg c = new Cfg();
        if (v.equals("240") || v.equals("320")) {
            c.cls = "src/b"; c.fG = "a"; c.fGrad = "g"; c.fCtab = "a";
            c.cx = v.equals("240") ? 120 : 160;
            c.drawStrings = 11;
            c.boot = "src/q"; c.midlet = "src/GameMidlet"; c.loader = "src/m"; c.menu = "src/o";
            // HUD quai: ten quai (dich dai hon) len hang tren (y 299 -> 285) de khong de chu "Lv"
            // thoai: ten nguoi noi can giua quanh x=35 (dai -> tran trai man hinh) -> can trai x=4 (anchor 33 -> 36)
            c.consts = v.equals("240") ? new String[][]{{"src/v", "a", "(Lsrc/e;Z)V", "299", "285", "1"},
                                                         {"src/v", "Q", "()V", "35,258,33", "4,258,36", "1"}}
                    : new String[][]{{"src/v", "a", "(Lsrc/e;Z)V", "219", "205", "1"},
                                     {"src/v", "Q", "()V", "35,178,33", "4,178,36", "1"},
                                     // man ngang: loi dan (v.b(String,int)) ngat dong 220 -> 300 px, it phai lat trang
                                     {"src/v", "b", "(Ljava/lang/String;I)V", "220", "300", "2"}};
            c.mDrawG = c.mDrawC = c.mLines = c.mLinesTW = c.mWidth = c.mWrap = "a";
            c.mLinesFade = c.mTw = "b";
            c.mWidthRaw = "c";
            return c;
        }
        if (v.equals("360")) {
            c.v360 = true;
            c.cls = "src/GameCanvas"; c.fG = "g"; c.fGrad = "colordata"; c.fCtab = "colorlist";
            c.drawStrings = 14;
            c.extraDrawString = new String[][]{{"src/MapManager", "1"}};
            c.mDrawG = c.mDrawC = "drawZkString";
            c.mLines = "drawZkStringArry"; c.mLinesTW = "drawZkStringArry1"; c.mLinesFade = "drawZkStringArry2";
            c.mWidth = "getStringWidth"; c.mWidthRaw = "stringLength"; c.mTw = "getStringLength"; c.mWrap = "formatzkword";
            c.mModule = "drawImage"; c.mHeight = "stringHeight";
            c.boot = "src/SplashCanvas"; c.midlet = "src/GameMidlet";
            c.bPlayer = "play"; c.bMidlet = "theMidlet"; c.bVol = "soundEffect"; c.bInit = "init";
            c.loader = "src/Util"; c.loaderName = "createImage";
            c.menu = "src/GameMenu"; c.menuInit = "(Lsrc/GameCanvas;)V"; c.menuDrop = 14;
            c.menuArrays = new int[][]{{6, 14, 8, 9, 10, 11}, {6, 7, 14, 8, 9, 10, 11}};
            return c;
        }
        throw new IllegalArgumentException("ban chua ho tro: " + v);
    }

    public static void main(String[] a) throws Exception {
        Cfg c = cfg(a[0]);
        Path in = Paths.get(a[1]), out = Paths.get(a[2]);
        log = new PrintWriter(new FileWriter(a[3]));
        log.println("ban " + a[0] + " class " + c.cls);
        write(in, out, c.cls, 1, c);
        write(in, out, c.boot, 2, c);
        write(in, out, c.loader, 3, c);
        write(in, out, c.menu, 4, c);
        for (String[] k : c.extraDrawString) {
            ClassNode cn = new ClassNode();
            new ClassReader(Files.readAllBytes(in.resolve(k[0] + ".class"))).accept(cn, 0);
            int n = redirectCalls(cn, G, "drawString", "(" + STR + "III)V", "drawString", "(" + GD + STR + "III)V");
            expect(k[0] + " Graphics.drawString -> VH.drawString", n, Integer.parseInt(k[1]));
            stripStackMap(cn);
            ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
            cn.accept(cw);
            Path o = out.resolve(k[0] + ".class");
            Files.createDirectories(o.getParent());
            Files.write(o, cw.toByteArray());
        }
        for (String[] k : c.consts) {
            Path f = out.resolve(k[0] + ".class");
            if (!Files.exists(f)) f = in.resolve(k[0] + ".class");
            ClassNode cn = new ClassNode();
            new ClassReader(Files.readAllBytes(f)).accept(cn, 0);
            MethodNode m = method(cn, k[1], k[2]);
            int n = 0;
            if (m != null) {
                String[] olds = k[3].split(","), news = k[4].split(",");
                for (AbstractInsnNode x = m.instructions.getFirst(); x != null; x = x.getNext()) {
                    AbstractInsnNode y = x; boolean ok = true;
                    List<IntInsnNode> hit = new ArrayList<>();
                    for (String o : olds) {
                        if (y == null || !(y instanceof IntInsnNode) || pushVal(y) != Integer.parseInt(o)) { ok = false; break; }
                        hit.add((IntInsnNode) y); y = y.getNext();
                    }
                    if (!ok) continue;
                    for (int j = 0; j < hit.size(); j++) hit.get(j).operand = Integer.parseInt(news[j]);
                    n++;
                }
            }
            expect("hang so " + k[0] + "." + k[1] + k[2] + " " + k[3] + "->" + k[4], n, Integer.parseInt(k[5]));
            if (m != null && k[1].equals("Q") && k[0].equals("src/v")) {
                // ten nguoi noi: b.a(String,x,y,anchor,mau) -> b.a(String,x,y,anchor,mau,mau_vien) (ham vien 4 huong co san), vien trang
                int q = 0;
                for (AbstractInsnNode x = m.instructions.getFirst(); x != null; x = x.getNext()) {
                    if (x instanceof IntInsnNode && pushVal(x) == 4) {
                        AbstractInsnNode y1 = x.getNext(), an = y1 == null ? null : y1.getNext(), col = an == null ? null : an.getNext(), inv = col == null ? null : col.getNext();
                        if (an != null && pushVal(an) == 36 && col != null && col.getOpcode() == Opcodes.ICONST_0 && inv instanceof MethodInsnNode
                                && ((MethodInsnNode) inv).owner.equals("src/b") && ((MethodInsnNode) inv).desc.equals("(" + STR + "IIII)V")) {
                            m.instructions.insert(col, new LdcInsnNode(0xFFFFFF));
                            ((MethodInsnNode) inv).desc = "(" + STR + "IIIII)V";
                            q++;
                        }
                    }
                }
                expect("ten nguoi noi -> chu vien", q, 1);
            }
            stripStackMap(cn);
            ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
            cn.accept(cw);
            Path o = out.resolve(k[0] + ".class");
            Files.createDirectories(o.getParent());
            Files.write(o, cw.toByteArray());
        }
        log.close();
        if (failed) {
            System.err.println("PATCH FAILED - xem log");
            System.exit(1);
        }
        System.out.println("PATCH OK");
    }

    static void write(Path in, Path out, String cls, int kind, Cfg c) throws IOException {
        ClassNode cn = new ClassNode();
        new ClassReader(Files.readAllBytes(in.resolve(cls + ".class"))).accept(cn, 0);
        if (kind == 1) patchText(cn, c); else if (kind == 2) patchBoot(cn, c); else if (kind == 3) patchLoader(cn, c); else patchMenu(cn, c);
        stripStackMap(cn);
        ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        cn.accept(cw);
        Path o = out.resolve(cls + ".class");
        Files.createDirectories(o.getParent());
        Files.write(o, cw.toByteArray());
    }

    /**
     * Khoi dong NAMP: splash cu (logo nhom upload, hoi am thanh, logo nha phat hanh) -> logo NAMP 2 giay.
     * run(): VH.boot(this, this.player); <am luong static int> = 4 (= chon "Co"); this.midlet.startGame(1)
     * paint(G): VH.bootPaint(g, this)     a()V (nap anh splash cu): rong
     */
    static void patchBoot(ClassNode cn, Cfg c) {
        String PL = "Ljavax/microedition/media/Player;", CV = "Ljavax/microedition/lcdui/Canvas;";
        expect("field Player", findField(cn, c.bPlayer, PL) == null ? 0 : 1, 1);
        expect("field midlet", findField(cn, c.bMidlet, "L" + c.midlet + ";") == null ? 0 : 1, 1);
        FieldNode vol = findField(cn, c.bVol, "I");
        expect("static int am luong", vol != null && (vol.access & Opcodes.ACC_STATIC) != 0 ? 1 : 0, 1);
        MethodNode run = method(cn, "run", "()V"), paint = method(cn, "paint", "(" + GD + ")V"), img = method(cn, c.bInit, "()V");
        expect("q.run/paint/a()", (run != null ? 1 : 0) + (paint != null ? 1 : 0) + (img != null ? 1 : 0), 3);
        if (run == null || paint == null || img == null) return;
        InsnList L = new InsnList();
        L.add(new VarInsnNode(Opcodes.ALOAD, 0));
        L.add(new VarInsnNode(Opcodes.ALOAD, 0));
        L.add(new FieldInsnNode(Opcodes.GETFIELD, cn.name, c.bPlayer, PL));
        L.add(new MethodInsnNode(Opcodes.INVOKESTATIC, VH, "boot", "(" + CV + PL + ")V", false));
        L.add(new InsnNode(Opcodes.ICONST_4));
        L.add(new FieldInsnNode(Opcodes.PUTSTATIC, cn.name, c.bVol, "I"));
        L.add(new VarInsnNode(Opcodes.ALOAD, 0));
        L.add(new FieldInsnNode(Opcodes.GETFIELD, cn.name, c.bMidlet, "L" + c.midlet + ";"));
        L.add(new InsnNode(Opcodes.ICONST_1));
        L.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, c.midlet, "startGame", "(B)V", false));
        L.add(new InsnNode(Opcodes.RETURN));
        setBody(run, L);
        L = new InsnList();
        L.add(new VarInsnNode(Opcodes.ALOAD, 1));
        L.add(new VarInsnNode(Opcodes.ALOAD, 0));
        L.add(new MethodInsnNode(Opcodes.INVOKESTATIC, VH, "bootPaint", "(" + GD + CV + ")V", false));
        L.add(new InsnNode(Opcodes.RETURN));
        setBody(paint, L);
        L = new InsnList();
        L.add(new InsnNode(Opcodes.RETURN));
        setBody(img, L);
        log.println("BODY " + cn.name + ".run/paint/a() -> logo NAMP, am thanh bat (4)");
    }

    /** m.a(String)Image (nap anh): truoc moi areturn goi VH.reg(anh, duong_dan) de VH nhan ra atlas co o chu. */
    static void patchLoader(ClassNode cn, Cfg c) {
        String IMG = "Ljavax/microedition/lcdui/Image;";
        MethodNode m = method(cn, c.loaderName, "(" + STR + ")" + IMG);
        expect("loader " + cn.name + "." + c.loaderName + "(String)Image", m == null ? 0 : 1, 1);
        if (m == null) return;
        if ((m.access & Opcodes.ACC_STATIC) == 0) throw new IllegalStateException("loader khong static");
        int k = 0;
        for (AbstractInsnNode x = m.instructions.getFirst(); x != null; x = x.getNext()) {
            if (x.getOpcode() == Opcodes.ARETURN) {
                InsnList L = new InsnList();
                L.add(new InsnNode(Opcodes.DUP));
                L.add(new VarInsnNode(Opcodes.ALOAD, 0));
                L.add(new MethodInsnNode(Opcodes.INVOKESTATIC, VH, "reg", "(" + IMG + STR + ")V", false));
                m.instructions.insertBefore(x, L);
                k++;
            }
        }
        expect("loader areturn -> VH.reg", k, 2);
    }

    /** Menu chinh: bo muc 8 ("Them game" = mo web quang cao) khoi 2 mang byte liet ke muc menu trong o.<init>. */
    static void patchMenu(ClassNode cn, Cfg c) {
        MethodNode m = method(cn, "<init>", c.menuInit);
        expect("menu " + cn.name + ".<init>", m == null ? 0 : 1, 1);
        if (m == null) return;
        int k = 0;
        for (int[] arr : c.menuArrays) k += dropByte(m, arr, c.menuDrop);
        expect("menu bo muc " + c.menuDrop, k, c.menuArrays.length);
    }

    static int pushVal(AbstractInsnNode x) {
        int op = x.getOpcode();
        if (op >= Opcodes.ICONST_M1 && op <= Opcodes.ICONST_5) return op - Opcodes.ICONST_0;
        if (op == Opcodes.BIPUSH || op == Opcodes.SIPUSH) return ((IntInsnNode) x).operand;
        return Integer.MIN_VALUE;
    }

    static AbstractInsnNode push(int v) {
        if (v >= -1 && v <= 5) return new InsnNode(Opcodes.ICONST_0 + v);
        return new IntInsnNode(Opcodes.BIPUSH, v);
    }

    /** Tim literal new byte[]{vals}; dung lai khong co phan tu `drop`. Tra 1 neu thay. */
    static int dropByte(MethodNode m, int[] vals, int drop) {
        for (AbstractInsnNode x = m.instructions.getFirst(); x != null; x = x.getNext()) {
            if (pushVal(x) != vals.length) continue;
            AbstractInsnNode na = x.getNext();
            if (na == null || na.getOpcode() != Opcodes.NEWARRAY || ((IntInsnNode) na).operand != Opcodes.T_BYTE) continue;
            AbstractInsnNode y = na.getNext();
            boolean ok = true;
            List<AbstractInsnNode> seq = new ArrayList<>();
            seq.add(x); seq.add(na);
            for (int i = 0; i < vals.length && ok; i++) {
                AbstractInsnNode d = y, ix = d == null ? null : d.getNext(), v = ix == null ? null : ix.getNext(), st = v == null ? null : v.getNext();
                if (d == null || d.getOpcode() != Opcodes.DUP || pushVal(ix) != i || pushVal(v) != vals[i] || st == null || st.getOpcode() != Opcodes.BASTORE) { ok = false; break; }
                seq.add(d); seq.add(ix); seq.add(v); seq.add(st);
                y = st.getNext();
            }
            if (!ok) continue;
            InsnList L = new InsnList();
            L.add(push(vals.length - 1));
            L.add(new IntInsnNode(Opcodes.NEWARRAY, Opcodes.T_BYTE));
            int j = 0;
            for (int v : vals) {
                if (v == drop) continue;
                L.add(new InsnNode(Opcodes.DUP)); L.add(push(j++)); L.add(push(v)); L.add(new InsnNode(Opcodes.BASTORE));
            }
            m.instructions.insertBefore(x, L);
            for (AbstractInsnNode r : seq) m.instructions.remove(r);
            return 1;
        }
        return 0;
    }

    static void setBody(MethodNode m, InsnList L) {
        m.instructions = L;
        m.tryCatchBlocks = new ArrayList<>();
        m.localVariables = null;
    }

    static void expect(String what, int got, int want) {
        String m = (got == want ? "OK   " : "FAIL ") + what + ": " + got + " (mong doi " + want + ")";
        log.println(m);
        if (got != want) {
            failed = true;
            System.err.println(m);
        }
    }

    static void patchText(ClassNode cn, Cfg c) {
        String gF = "F:" + c.fG + ":" + GD, gr = "F:" + c.fGrad + ":[I", ct = "F:" + c.fCtab + ":[[I";
        body(cn, c.mDrawG, "(" + STR + "III[B)I", "drawG", "(" + GD + "[I[[I" + STR + "III)I",
                gF, gr, ct, "A1", "I2", "I3", "I4");
        body(cn, c.mDrawC, "(" + STR + "III[BI)V", "drawC", "(" + GD + STR + "IIII)V",
                gF, "A1", "I2", "I3", "I4", "I6");
        body(cn, c.mLines, "([" + STR + "IIIIII)V", "lines", "(" + GD + "[I[[I[" + STR + "IIIII)V",
                gF, gr, ct, "A1", "I2", "I3", "I4", "I5", "I6");
        if (c.v360) {
            body(cn, c.mLinesTW, "([" + STR + "IIIIIIB)V", "linesTWA", "(" + GD + "[I[[I[" + STR + "IIIIII)V",
                    gF, gr, ct, "A1", "I2", "I3", "I4", "I5", "I6", "I8");
            body(cn, c.mLinesFade, "([" + STR + "IIIIII)V", "linesFadeA", "(" + GD + "[I[[I[" + STR + "IIIIII)V",
                    gF, gr, ct, "A1", "I2", "I3", "I4", "I5", "I6", "I7");
            body(cn, c.mHeight, "()I", "height", "()I");
        } else {
            body(cn, c.mLinesTW, "([" + STR + "IIIIIIB)V", "linesTW", "(" + GD + "[I[[I[" + STR + "IIIII)V",
                    gF, gr, ct, "A1", "I2", "I3", "I5", "I6", "I8");
            body(cn, c.mLinesFade, "([" + STR + "IIIIII)V", "linesFade", "(" + GD + "[I[[I[" + STR + "IIIII)V",
                    gF, gr, ct, "A1", "K" + c.cx, "I3", "I5", "I6", "I7");
        }
        body(cn, c.mWidth, "(" + STR + ")I", "width", "(" + STR + ")I", "A1");
        body(cn, c.mWidthRaw, "(" + STR + ")I", "widthRaw", "(" + STR + ")I", "A1");
        body(cn, c.mTw, "(" + STR + ")I", "twUnits", "(" + STR + ")I", c.v360 ? "A1" : "A0");
        body(cn, c.mWrap, "(" + STR + "II)[" + STR, "wrap", "(" + STR + "I)[" + STR, "A1", "I2");
        String IMG = "Ljavax/microedition/lcdui/Image;";
        body(cn, c.mModule, "(" + IMG + "IIII[SI)V", "mod", "(" + GD + IMG + "IIII[SI)V",
                gF, "A1", "I2", "I3", "I4", "I5", "A6", "I7");
        int n = redirectCalls(cn, G, "drawString", "(" + STR + "III)V", "drawString", "(" + GD + STR + "III)V");
        expect(c.cls + " Graphics.drawString -> VH.drawString", n, c.drawStrings);
    }

    static MethodNode method(ClassNode cn, String n, String d) {
        MethodNode r = null;
        for (MethodNode m : cn.methods) if (m.name.equals(n) && m.desc.equals(d)) r = m;
        return r;
    }

    /** Thay toan bo than method: nap cac gia tri theo spec -> invokestatic VH.target -> return dung kieu. */
    static void body(ClassNode cn, String n, String d, String target, String tdesc, String... spec) {
        MethodNode m = method(cn, n, d);
        expect("than " + cn.name + "." + n + d + " -> VH." + target, m == null ? 0 : 1, 1);
        if (m == null) return;
        boolean isStatic = (m.access & Opcodes.ACC_STATIC) != 0;
        InsnList L = new InsnList();
        for (String s : spec) {
            char k = s.charAt(0);
            if (k == 'F') {
                String[] p = s.split(":", 3);
                if (isStatic) throw new IllegalStateException("field tren method static");
                if (findField(cn, p[1], p[2]) == null) expect("field " + p[1] + p[2], 0, 1);
                L.add(new VarInsnNode(Opcodes.ALOAD, 0));
                L.add(new FieldInsnNode(Opcodes.GETFIELD, cn.name, p[1], p[2]));
            } else if (k == 'A') {
                L.add(new VarInsnNode(Opcodes.ALOAD, Integer.parseInt(s.substring(1))));
            } else if (k == 'I') {
                L.add(new VarInsnNode(Opcodes.ILOAD, Integer.parseInt(s.substring(1))));
            } else if (k == 'K') {
                int v = Integer.parseInt(s.substring(1));
                L.add(v >= -32768 && v <= 32767 ? new IntInsnNode(Opcodes.SIPUSH, v) : new LdcInsnNode(v));
            }
        }
        L.add(new MethodInsnNode(Opcodes.INVOKESTATIC, VH, target, tdesc, false));
        Type rt = Type.getReturnType(d);
        if (!rt.equals(Type.getReturnType(tdesc))) throw new IllegalStateException("kieu tra ve lech " + n + d);
        L.add(new InsnNode(rt.getOpcode(Opcodes.IRETURN)));
        m.instructions = L;
        m.tryCatchBlocks = new ArrayList<>();
        m.localVariables = null;
        m.visibleLocalVariableAnnotations = null;
        m.invisibleLocalVariableAnnotations = null;
    }

    static FieldNode findField(ClassNode cn, String n, String d) {
        for (FieldNode f : cn.fields) if (f.name.equals(n) && f.desc.equals(d)) return f;
        return null;
    }

    /** invokevirtual owner.name(desc) -> invokestatic VH.target(tdesc), cung hinh dang stack. */
    static int redirectCalls(ClassNode cn, String owner, String name, String desc, String target, String tdesc) {
        int k = 0;
        for (MethodNode m : cn.methods) {
            List<MethodInsnNode> hit = new ArrayList<>();
            for (AbstractInsnNode x = m.instructions.getFirst(); x != null; x = x.getNext()) {
                if (x instanceof MethodInsnNode) {
                    MethodInsnNode mi = (MethodInsnNode) x;
                    if (mi.getOpcode() == Opcodes.INVOKEVIRTUAL && mi.owner.equals(owner) && mi.name.equals(name) && mi.desc.equals(desc)) hit.add(mi);
                }
            }
            for (MethodInsnNode mi : hit) m.instructions.set(mi, new MethodInsnNode(Opcodes.INVOKESTATIC, VH, target, tdesc, false));
            k += hit.size();
        }
        return k;
    }

    static void stripStackMap(ClassNode cn) {
        for (MethodNode m : cn.methods) {
            if (m.instructions == null) continue;
            for (AbstractInsnNode x = m.instructions.getFirst(); x != null; ) {
                AbstractInsnNode nx = x.getNext();
                if (x instanceof FrameNode) m.instructions.remove(x);
                x = nx;
            }
        }
        if (cn.attrs != null) cn.attrs.clear();
    }
}
