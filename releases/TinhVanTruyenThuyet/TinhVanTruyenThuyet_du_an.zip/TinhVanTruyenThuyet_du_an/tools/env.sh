# moi truong cua bo tool (tuong doi): source tools/env.sh
source "$(dirname "${BASH_SOURCE[0]:-$0}")/../scripts/env.sh"
