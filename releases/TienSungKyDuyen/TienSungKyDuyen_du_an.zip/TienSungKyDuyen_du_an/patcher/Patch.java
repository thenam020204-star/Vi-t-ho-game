import java.io.*;
import java.nio.file.*;
import java.util.*;

import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/**
 * Patch bytecode tinh cho "Tien Sung Ky Duyen" - Viet hoa (QD thiet ke 1-4, 2b trong PLAN.md).
 *   java -cp asm.jar:asm-tree.jar:. Patch <in_dir> <out_dir> <patch_log>
 * Chi ghi cac class co sua; class khac giu nguyen byte goc. Version class giu nguyen (45.3), COMPUTE_MAXS,
 * bo StackMap cu (ProGuard -microedition sinh lai). Moi patch phai khop DUNG so lan mong doi, sai -> exit 1.
 */
public class Patch {
    static final String G = "javax/microedition/lcdui/Graphics";
    static final String F = "javax/microedition/lcdui/Font";
    static final String VH = "VH";
    static final String STR = "Ljava/lang/String;";
    static PrintWriter log;
    static boolean failed = false;

    // ---- 5 loai call-site (QD 2): owner, name, desc, ten ham VH
    static final String[][] CALLS = {
        {G, "drawString", "(" + STR + "III)V", "drawString"},
        {F, "stringWidth", "(" + STR + ")I", "stringWidth"},
        {F, "charWidth", "(C)I", "charWidth"},
        {F, "substringWidth", "(" + STR + "II)I", "substringWidth"},
        {F, "getHeight", "()I", "getHeight"},
    };
    // ---- so call-site CON LAI sau khi da thay than method (docs/render.md muc 1-2): lop -> {drawString, stringWidth, charWidth, substringWidth, getHeight}
    static final Map<String, int[]> EXPECT = new LinkedHashMap<>();
    static {
        EXPECT.put("Main/a", new int[]{1, 0, 0, 0, 0});
        EXPECT.put("Main/e", new int[]{10, 8, 0, 0, 1});
        EXPECT.put("Main/f", new int[]{1, 2, 0, 0, 1});
        EXPECT.put("Main/g", new int[]{0, 0, 0, 0, 0});
        EXPECT.put("Main/j", new int[]{13, 12, 0, 0, 0});
        EXPECT.put("Main/k", new int[]{0, 1, 0, 0, 1});
        EXPECT.put("rf/b", new int[]{0, 1, 0, 0, 1});
        EXPECT.put("rf/c", new int[]{1, 0, 0, 0, 0});
        EXPECT.put("rf/e", new int[]{3, 0, 0, 0, 0});
    }
    // ---- so call-site TRUOC khi thay than method (de chung minh than method cu dung nhu phan tich)
    static final Map<String, int[]> BEFORE = new LinkedHashMap<>();
    static {
        BEFORE.put("Main/f", new int[]{11, 2, 0, 0, 1});
        BEFORE.put("Main/g", new int[]{1, 0, 2, 0, 0});
        BEFORE.put("rf/b", new int[]{10, 1, 0, 2, 1});
    }

    public static void main(String[] a) throws Exception {
        Path in = Paths.get(a[0]), out = Paths.get(a[1]);
        if (a.length > 3) loadTranslated(a[3]);
        log = new PrintWriter(new FileWriter(a[2]));
        List<Path> files = new ArrayList<>();
        try (java.util.stream.Stream<Path> st = Files.walk(in)) {
            st.filter(p -> p.toString().endsWith(".class")).sorted().forEach(files::add);
        }
        int tot[] = new int[CALLS.length];
        int changedClasses = 0;
        for (Path f : files) {
            String name = in.relativize(f).toString().replace('\\', '/');
            name = name.substring(0, name.length() - 6);
            byte[] b = Files.readAllBytes(f);
            ClassNode cn = new ClassNode();
            new ClassReader(b).accept(cn, 0);
            boolean ch = patchClass(cn, name, tot);
            if (!ch) continue;
            stripStackMap(cn);
            ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
            cn.accept(cw);
            Path o = out.resolve(name + ".class");
            Files.createDirectories(o.getParent());
            Files.write(o, cw.toByteArray());
            changedClasses++;
        }
        for (int i = 0; i < CALLS.length; i++) {
            int want = 0;
            for (int[] e : EXPECT.values()) want += e[i];
            expect("TONG " + CALLS[i][1], tot[i], want);
        }
        log.println("class da ghi: " + changedClasses);
        log.close();
        if (failed) {
            System.err.println("PATCH FAILED - xem log");
            System.exit(1);
        }
        System.out.println("PATCH OK (" + changedClasses + " class)");
    }

    /** Cac chuoi dich cua hang `class:` trong TSV (cot 5): chi nhung chuoi nay moi duoc chen dau cach khi noi. */
    static final Set<String> TRANSLATED = new HashSet<>();

    static void loadTranslated(String tsv) throws IOException {
        for (String ln : Files.readAllLines(Paths.get(tsv), java.nio.charset.StandardCharsets.UTF_8)) {
            String[] c = ln.split("\t", -1);
            if (c.length > 4 && c[1].startsWith("class:") && c[4].length() > 0) TRANSLATED.add(c[4]);
        }
    }

    static void expect(String what, int got, int want) {
        String m = (got == want ? "OK   " : "FAIL ") + what + ": " + got + " (mong doi " + want + ")";
        log.println(m);
        if (got != want) {
            failed = true;
            System.err.println(m);
        }
    }

    static boolean patchClass(ClassNode cn, String name, int[] tot) {
        boolean changed = false;
        int[] want = EXPECT.get(name);
        int[] before = BEFORE.get(name);
        if (before != null) {
            for (int i = 0; i < CALLS.length; i++) expect(name + " [truoc] " + CALLS[i][1], count(cn, CALLS[i]), before[i]);
        }
        // QD 2b: thay than method
        if (name.equals("Main/g")) {
            redirectBody(cn, "a", "([C" + "L" + G + ";IIIII)I", "dialog");
            changed = true;
        } else if (name.equals("rf/b")) {
            wrapBody(cn, "a", "(" + STR + "I)V", "c", "e");
            wrapBody(cn, "b", "(" + STR + "I)V", "d", "f");
            redirectBody(cn, "a", "(L" + G + ";" + STR + "IIIII)V", "outline");
            changed = true;
        } else if (name.equals("Main/f")) {
            redirectBody(cn, "a", "(L" + G + ";" + STR + "IIIII)V", "outline");
            changed = true;
        }
        if (name.equals("Main/f")) {
            patchBoot(cn);
            changed = true;
        }
        // QD 2: thay call-site
        for (int i = 0; i < CALLS.length; i++) {
            int n = redirectCalls(cn, CALLS[i][0], CALLS[i][1], CALLS[i][2], CALLS[i][3]);
            tot[i] += n;
            if (n > 0) changed = true;
            int w = want == null ? 0 : want[i];
            if (n != w || n > 0) expect(name + " " + CALLS[i][1], n, w);
        }
        if (name.equals("Main/j")) {
            patchMainJ(cn);
            changed = true;
        } else if (name.equals("Main/e")) {
            patchShop(cn);
            changed = true;
        } else if (name.equals("Main/a")) {
            patchKeyEq(cn);
            changed = true;
        }
        if (name.equals("Main/j") || name.equals("Main/e")) {
            if (spaceConcat(cn) > 0) changed = true;
        }
        if (name.equals("Main/j") || name.equals("Main/e") || name.equals("rf/b")) {
            int c = cacheConcat(cn);
            if (c > 0) changed = true;
        }
        return changed;
    }

    static int count(ClassNode cn, String[] c) {
        int n = 0;
        for (MethodNode m : cn.methods) {
            for (AbstractInsnNode x = m.instructions.getFirst(); x != null; x = x.getNext()) {
                if (isCall(x, Opcodes.INVOKEVIRTUAL, c[0], c[1], c[2])) n++;
            }
        }
        return n;
    }

    static void stripStackMap(ClassNode cn) {
        if (cn.attrs != null) cn.attrs.removeIf(x -> x.type.equals("StackMap"));
        for (MethodNode m : cn.methods) {
            if (m.attrs != null) m.attrs.removeIf(x -> x.type.equals("StackMap") || x.type.equals("StackMapTable"));
        }
    }

    static MethodNode method(ClassNode cn, String n, String d) {
        for (MethodNode m : cn.methods) if (m.name.equals(n) && m.desc.equals(d)) return m;
        throw new RuntimeException("khong thay " + cn.name + "." + n + d);
    }

    static void clearBody(MethodNode m) {
        m.instructions.clear();
        m.tryCatchBlocks.clear();
        m.localVariables = null;
        m.visibleLocalVariableAnnotations = null;
        m.invisibleLocalVariableAnnotations = null;
    }

    /** Thay toan bo than method: nap tham so (khong gom this) -> invokestatic VH.target(desc) -> return. */
    static void redirectBody(ClassNode cn, String n, String d, String target) {
        MethodNode m = method(cn, n, d);
        clearBody(m);
        InsnList L = new InsnList();
        int slot = (m.access & Opcodes.ACC_STATIC) != 0 ? 0 : 1;
        for (Type t : Type.getArgumentTypes(d)) {
            L.add(new VarInsnNode(t.getOpcode(Opcodes.ILOAD), slot));
            slot += t.getSize();
        }
        L.add(new MethodInsnNode(Opcodes.INVOKESTATIC, VH, target, d, false));
        L.add(new InsnNode(Type.getReturnType(d).getOpcode(Opcodes.IRETURN)));
        m.instructions = L;
        log.println("BODY " + cn.name + "." + n + d + " -> VH." + target);
    }

    /** rf.b.a/b(String,int) (static): arr = <cn>.<arrField>; <cn>.<cntField> = VH.wrap(s, w, arr). */
    static void wrapBody(ClassNode cn, String n, String d, String arrField, String cntField) {
        MethodNode m = method(cn, n, d);
        clearBody(m);
        InsnList L = new InsnList();
        L.add(new VarInsnNode(Opcodes.ALOAD, 0));
        L.add(new VarInsnNode(Opcodes.ILOAD, 1));
        L.add(new FieldInsnNode(Opcodes.GETSTATIC, cn.name, arrField, "[" + STR));
        L.add(new MethodInsnNode(Opcodes.INVOKESTATIC, VH, "wrap", "(" + STR + "I[" + STR + ")I", false));
        L.add(new FieldInsnNode(Opcodes.PUTSTATIC, cn.name, cntField, "I"));
        L.add(new InsnNode(Opcodes.RETURN));
        m.instructions = L;
        log.println("BODY " + cn.name + "." + n + d + " -> VH.wrap(" + arrField + "," + cntField + ")");
    }

    /** invokevirtual owner.name(desc) -> invokestatic VH.target(Lowner;desc). */
    static int redirectCalls(ClassNode cn, String owner, String name, String desc, String target) {
        String nd = "(L" + owner + ";" + desc.substring(1);
        int n = 0;
        for (MethodNode m : cn.methods) {
            AbstractInsnNode x = m.instructions.getFirst();
            while (x != null) {
                AbstractInsnNode nx = x.getNext();
                if (isCall(x, Opcodes.INVOKEVIRTUAL, owner, name, desc)) {
                    m.instructions.set(x, new MethodInsnNode(Opcodes.INVOKESTATIC, VH, target, nd, false));
                    n++;
                }
                x = nx;
            }
        }
        return n;
    }

    static AbstractInsnNode next(AbstractInsnNode x) {
        x = x.getNext();
        while (x != null && (x instanceof LabelNode || x instanceof LineNumberNode || x instanceof FrameNode)) x = x.getNext();
        return x;
    }

    static AbstractInsnNode prev(AbstractInsnNode x) {
        x = x.getPrevious();
        while (x != null && (x instanceof LabelNode || x instanceof LineNumberNode || x instanceof FrameNode)) x = x.getPrevious();
        return x;
    }

    static boolean isField(AbstractInsnNode x, int op, String owner, String name) {
        return x != null && x.getOpcode() == op && ((FieldInsnNode) x).owner.equals(owner) && ((FieldInsnNode) x).name.equals(name);
    }

    static boolean isCall(AbstractInsnNode x, int op, String owner, String name, String desc) {
        if (x == null || x.getOpcode() != op) return false;
        MethodInsnNode m = (MethodInsnNode) x;
        return m.owner.equals(owner) && m.name.equals(name) && m.desc.equals(desc);
    }

    static int intValue(AbstractInsnNode x) {
        int op = x.getOpcode();
        if (op >= Opcodes.ICONST_M1 && op <= Opcodes.ICONST_5) return op - Opcodes.ICONST_0;
        if (op == Opcodes.BIPUSH || op == Opcodes.SIPUSH) return ((IntInsnNode) x).operand;
        if (op == Opcodes.LDC && ((LdcInsnNode) x).cst instanceof Integer) return (Integer) ((LdcInsnNode) x).cst;
        return Integer.MIN_VALUE;
    }

    // ===================================================================== T7: bo cuc
    static MethodInsnNode vhCall(String name, String desc) {
        return new MethodInsnNode(Opcodes.INVOKESTATIC, VH, name, desc, false);
    }

    /** Doi cac call VH.drawString trong method (name, (Graphics)V) thanh VH.<to>; phai dung `want` lan. */
    static void retarget(ClassNode cn, String mname, String to, int want) {
        MethodNode m = method(cn, mname, "(L" + G + ";)V");
        int n = 0;
        for (AbstractInsnNode x = m.instructions.getFirst(); x != null; x = x.getNext()) {
            if (x instanceof MethodInsnNode && x.getOpcode() == Opcodes.INVOKESTATIC) {
                MethodInsnNode mi = (MethodInsnNode) x;
                if (mi.owner.equals(VH) && mi.name.equals("drawString")) {
                    mi.name = to;
                    n++;
                }
            }
        }
        expect(cn.name + "." + mname + " drawString -> VH." + to, n, want);
    }

    /** T9: bo remap phim cho p==6 (E62) trong Main/j.d(String,String): case 6 -> default (khong doi 48->109, -4->104, -2->98). */
    static void patchKeyRemap(ClassNode cn) {
        MethodNode d = method(cn, "d", "(" + STR + STR + ")V");
        int n = 0;
        for (AbstractInsnNode x = d.instructions.getFirst(); x != null; x = x.getNext()) {
            if (x instanceof TableSwitchInsnNode) {
                TableSwitchInsnNode t = (TableSwitchInsnNode) x;
                if (t.min == 4 && t.max == 6) {
                    t.labels.set(2, t.dflt);
                    n++;
                }
            }
        }
        expect("Main/j.d: bo remap phim case 6", n, 1);
    }

    /** T9: so khop phim bang nhom tuong duong: cq (phim bam) so voi Integer.parseInt(cr) -> VH.keyEq (4 cho trong Main/a). */
    static void patchKeyEq(ClassNode cn) {
        int n = 0;
        for (MethodNode m : cn.methods) {
            for (AbstractInsnNode x = m.instructions.getFirst(); x != null; x = x.getNext()) {
                if (isCall(x, Opcodes.INVOKESTATIC, "java/lang/Integer", "parseInt", "(" + STR + ")I")) {
                    AbstractInsnNode nx = x.getNext();
                    AbstractInsnNode pv = prev(x);
                    if (nx instanceof JumpInsnNode && (nx.getOpcode() == Opcodes.IF_ICMPEQ || nx.getOpcode() == Opcodes.IF_ICMPNE)
                            && pv != null && pv.getOpcode() == Opcodes.GETSTATIC && ((FieldInsnNode) pv).name.equals("cr")) {
                        m.instructions.insert(x, vhCall("keyEq", "(II)Z"));
                        JumpInsnNode j = (JumpInsnNode) nx;
                        m.instructions.set(nx, new JumpInsnNode(nx.getOpcode() == Opcodes.IF_ICMPEQ ? Opcodes.IFNE : Opcodes.IFEQ, j.label));
                        n++;
                    }
                }
            }
        }
        expect("Main/a: keyEq thay so sanh cq/cr", n, 4);
    }

    static void patchMainJ(ClassNode cn) {
        patchKeyRemap(cn);
        // phim mem phai ("Thoat"/"Quay lai", x = t - k.w*2 - 1) va "Tam dung" (x = t/2 - k.w): can theo do rong that
        retarget(cn, "y", "drawRight", 1);
        retarget(cn, "z", "drawRight", 1);
        retarget(cn, "i", "drawMid", 1);

        // menu chinh f(Graphics): (1) bo muc 2 ("Game khac", platformRequest quang cao), (2) mui ten theo nhan dang chon
        MethodNode f = method(cn, "f", "(L" + G + ";)V");
        InsnList pre = new InsnList();
        pre.add(new VarInsnNode(Opcodes.ALOAD, 0));
        pre.add(new VarInsnNode(Opcodes.ALOAD, 0));
        pre.add(new FieldInsnNode(Opcodes.GETFIELD, "Main/j", "cR", "I"));
        String[] busy = {"bS", "bX", "bC", "bk", "bs", "bL"};
        for (int i = 0; i < busy.length; i++) {
            pre.add(new FieldInsnNode(Opcodes.GETSTATIC, "Main/j", busy[i], "Z"));
            if (i > 0) pre.add(new InsnNode(Opcodes.IOR));
        }
        pre.add(vhCall("menuSkip", "(II)I"));
        pre.add(new FieldInsnNode(Opcodes.PUTFIELD, "Main/j", "cR", "I"));
        f.instructions.insert(pre);
        int arrows = 0;
        for (AbstractInsnNode x = f.instructions.getFirst(); x != null; x = x.getNext()) {
            if (x.getOpcode() == Opcodes.ALOAD && ((VarInsnNode) x).var == 2) {
                AbstractInsnNode a1 = x.getNext();
                AbstractInsnNode a2 = a1 == null ? null : a1.getNext();
                AbstractInsnNode a3 = a2 == null ? null : a2.getNext();
                if (a1 != null && a1.getOpcode() == Opcodes.ICONST_1 && a2 != null && a2.getOpcode() == Opcodes.AALOAD
                        && a3 != null && a3.getOpcode() == Opcodes.INVOKESTATIC && ((MethodInsnNode) a3).name.equals("stringWidth")) {
                    InsnList r = new InsnList();
                    r.add(new VarInsnNode(Opcodes.ALOAD, 0));
                    r.add(new FieldInsnNode(Opcodes.GETFIELD, "Main/j", "cR", "I"));
                    f.instructions.insert(a1, r);
                    f.instructions.remove(a1);
                    arrows++;
                }
            }
        }
        expect("Main/j.f: mui ten menu theo nhan dang chon", arrows, 2);

        // o mo ta cuon doc a(G,String,IIIII)V: cuon theo trang (hang + thay trang), khong cat nua dong
        MethodNode a = method(cn, "a", "(L" + G + ";" + STR + "IIIII)V");
        clearBody(a);
        InsnList L = new InsnList();
        LabelNode skip = new LabelNode();
        // g=1 s=2 w=3 h=4 x=5 y=6 color=7
        L.add(new VarInsnNode(Opcodes.ALOAD, 1));
        L.add(new VarInsnNode(Opcodes.ILOAD, 5));
        L.add(new VarInsnNode(Opcodes.ILOAD, 6));
        L.add(new VarInsnNode(Opcodes.ILOAD, 3));
        L.add(new VarInsnNode(Opcodes.ILOAD, 4));
        L.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, G, "setClip", "(IIII)V", false));
        L.add(new FieldInsnNode(Opcodes.GETSTATIC, "Main/j", "bE", "Z"));
        L.add(new JumpInsnNode(Opcodes.IFEQ, skip));
        L.add(new VarInsnNode(Opcodes.ALOAD, 2));
        L.add(new VarInsnNode(Opcodes.ILOAD, 3));
        L.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "rf/b", "a", "(" + STR + "I)V", false));
        L.add(new InsnNode(Opcodes.ICONST_0));
        L.add(new FieldInsnNode(Opcodes.PUTSTATIC, "Main/j", "bE", "Z"));
        L.add(new InsnNode(Opcodes.ICONST_0));
        L.add(new FieldInsnNode(Opcodes.PUTSTATIC, "Main/j", "cW", "I"));
        L.add(new VarInsnNode(Opcodes.ALOAD, 0));
        L.add(new InsnNode(Opcodes.ICONST_0));
        L.add(new FieldInsnNode(Opcodes.PUTFIELD, "Main/j", "X", "I"));
        L.add(skip);
        L.add(new VarInsnNode(Opcodes.ALOAD, 0));
        L.add(new VarInsnNode(Opcodes.ALOAD, 1));
        L.add(new FieldInsnNode(Opcodes.GETSTATIC, "rf/b", "c", "[" + STR));
        L.add(new FieldInsnNode(Opcodes.GETSTATIC, "rf/b", "e", "I"));
        L.add(new VarInsnNode(Opcodes.ILOAD, 5));
        L.add(new VarInsnNode(Opcodes.ILOAD, 6));
        L.add(new VarInsnNode(Opcodes.ILOAD, 3));
        L.add(new VarInsnNode(Opcodes.ILOAD, 4));
        L.add(new VarInsnNode(Opcodes.ILOAD, 7));
        L.add(new VarInsnNode(Opcodes.ALOAD, 0));
        L.add(new FieldInsnNode(Opcodes.GETFIELD, "Main/j", "X", "I"));
        L.add(vhCall("scroll", "(L" + G + ";[" + STR + "IIIIIII)I"));
        L.add(new FieldInsnNode(Opcodes.PUTFIELD, "Main/j", "X", "I"));
        L.add(new InsnNode(Opcodes.RETURN));
        a.instructions = L;
        log.println("BODY Main/j.a(G,String,IIIII) -> VH.scroll (cuon theo trang)");
    }

    /**
     * Cua hang Main/e.a(G,String[][],...) kieu 1 (T7b): gia can PHAI sat mep trong khung, khoi <so> ngay truoc gia, ten dung phan con lai.
     * - ten bat dau o n2+4 (goc n2+18);
     * - x khoi so = VH.shopCol(a,row,n2+n4-5) = R - 26 - rong(gia) (goc: sau ten hang dau + 20);
     * - khoang cach trong khoi 5 -> 1 (hai cho).
     */
    static void patchShop(ClassNode cn) {
        MethodNode m = method(cn, "a", "(L" + G + ";[[" + STR + "IIIIIIZI)I");
        int n = 0;
        for (AbstractInsnNode x = m.instructions.getFirst(); x != null; x = x.getNext()) {
            // ten: n2 + 18 -> n2 + 4
            if (x.getOpcode() == Opcodes.BIPUSH && ((IntInsnNode) x).operand == 18) {
                AbstractInsnNode pv = prev(x), nx = next(x);
                if (pv != null && pv.getOpcode() == Opcodes.ILOAD && ((VarInsnNode) pv).var == 4 && nx != null && nx.getOpcode() == Opcodes.IADD) {
                    ((IntInsnNode) x).operand = 4;
                    n += 100;
                }
            }
            // x cot so luong: iload15; getstatic a; aload2; iconst0; aaload; iconst0; aaload; stringWidth; iadd; bipush 20; iadd; istore 19
            if (x.getOpcode() == Opcodes.ILOAD && ((VarInsnNode) x).var == 15) {
                List<AbstractInsnNode> q = new ArrayList<>();
                AbstractInsnNode c = x;
                for (int k = 0; k < 12 && c != null; k++) { q.add(c); c = next(c); }
                if (q.size() == 12 && q.get(1).getOpcode() == Opcodes.GETSTATIC && q.get(2).getOpcode() == Opcodes.ALOAD && ((VarInsnNode) q.get(2)).var == 2
                        && q.get(3).getOpcode() == Opcodes.ICONST_0 && q.get(4).getOpcode() == Opcodes.AALOAD && q.get(5).getOpcode() == Opcodes.ICONST_0
                        && q.get(6).getOpcode() == Opcodes.AALOAD && q.get(7).getOpcode() == Opcodes.INVOKESTATIC && q.get(8).getOpcode() == Opcodes.IADD
                        && q.get(9).getOpcode() == Opcodes.BIPUSH && q.get(10).getOpcode() == Opcodes.IADD
                        && q.get(11).getOpcode() == Opcodes.ISTORE && ((VarInsnNode) q.get(11)).var == 19) {
                    InsnList r = new InsnList();
                    r.add(new VarInsnNode(Opcodes.ALOAD, 2));
                    r.add(new VarInsnNode(Opcodes.ILOAD, 17));
                    r.add(new VarInsnNode(Opcodes.ILOAD, 4));
                    r.add(new VarInsnNode(Opcodes.ILOAD, 6));
                    r.add(new InsnNode(Opcodes.IADD));
                    r.add(new InsnNode(Opcodes.ICONST_5));
                    r.add(new InsnNode(Opcodes.ISUB));
                    r.add(vhCall("shopCol", "([[" + STR + "II)I"));
                    m.instructions.insertBefore(q.get(11), r);
                    for (int k = 0; k < 11; k++) m.instructions.remove(q.get(k));
                    // khoang cach 5 -> 1 (2 cho ngay sau)
                    int g = 0;
                    AbstractInsnNode y = q.get(11);
                    while (y != null && g < 2) {
                        AbstractInsnNode ny = y.getNext();
                        if (y.getOpcode() == Opcodes.ICONST_5 && next(y) != null && next(y).getOpcode() == Opcodes.IADD) {
                            m.instructions.set(y, new InsnNode(Opcodes.ICONST_1));
                            g++;
                        }
                        y = ny;
                    }
                    n += g == 2 ? 1 : 1000;
                }
            }
        }
        expect("Main/e.a(String[][]): bo cuc cua hang (ten, cot, khoang cach)", n, 101);
    }

    /**
     * Noi chuoi `bien + "Han dich" + bien`: ban goc tieng Trung khong can dau cach, tieng Viet thi can.
     * Duyet moi chuoi new StringBuffer()...append(..)...toString() (chi chuoi khong co nhay/lenh khac): moi hang LDC la chu dich
     * (>= 2 chu cai) ke voi mot phan tu KHONG phai LDC (bien/so) thi chen dau cach o phia ke; LDC "x" dung sau bien -> " x".
     * Sua truc tiep hang LDC tai vi tri noi (khong dong vao hang dung chung o noi khac).
     */
    static int spaceConcat(ClassNode cn) {
        int total = 0;
        String sb = "java/lang/StringBuffer";
        java.util.regex.Pattern word = java.util.regex.Pattern.compile("[A-Za-zÀ-ỹ]{2,}");
        for (MethodNode m : cn.methods) {
            for (AbstractInsnNode x = m.instructions.getFirst(); x != null; x = x.getNext()) {
                if (!(x.getOpcode() == Opcodes.NEW && ((TypeInsnNode) x).desc.equals(sb))) continue;
                AbstractInsnNode d = next(x), ini = d == null ? null : next(d);
                if (d == null || d.getOpcode() != Opcodes.DUP || ini == null || !isCall(ini, Opcodes.INVOKESPECIAL, sb, "<init>", "()V")) continue;
                List<LdcInsnNode> ldc = new ArrayList<>();      // phan tu LDC (hoac null neu la bien)
                AbstractInsnNode c = next(ini);
                int cnt = 0;
                boolean ok = true;
                AbstractInsnNode first = null;
                int groupLen = 0;
                LdcInsnNode single = null;
                while (c != null && ok) {
                    if (isCall(c, Opcodes.INVOKEVIRTUAL, sb, "toString", "()" + STR)) break;
                    if (c instanceof MethodInsnNode && c.getOpcode() == Opcodes.INVOKEVIRTUAL && ((MethodInsnNode) c).owner.equals(sb)
                            && ((MethodInsnNode) c).name.equals("append")) {
                        ldc.add(groupLen == 1 ? single : null);
                        groupLen = 0;
                        single = null;
                        cnt++;
                    } else if (c instanceof JumpInsnNode || c.getOpcode() == Opcodes.NEW || c instanceof TableSwitchInsnNode || c instanceof LookupSwitchInsnNode) {
                        ok = false;
                    } else {
                        groupLen++;
                        single = (c instanceof LdcInsnNode && ((LdcInsnNode) c).cst instanceof String) ? (LdcInsnNode) c : null;
                    }
                    c = next(c);
                }
                if (!ok || c == null || cnt < 2 || groupLen != 0) continue;
                for (int i = 0; i < ldc.size(); i++) {
                    LdcInsnNode e = ldc.get(i);
                    if (e == null) continue;
                    String v = (String) e.cst;
                    boolean prevVar = i > 0 && ldc.get(i - 1) == null;
                    boolean nextVar = i + 1 < ldc.size() && ldc.get(i + 1) == null;
                    String nv = v;
                    if (v.equals("x") && prevVar) {
                        nv = " x";
                    } else if (TRANSLATED.contains(v) && v.length() > 0) {
                        char f = v.charAt(0), l = v.charAt(v.length() - 1);
                        if (prevVar && Character.isLetterOrDigit(f)) nv = " " + nv;
                        if (nextVar && l != ' ' && l != '^' && l != '@') nv = nv + " ";
                    }
                    if (!nv.equals(v)) {
                        e.cst = nv;
                        total++;
                        log.println("  space concat " + cn.name + "." + m.name + ": \"" + v + "\" -> \"" + nv + "\"");
                    }
                }
            }
        }
        log.println("spaceConcat " + cn.name + ": " + total);
        return total;
    }

    /**
     * Noi chuoi toan String ("a" + b + "^") moi khung hinh: thay chuoi new StringBuffer().append(S)...toString() bang
     * VH.catN(a,b,..,slot): neu cac phan tu giu nguyen (so sanh tham chieu) thi tra lai ket qua da noi (khong cap phat).
     * Chi xu ly chuoi chi co append(String) voi doi so la 1 lenh don (LDC/ALOAD/GETSTATIC/this.field).
     */
    static int catSlots = 0;

    static int cacheConcat(ClassNode cn) {
        int total = 0;
        String sb = "java/lang/StringBuffer";
        for (MethodNode m : cn.methods) {
            AbstractInsnNode x = m.instructions.getFirst();
            while (x != null) {
                AbstractInsnNode nx = x.getNext();
                if (x.getOpcode() == Opcodes.NEW && ((TypeInsnNode) x).desc.equals(sb)) {
                    AbstractInsnNode d = next(x), ini = d == null ? null : next(d);
                    if (d != null && d.getOpcode() == Opcodes.DUP && ini != null && isCall(ini, Opcodes.INVOKESPECIAL, sb, "<init>", "()V")) {
                        List<InsnList> args = new ArrayList<>();
                        List<AbstractInsnNode> all = new ArrayList<>();
                        AbstractInsnNode c = next(ini);
                        boolean ok = true;
                        AbstractInsnNode end = null;
                        while (ok) {
                            // doi so: day lenh nap thuan (khong nhay/goi/ghi) ket thuc bang append(String)
                            AbstractInsnNode a = c;
                            int cntIn = 0;
                            while (a != null && !isCall(a, Opcodes.INVOKEVIRTUAL, sb, "append", "(" + STR + ")L" + sb + ";")) {
                                int op = a.getOpcode();
                                boolean pure = op == Opcodes.LDC || op == Opcodes.ALOAD || op == Opcodes.ILOAD || op == Opcodes.GETSTATIC
                                        || op == Opcodes.GETFIELD || op == Opcodes.AALOAD || (op >= Opcodes.ICONST_M1 && op <= Opcodes.ICONST_5)
                                        || op == Opcodes.BIPUSH || op == Opcodes.SIPUSH;
                                if (!pure || cntIn > 8) { ok = false; break; }
                                all.add(a);
                                cntIn++;
                                a = next(a);
                            }
                            if (!ok || a == null || cntIn == 0) { ok = false; break; }
                            args.add(null);
                            all.add(a);
                            c = next(a);
                            if (c != null && isCall(c, Opcodes.INVOKEVIRTUAL, sb, "toString", "()" + STR)) { end = c; break; }
                        }
                        if (ok && end != null && args.size() >= 2 && args.size() <= 4) {
                            // gom lenh doi so (bo cac append)
                            List<AbstractInsnNode> keep = new ArrayList<>();
                            for (AbstractInsnNode q : all) if (!(q instanceof MethodInsnNode)) keep.add(q);
                            InsnList rep = new InsnList();
                            // doi so duoc giu nguyen thu tu; dem cho du 4 doi so
                            for (AbstractInsnNode q : keep) {
                                m.instructions.remove(q);
                                rep.add(q);
                            }
                            for (int i = args.size(); i < 4; i++) rep.add(new FieldInsnNode(Opcodes.GETSTATIC, VH, "E", STR));
                            rep.add(new LdcInsnNode(catSlots++));
                            rep.add(vhCall("cat", "(" + STR + STR + STR + STR + "I)" + STR));
                            m.instructions.insertBefore(x, rep);
                            // xoa new/dup/init + cac append + toString
                            for (AbstractInsnNode q : all) if (q instanceof MethodInsnNode) m.instructions.remove(q);
                            m.instructions.remove(end);
                            m.instructions.remove(ini);
                            m.instructions.remove(d);
                            nx = x.getNext();
                            m.instructions.remove(x);
                            total++;
                            log.println("  concat cache " + cn.name + "." + m.name + m.desc + " (" + args.size() + " phan tu) slot " + (catSlots - 1));
                        }
                    }
                }
                x = nx;
            }
        }
        log.println("cacheConcat " + cn.name + ": " + total);
        return total;
    }

    // ===================================================================== Main/f: khoi dong (QD 9)
    /**
     * - c(): chi nap /Image/namp.png (VH.logo()) vao this.h, bo bg/logo0-5/logo51/52/menu thu nho.
     * - paint pha u: ve h giua man hinh (y = s/2, khong lech -40).
     * - run(): sau 2s logo, TRUOC khi u=false: g=true; Main.j.bY=true; w=false; v=false; this.e() (bat nhac) -> bo qua hoi nhac + hoat hinh logo,
     *   di thang vao khoi finally goc (chuyen canvas, a.d().a(2), start thread).
     */
    static void patchBoot(ClassNode cn) {
        MethodNode c = method(cn, "c", "()V");
        clearBody(c);
        InsnList L = new InsnList();
        L.add(new VarInsnNode(Opcodes.ALOAD, 0));
        L.add(new MethodInsnNode(Opcodes.INVOKESTATIC, VH, "logo", "()Ljavax/microedition/lcdui/Image;", false));
        L.add(new FieldInsnNode(Opcodes.PUTFIELD, "Main/f", "h", "Ljavax/microedition/lcdui/Image;"));
        L.add(new InsnNode(Opcodes.RETURN));
        c.instructions = L;
        log.println("BODY Main/f.c() -> chi nap namp.png");

        MethodNode p = method(cn, "paint", "(L" + G + ";)V");
        int n40 = 0, shifted = 0;
        for (AbstractInsnNode x = p.instructions.getFirst(); x != null; x = x.getNext()) {
            if (x.getOpcode() == Opcodes.BIPUSH && ((IntInsnNode) x).operand == 40) {
                n40++;
                if (n40 <= 2) {
                    p.instructions.set(x, x = new InsnNode(Opcodes.ICONST_0));
                    shifted++;
                }
            }
        }
        expect("Main/f.paint: bipush 40 (2 dau la pha u) -> 0", n40 * 10 + shifted, 42);

        MethodNode r = method(cn, "run", "()V");
        int ins = 0;
        for (AbstractInsnNode x = r.instructions.getFirst(); x != null; x = x.getNext()) {
            if (isField(x, Opcodes.PUTSTATIC, "Main/f", "u")) {
                AbstractInsnNode pv = prev(x);
                if (pv != null && pv.getOpcode() == Opcodes.ICONST_0) {
                    InsnList a = new InsnList();
                    a.add(new InsnNode(Opcodes.ICONST_1));
                    a.add(new FieldInsnNode(Opcodes.PUTSTATIC, "Main/f", "g", "Z"));
                    a.add(new InsnNode(Opcodes.ICONST_1));
                    a.add(new FieldInsnNode(Opcodes.PUTSTATIC, "Main/j", "bY", "Z"));
                    a.add(new InsnNode(Opcodes.ICONST_0));
                    a.add(new FieldInsnNode(Opcodes.PUTSTATIC, "Main/f", "w", "Z"));
                    a.add(new InsnNode(Opcodes.ICONST_0));
                    a.add(new FieldInsnNode(Opcodes.PUTSTATIC, "Main/f", "v", "Z"));
                    a.add(new VarInsnNode(Opcodes.ALOAD, 0));
                    a.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, "Main/f", "e", "()V", false));
                    r.instructions.insertBefore(pv, a);
                    ins++;
                }
            }
        }
        expect("Main/f.run: chen bat nhac + bo hoi nhac/logo truoc u=false", ins, 1);
    }
}
