/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Graphics
 *  javax.microedition.lcdui.Image
 */
package rf;

import Main.j;
import java.util.Vector;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import rf.a;
import rf.d;
import rf.g;

public final class e {
    public int a = 0;
    public int b = 0;
    public e c = null;
    public int d;
    int e = 0;
    int f = 0;
    public int g;
    public int h = 0;
    long i = 0L;
    public int j = 0;
    public int k = 0;
    public int l = 0;
    public int m = 0;
    public int n = 0;
    public int o = 0;
    public int p = 0;
    public int q = 0;
    public int[] r;
    public int s = 0;
    public String t = "-1";
    public short[][][] u;
    public int v = 0;
    public int w = 0;
    private short aT;
    public short x;
    public short y;
    public volatile int z = 0;
    public volatile int A = 0;
    protected byte[] B;
    protected short[] C;
    private short aU;
    public d D;
    public Vector E = new Vector();
    public short[] F;
    public short[] G;
    public short[] H;
    public short[] I;
    public short[] J;
    public int K = 0;
    int L;
    public int M = 0;
    public int N = 0;
    public int O = 0;
    public int P = -1;
    public int Q;
    public int R;
    public int S;
    public int T = 2;
    public String U = "1";
    public String V = "1";
    public String W = "1";
    public String X = "1";
    public int Y = -1;
    public int Z = 0;
    public byte aa;
    public int ab;
    public short ac = 0;
    public short ad = 0;
    public int ae;
    public volatile int af = 0;
    public int ag = 3;
    public Image[] ah;
    public boolean ai;
    public boolean aj;
    public boolean ak = true;
    public boolean al = true;
    public boolean am;
    public boolean an;
    public boolean ao;
    public byte ap;
    public boolean aq;
    public boolean ar;
    public boolean as;
    public int at;
    public int au = -1;
    public int av = 100;
    public int aw = 0;
    public int ax = 0;
    public int ay;
    public int az;
    public int aA;
    public int aB;
    public int aC;
    public int aD;
    public int aE;
    public int aF;
    public int aG;
    public String aH;
    public int aI = 0;
    public volatile int aJ;
    public volatile int aK;
    public volatile int aL;
    public volatile int aM;
    public int aN = 0;
    public int aO = 100;
    public byte aP;
    public String aQ = null;
    public volatile int aR = 0;
    public boolean aS = true;

    static {
        byte[][] byArrayArray = new byte[][]{{0, 2, 1, 10, 6, 5, 11, 7}, {2, 0, 10, 1, 11, 7, 6, 5}, {1, 10, 0, 2, 7, 11, 5, 6}, {10, 1, 2, 0, 5, 6, 7, 11}, {6, 7, 11, 5, 10, 0, 2, 1}, {5, 11, 7, 6, 0, 10, 1, 2}, {11, 5, 6, 7, 1, 2, 0, 10}, {7, 6, 5, 11, 2, 1, 10, 0}};
    }

    public e(a a2) {
        this.D = a2.c;
        this.aU = (short)a2.e;
        this.u = a2.d;
        this.b = -a2.a[0];
        this.h = -a2.a[1];
        this.a = -a2.a[2];
        this.x = 0;
        this.y = 0;
        this.s = a2.f;
    }

    public e() {
        this.t = "-1";
    }

    public final e a() {
        e e2 = new e();
        new e().t = this.t;
        e2.aD = this.aD;
        e2.ae = this.ae;
        e2.ab = this.ab;
        e2.ag = this.ag;
        e2.ax = this.ax;
        e2.Z = this.Z;
        e2.D = this.D;
        e2.ah = this.ah;
        e2.aU = this.aU;
        e2.u = this.u;
        e2.b = this.b;
        e2.h = this.h;
        e2.a = this.a;
        e2.x = this.x;
        e2.y = this.y;
        e2.s = this.s;
        e2.aR = this.aR;
        e2.af = this.af;
        e2.r = this.r;
        e2.C = this.C;
        if (this.C != null) {
            e2.C = new short[this.C.length];
            System.arraycopy(this.C, 0, e2.C, 0, this.C.length);
        }
        e2.B = this.B;
        if (this.B != null) {
            e2.B = new byte[this.B.length];
            System.arraycopy(this.B, 0, e2.B, 0, this.B.length);
        }
        return e2;
    }

    public final void a(Graphics graphics) {
        this.E.removeAllElements();
        int n = 0;
        while (n < this.u[this.x][this.y].length / 3) {
            short s = this.u[this.x][this.y][n * 3];
            short s2 = this.u[this.x][this.y][n * 3];
            this.L = this.D.b[s][4];
            if (this.L != this.b && this.L != this.h && this.L != this.a) {
                if (this.aP == 0) {
                    this.v = this.af + this.u[this.x][this.y][n * 3 + 1] + this.z;
                    this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                } else if (this.aP == 2) {
                    if (this.D.b[s][5] == 5 || this.D.b[s][5] == 6) {
                        this.v = this.af - this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][3] + this.z;
                        this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    } else {
                        this.v = this.af - this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][2] + this.z;
                        this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    }
                }
                this.D.a(graphics, (int)s2, this.v, this.w, 0, (int)this.aP);
            } else {
                if (this.aP == 0) {
                    this.N = this.af + this.u[this.x][this.y][n * 3 + 1] + this.z;
                    this.O = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    this.M = this.D.b[s][2];
                    this.K = this.D.b[s][3];
                } else if (this.aP == 2) {
                    if (this.D.b[s][5] == 5 || this.D.b[s][5] == 6) {
                        this.N = this.af - this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][3] + this.z;
                        this.O = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                        this.M = this.D.b[s][2];
                        this.K = this.D.b[s][3];
                    } else {
                        this.N = this.af - this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][2] + this.z;
                        this.O = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                        this.M = this.D.b[s][2];
                        this.K = this.D.b[s][3];
                    }
                }
                int[] nArray = new int[]{this.N, this.O, this.M, this.K, this.L};
                this.E.addElement(nArray);
                if (Main.j.c) {
                    if (this.L == this.b) {
                        graphics.setColor(0xFF0000);
                    } else if (this.L == this.h) {
                        graphics.setColor(0xFFFF00);
                    } else if (this.L == this.a) {
                        graphics.setColor(65280);
                    }
                    graphics.drawRect(this.N, this.O, this.M, this.K);
                }
            }
            ++n;
        }
        if (Main.j.c) {
            graphics.setColor(0xF0F0F0);
            graphics.fillRect(this.af + this.z, this.aR + this.A, 10, 10);
            graphics.setColor(0);
            graphics.drawString(this.t, this.af + this.z, this.aR + this.A, 0);
        }
    }

    public final void b(Graphics graphics) {
        int n = 0;
        while (n < this.u[this.x][this.y].length / 3) {
            short s = this.u[this.x][this.y][n * 3];
            short s2 = this.u[this.x][this.y][n * 3];
            this.L = this.D.b[s][4];
            if (this.L != this.b && this.L != this.h && this.L != this.a) {
                if (this.aP == 0) {
                    this.v = this.af + this.u[this.x][this.y][n * 3 + 1] + this.z;
                    this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                } else if (this.aP == 2) {
                    if (this.D.b[s][5] == 5 || this.D.b[s][5] == 6) {
                        this.v = this.af - this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][3] + this.z;
                        this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    } else {
                        this.v = this.af - this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][2] + this.z;
                        this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    }
                }
                this.D.a(this, graphics, s2, this.v, this.w, 0, this.aP);
            } else {
                if (this.aP == 0) {
                    this.N = this.af + this.u[this.x][this.y][n * 3 + 1] + this.z;
                    this.O = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    this.M = this.D.b[s][2];
                    this.K = this.D.b[s][3];
                } else if (this.aP == 2) {
                    if (this.D.b[s][5] == 5 || this.D.b[s][5] == 6) {
                        this.N = this.af - this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][3] + this.z;
                        this.O = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                        this.M = this.D.b[s][2];
                        this.K = this.D.b[s][3];
                    } else {
                        this.N = this.af - this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][2] + this.z;
                        this.O = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                        this.M = this.D.b[s][2];
                        this.K = this.D.b[s][3];
                    }
                }
                int[] nArray = new int[]{this.N, this.O, this.M, this.K, this.L};
                if (this.E.size() == 0 && n == this.u[this.x][this.y].length / 3 - 1) {
                    this.E.addElement(nArray);
                }
                if (Main.j.c) {
                    if (this.L == this.b) {
                        graphics.setColor(0xFF0000);
                    } else if (this.L == this.h) {
                        graphics.setColor(0xFFFF00);
                    } else if (this.L == this.a) {
                        graphics.setColor(65280);
                    }
                    graphics.drawRect(this.N, this.O, this.M, this.K);
                }
            }
            ++n;
        }
        if (Main.j.c) {
            graphics.setColor(0xF0F0F0);
            graphics.fillRect(this.af + this.z, this.aR + this.A, 10, 10);
            graphics.setColor(0);
            graphics.drawString(this.t, this.af + this.z, this.aR + this.A, 0);
        }
    }

    public final void a(Graphics graphics, boolean bl) {
        if (bl) {
            this.z = -rf.g.a[0].t + rf.g.a[0].l;
            this.A = -rf.g.a[0].A + rf.g.a[0].m;
        }
        int n = 0;
        while (n < this.u[this.x][this.y].length / 3) {
            short s = this.u[this.x][this.y][n * 3];
            short s2 = this.u[this.x][this.y][n * 3];
            this.L = this.D.b[s][4];
            if (this.L != this.b && this.L != this.h && this.L != this.a) {
                if (this.aP == 0) {
                    if (this.D.b[s][5] == 6) {
                        this.v = this.af + this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][4] + this.z;
                    } else if (this.D.b[s][5] == 5) {
                        this.v = this.af + this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][3] + this.z;
                        this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    } else if (this.D.b[s][5] == 2) {
                        this.v = this.af + this.u[this.x][this.y][n * 3 + 1] + this.z;
                        this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    } else if (this.D.b[s][5] == 1) {
                        this.v = this.af + this.u[this.x][this.y][n * 3 + 1] + this.z;
                        this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    } else if (this.D.b[s][5] == 11) {
                        this.v = this.af + this.u[this.x][this.y][n * 3 + 1] + this.z;
                        this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    } else if (this.D.b[s][5] == 7) {
                        this.v = this.af + this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][3] + this.z;
                        this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] - this.D.b[s][2] + this.A;
                    } else if (this.D.b[s][5] == 10) {
                        this.v = this.af + this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][2] + this.z;
                        this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] - this.D.b[s][3] + this.A;
                    } else {
                        this.v = this.af + this.u[this.x][this.y][n * 3 + 1] + this.z;
                        this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    }
                } else if (this.aP == 2) {
                    if (this.D.b[s][5] == 5 || this.D.b[s][5] == 6) {
                        this.v = this.af - this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][3] + this.z;
                        this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    } else {
                        this.v = this.af - this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][2] + this.z;
                        this.w = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    }
                }
                this.D.a(this, graphics, s2, this.v, this.w, 0, this.aP);
            } else {
                if (this.aP == 0) {
                    this.N = this.af + this.u[this.x][this.y][n * 3 + 1] + this.z;
                    this.O = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    this.M = this.D.b[s][2];
                    this.K = this.D.b[s][3];
                } else if (this.aP == 2) {
                    if (this.D.b[s][5] == 5 || this.D.b[s][5] == 6) {
                        this.N = this.af - this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][3] + this.z;
                        this.O = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                        this.M = this.D.b[s][2];
                        this.K = this.D.b[s][3];
                    } else {
                        this.N = this.af - this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][2] + this.z;
                        this.O = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                        this.M = this.D.b[s][2];
                        this.K = this.D.b[s][3];
                    }
                }
                int[] nArray = new int[]{this.N, this.O, this.M, this.K, this.L};
                if (this.E.size() == 0 && n == this.u[this.x][this.y].length / 3 - 1) {
                    this.E.addElement(nArray);
                }
                if (Main.j.c) {
                    if (this.L == this.b) {
                        graphics.setColor(0xFF0000);
                    } else if (this.L == this.h) {
                        graphics.setColor(0xFFFF00);
                    } else if (this.L == this.a) {
                        graphics.setColor(65280);
                    }
                    graphics.drawRect(this.N, this.O, this.M, this.K);
                }
            }
            ++n;
        }
        if (Main.j.c) {
            graphics.setColor(0xF0F0F0);
            graphics.fillRect(this.af + this.z, this.aR + this.A, 10, 10);
            graphics.setColor(0);
            graphics.drawString(this.t, this.af + this.z, this.aR + this.A, 0);
        }
    }

    public final void a(int n, boolean bl) {
        this.aO = n;
        if (n > this.aU) {
            System.out.println("-----------\u8bbe\u7f6e\u52a8\u753b" + n + "\u5e8f\u5217!");
            return;
        }
        if (!bl && n == this.x) {
            return;
        }
        System.out.println("St22ate=" + n);
        this.x = (short)n;
        this.y = 0;
    }

    public final void a(int n) {
        this.aO = n;
        this.y = 0;
        this.x = (short)n;
    }

    public final void b() {
        this.E.removeAllElements();
        this.z = -rf.g.a[0].t + rf.g.a[0].l;
        this.A = -rf.g.a[0].A + rf.g.a[0].m;
        int n = 0;
        while (n < this.u[this.x][this.y].length / 3) {
            short s = this.u[this.x][this.y][n * 3];
            boolean bl = false;
            this.L = this.D.b[s][4];
            if (this.L == this.b || this.L == this.h || this.L == this.a) {
                if (this.aP == 0) {
                    this.N = this.af + this.u[this.x][this.y][n * 3 + 1] + this.z;
                    this.O = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                    this.M = this.D.b[s][2];
                    this.K = this.D.b[s][3];
                } else if (this.aP == 2) {
                    if (this.D.b[s][5] == 5 || this.D.b[s][5] == 6) {
                        this.N = this.af - this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][3] + this.z;
                        this.O = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                        this.M = this.D.b[s][2];
                        this.K = this.D.b[s][3];
                    } else {
                        this.N = this.af - this.u[this.x][this.y][n * 3 + 1] - this.D.b[s][2] + this.z;
                        this.O = this.aR + this.u[this.x][this.y][n * 3 + 2] + this.A;
                        this.M = this.D.b[s][2];
                        this.K = this.D.b[s][3];
                    }
                }
                int[] nArray = new int[]{this.N, this.O, this.M, this.K, this.L};
                this.E.addElement(nArray);
            }
            ++n;
        }
    }

    public final void a(int n, int n2, int n3, boolean bl, int n4, int n5) {
        this.g = n;
        this.f = this.aR + n3;
        this.e = this.af + n2;
        this.aI = n4;
        if (this.d <= 0) {
            return;
        }
        System.currentTimeMillis();
        this.d = n5;
    }

    public final boolean c() {
        return this.y == this.u[this.x].length - 1;
    }

    public final void a(int n, int n2) {
        this.af += n;
        this.aR += n2;
        if (this.c != null) {
            this.c.af += n;
            this.c.aR += n2;
        }
    }

    public final void a(boolean bl) {
        if (this.c != null) {
            this.c.a(bl);
        }
        if (this.u[this.x].length <= 1) {
            return;
        }
        if (this.j != 0) {
            if (System.currentTimeMillis() - this.i >= (long)this.j) {
                if (this.y < this.u[this.x].length - 1) {
                    this.y = (short)(this.y + 1);
                } else if (bl) {
                    this.y = 0;
                }
                this.i = System.currentTimeMillis();
            }
            return;
        }
        if (this.y < this.u[this.x].length - 1) {
            this.y = (short)(this.y + 1);
            return;
        }
        if (bl) {
            this.y = 0;
        }
    }

    public final void a(Graphics graphics, int n) {
        if (this.aS) {
            int n2 = 0;
            while (n2 < this.aT) {
                if (this.G[n2] != 0) {
                    graphics.setColor(n >>> 8 * n2);
                    graphics.drawRect(this.af + this.z + this.I[n2], this.aR + this.A + this.J[n2], this.H[n2] - 1, this.F[n2] - 1);
                    graphics.fillRect(this.af + this.z + this.ac, this.aR + this.A + this.ad, 1, 1);
                }
                ++n2;
            }
        }
    }

    public final void a(byte by) {
        if (this.aP != by) {
            this.aP = by;
        }
    }

    public final void b(int n, int n2) {
        this.af = n;
        this.aR = n2;
        if (this.c != null) {
            this.c.aR = this.aR + this.c.f;
            this.c.af = this.af + this.c.e;
        }
    }
}

