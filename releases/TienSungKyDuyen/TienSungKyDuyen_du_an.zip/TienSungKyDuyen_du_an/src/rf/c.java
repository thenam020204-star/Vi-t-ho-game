/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Graphics
 */
package rf;

import Main.j;
import javax.microedition.lcdui.Graphics;
import rf.d;

public final class c {
    public static byte[][] a;
    public static byte b;
    public static byte c;
    public static short d;
    public static short e;
    public static byte[][] f;
    private d g;

    public c(d d2, byte[][] byArray, byte[][] byArray2, int n, int n2) {
        this.g = d2;
        f = byArray;
        e = (short)f[0].length;
        d = (short)f.length;
        a = byArray2;
        c = (byte)n;
        b = (byte)n2;
    }

    protected final void a(Graphics graphics, int n, int n2, int n3, int n4) {
        if (n < 0 || n > f[0].length - 1 || n2 < 0 || n2 > f.length - 1) {
            return;
        }
        try {
            this.g.a(graphics, f[n2][n], n3 * c, n4 * b);
            if (j.c && a[n2][n] != 0) {
                graphics.setColor(0xFF00FF);
                graphics.drawRect(n3 * c, n4 * b, (int)c, (int)b);
                graphics.drawString(a[n2][n] + " ", n3 * c, n4 * b, 0);
            }
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.printStackTrace();
            return;
        }
    }

    protected final void a(Graphics graphics, int n, int n2, int n3, int n4, int n5) {
        graphics.setColor(n5);
        graphics.drawRect(n3 * c, n4 * b, (int)c, (int)b);
    }

    protected final void b(Graphics graphics, int n, int n2, int n3, int n4) {
        if (n < 0 || n > f[0].length - 1 || n2 < 0 || n2 > f.length - 1) {
            return;
        }
        if (f[n2][n] == 0) {
            return;
        }
        this.g.a(graphics, f[n2][n], n3, n4);
    }
}

