/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Font
 *  javax.microedition.lcdui.Graphics
 *  javax.microedition.lcdui.Image
 *  javax.microedition.lcdui.game.Sprite
 *  javax.microedition.rms.RecordStore
 */
package rf;

import Main.d;
import Main.i;
import Main.j;
import Main.k;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Enumeration;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.Sprite;
import javax.microedition.rms.RecordStore;
import rf.e;

public final class b {
    public static Font a;
    public static int b;
    public static String[] c;
    public static String[] d;
    public static int e;
    public static int f;

    static {
        c = new String[100];
        e = 0;
        d = new String[100];
        f = 0;
        a = Font.getFont((int)0, (int)0, (int)8);
        a.stringWidth("\u5979");
        b = a.getHeight();
    }

    public static final int a(Graphics graphics, Image image, int n, int n2, int n3, int n4) {
        int n5 = (n + "").length();
        int n6 = 0;
        while (n6 < n5) {
            int n7 = n / rf.b.a(10, n5 - n6 - 1) % 10;
            rf.b.a(image, image.getWidth() / 10 * n7, 0, image.getWidth() / 10, image.getHeight(), 0, n2 + n6 * (image.getWidth() / 10 + n4), n3, 0, graphics);
            ++n6;
        }
        return n5 * (image.getWidth() / 10 + n4);
    }

    public static final void a(String string, int n) {
        int n2 = 0;
        int n3 = 0;
        StringBuffer stringBuffer = new StringBuffer();
        int n4 = 0;
        while (n4 < e) {
            rf.b.c[n4] = null;
            ++n4;
        }
        e = 0;
        while (n2 + n3 < string.length()) {
            if (a.substringWidth(string, n2, n3 + 1) <= n && string.charAt(n2 + n3) != '^') {
                stringBuffer.append(string.charAt(n2 + n3));
                ++n3;
                continue;
            }
            if (string.charAt(n2 + n3) == '^') {
                rf.b.c[rf.b.e++] = stringBuffer.toString();
                stringBuffer.delete(0, stringBuffer.length());
                n2 += ++n3;
                n3 = 0;
                continue;
            }
            rf.b.c[rf.b.e++] = stringBuffer.toString();
            stringBuffer.delete(0, stringBuffer.length());
            n2 += n3;
            n3 = 0;
        }
    }

    public static final void b(String string, int n) {
        System.out.println("width2=" + n);
        int n2 = 0;
        int n3 = 0;
        StringBuffer stringBuffer = new StringBuffer();
        int n4 = 0;
        while (n4 < f) {
            rf.b.d[n4] = null;
            ++n4;
        }
        f = 0;
        while (n2 + n3 < string.length()) {
            System.out.println("width=" + n);
            if (a.substringWidth(string, n2, n3 + 1) <= n && string.charAt(n2 + n3) != '^') {
                stringBuffer.append(string.charAt(n2 + n3));
                ++n3;
                continue;
            }
            if (string.charAt(n2 + n3) == '^') {
                rf.b.d[rf.b.f++] = stringBuffer.toString();
                stringBuffer.delete(0, stringBuffer.length());
                n2 += ++n3;
                n3 = 0;
                continue;
            }
            rf.b.d[rf.b.f++] = stringBuffer.toString();
            stringBuffer.delete(0, stringBuffer.length());
            n2 += n3;
            n3 = 0;
        }
    }

    public static final Image a(String string) {
        try {
            return Image.createImage((String)string);
        }
        catch (Exception exception) {
            System.out.println("!\u65e0\u6548\u8d44\u6e90\u6587\u4ef6\uff1a" + string);
            return null;
        }
    }

    public static final int b(Graphics graphics, Image image, int n, int n2, int n3, int n4) {
        int n5 = 0;
        if (n >= 100000) {
            n5 = 6;
        } else if (n >= 10000 & n < 1000000) {
            n5 = 5;
        } else if (n >= 1000 & n < 10000) {
            n5 = 4;
        } else if (n >= 100 & n < 1000) {
            n5 = 3;
        } else if (n >= 10 & n < 100) {
            n5 = 2;
        } else if (n >= 0 & n < 10) {
            n5 = 1;
        }
        int n6 = 0;
        while (n6 < n5) {
            rf.b.a(graphics, image, n2 + n6 * (image.getWidth() / 10 + n4), n3, 0 + rf.b.a(n)[n6] * image.getWidth() / 10, 0, image.getWidth() / 10, image.getHeight());
            ++n6;
        }
        return n5 * image.getWidth() / 10;
    }

    public static final void a(Image image, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, Graphics graphics) {
        graphics.drawRegion(image, n, n2, n3, n4, n5, n6, n7, n8);
    }

    public static final void a(Graphics graphics, Image image, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        graphics.getClipX();
        graphics.getClipY();
        int n9 = graphics.getClipWidth();
        int n10 = graphics.getClipHeight();
        int n11 = 0;
        if (n8 == 2) {
            if (n7 == 5) {
                n7 = 18;
            } else if (n7 == 3) {
                n7 = 1;
            } else if (n7 == 6) {
                n7 = 7;
            } else if (n7 == 0) {
                n7 = 2;
            } else if (n7 == 2) {
                n7 = 0;
            } else if (n7 == 1) {
                n7 = 3;
            }
        }
        switch (n7) {
            case 0: {
                graphics.setClip(n5, n6, n3, n4);
                n11 = 0;
                n5 -= n;
                n6 -= n2;
                break;
            }
            case 2: {
                graphics.setClip(n5, n6, n3, n4);
                n11 = 2;
                n5 -= image.getWidth() - n - n3;
                n6 -= n2;
                break;
            }
            case 1: {
                graphics.setClip(n5, n6, n3, n4);
                n11 = 1;
                n5 -= n;
                n6 = n6 - image.getHeight() + n2 + n4;
                break;
            }
            case 5: {
                graphics.setClip(n5, n6, n4, n3);
                n11 = 5;
                n5 -= image.getHeight() - n2 - n4;
                n6 -= n;
                break;
            }
            case 3: {
                graphics.setClip(n5, n6, n3, n4);
                n11 = 3;
                n5 -= image.getWidth() - n - n3;
                n6 -= image.getHeight() - n2 - n4;
                break;
            }
            case 6: {
                graphics.setClip(n5, n6, n4, n3);
                n11 = 6;
                n5 -= n2;
                n6 -= image.getWidth() - n - n3;
                break;
            }
            case 7: {
                graphics.setClip(n5, n6, n4, n3);
                n6 -= image.getWidth() - n - n3;
                n5 -= image.getHeight() - n2 - n4;
                n11 = 7;
                break;
            }
            case 11: 
            case 18: {
                graphics.setClip(n5, n6, n4, n3);
                n5 -= n2;
                n6 -= n;
                n11 = 4;
                break;
            }
            case 10: {
                graphics.setClip(n5, n6, n3, n4);
                n5 -= image.getWidth() - n - n3;
                n6 = n6 - image.getHeight() + n2 + n4;
                n11 = 1;
            }
        }
        Sprite sprite = new Sprite(image);
        sprite.setTransform(n11);
        sprite.setPosition(n5, n6);
        sprite.paint(graphics);
        graphics.setClip(0, 0, n9, n10);
    }

    public static final void a(Graphics graphics, String string, int n, int n2, int n3, int n4, int n5) {
        graphics.setFont(Font.getFont((int)64, (int)0, (int)8));
        if (n3 == n4) {
            graphics.setColor(n3);
            graphics.drawString(string, n, n2, n5);
            return;
        }
        graphics.setColor(n3);
        graphics.drawString(string, n + 1, n2, n5);
        graphics.drawString(string, n - 1, n2, n5);
        graphics.drawString(string, n, n2 + 1, n5);
        graphics.drawString(string, n, n2 - 1, n5);
        graphics.drawString(string, n + 1, n2 + 1, n5);
        graphics.drawString(string, n - 1, n2 - 1, n5);
        graphics.drawString(string, n + 1, n2 - 1, n5);
        graphics.drawString(string, n - 1, n2 + 1, n5);
        graphics.setColor(n4);
        graphics.drawString(string, n, n2, n5);
    }

    static final int[] a(int n) {
        int[] nArray;
        if (n >= 100000) {
            int[] nArray2 = new int[6];
            nArray = nArray2;
            nArray2[0] = n / 100000;
            nArray[1] = n % 100000 / 10000;
            nArray[2] = n % 100000 % 10000 / 1000;
            nArray[3] = n % 100000 % 10000 % 1000 / 100;
            nArray[4] = n % 100000 % 10000 % 1000 % 100 / 10;
            nArray[5] = n % 100000 % 10000 % 1000 % 100 % 10;
        } else if (n >= 10000) {
            int[] nArray3 = new int[5];
            nArray = nArray3;
            nArray3[0] = n / 10000;
            nArray[1] = n % 10000 / 1000;
            nArray[2] = n % 10000 % 1000 / 100;
            nArray[3] = n % 10000 % 1000 % 100 / 10;
            nArray[4] = n % 10000 % 1000 % 100 % 10;
        } else if (n >= 1000 && n < 10000) {
            int[] nArray4 = new int[4];
            nArray = nArray4;
            nArray4[0] = n / 1000;
            nArray[1] = n % 1000 / 100;
            nArray[2] = n % 1000 % 100 / 10;
            nArray[3] = n % 1000 % 100 % 10;
        } else if (n >= 100 && n < 1000) {
            int[] nArray5 = new int[3];
            nArray = nArray5;
            nArray5[0] = n / 100;
            nArray[1] = n % 100 / 10;
            nArray[2] = n % 100 % 10 / 1;
        } else if (n >= 10 && n < 100) {
            int[] nArray6 = new int[2];
            nArray = nArray6;
            nArray6[0] = n / 10;
            nArray[1] = n % 10 / 1;
        } else {
            int[] nArray7 = new int[1];
            nArray = nArray7;
            nArray7[0] = n;
        }
        return nArray;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Loose catch block
     */
    public static final void a() {
        RecordStore recordStore;
        block19: {
            DataInputStream dataInputStream;
            ByteArrayInputStream byteArrayInputStream;
            byte[] byArray;
            block17: {
                block18: {
                    byArray = null;
                    byteArrayInputStream = null;
                    dataInputStream = null;
                    recordStore = null;
                    recordStore = RecordStore.openRecordStore((String)"xianchong1", (boolean)true);
                    if (recordStore.getNumRecords() != 0) break block17;
                    System.out.println("=yyyyyyyyyyyyyyyyy111");
                    if (recordStore == null) break block18;
                    try {
                        recordStore.closeRecordStore();
                        return;
                    }
                    catch (Exception exception) {
                        Exception exception2 = exception;
                        exception.printStackTrace();
                    }
                }
                return;
            }
            System.out.println("=@@@@@@@@@rr");
            byArray = recordStore.getRecord(1);
            byteArrayInputStream = new ByteArrayInputStream(byArray);
            dataInputStream = new DataInputStream(byteArrayInputStream);
            int n = 0;
            while (n < j.cM.length) {
                j.cM[n] = dataInputStream.readUTF();
                ++n;
            }
            j.bt = dataInputStream.readInt();
            if (j.bt != 1) {
                j.bt = 2;
            }
            if ((j.bK = dataInputStream.readInt()) != 1) {
                j.bK = 2;
            }
            if (recordStore == null) break block19;
            try {
                recordStore.closeRecordStore();
            }
            catch (Exception exception) {
                Exception exception3 = exception;
                exception.printStackTrace();
            }
        }
        return;
        catch (Exception exception) {
            block20: {
                try {
                    Exception exception4 = exception;
                    exception.printStackTrace();
                    if (recordStore == null) break block20;
                }
                catch (Throwable throwable) {
                    if (recordStore != null) {
                        try {
                            recordStore.closeRecordStore();
                        }
                        catch (Exception exception5) {
                            Exception exception6 = exception5;
                            exception5.printStackTrace();
                        }
                    }
                    throw throwable;
                }
                try {
                    recordStore.closeRecordStore();
                }
                catch (Exception exception7) {
                    Exception exception8 = exception7;
                    exception7.printStackTrace();
                }
            }
            return;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Loose catch block
     */
    public static final void b(String string) {
        RecordStore recordStore;
        block32: {
            int n;
            int n2;
            DataInputStream dataInputStream;
            ByteArrayInputStream byteArrayInputStream;
            byte[] byArray;
            block30: {
                block31: {
                    byArray = null;
                    byteArrayInputStream = null;
                    dataInputStream = null;
                    recordStore = null;
                    recordStore = RecordStore.openRecordStore((String)string, (boolean)true);
                    if (recordStore.getNumRecords() != 0) break block30;
                    if (recordStore == null) break block31;
                    try {
                        recordStore.closeRecordStore();
                        return;
                    }
                    catch (Exception exception) {
                        Exception exception2 = exception;
                        exception.printStackTrace();
                    }
                }
                return;
            }
            byArray = recordStore.getRecord(1);
            byteArrayInputStream = new ByteArrayInputStream(byArray);
            dataInputStream = new DataInputStream(byteArrayInputStream);
            int n3 = 0;
            while (n3 < j.cY.length) {
                j.cY[n3] = new e();
                ++n3;
            }
            int n4 = 0;
            while (n4 < j.cY.length) {
                j.cY[n4].ag = dataInputStream.readInt();
                j.cY[n4].ax = dataInputStream.readInt();
                j.cY[n4].Z = dataInputStream.readInt();
                j.cY[n4].aD = dataInputStream.readInt();
                j.cY[n4].t = dataInputStream.readUTF();
                j.cY[n4].ae = dataInputStream.readInt();
                j.cY[n4].ab = dataInputStream.readInt();
                j.cY[n4].an = dataInputStream.readBoolean();
                if (!j.cY[n4].t.equals("-1")) {
                    j.l().g(j.cY[n4]);
                }
                ++n4;
            }
            int n5 = 0;
            while (n5 < j.cZ.length) {
                j.cZ[n5] = new e();
                ++n5;
            }
            int n6 = 0;
            while (n6 < j.cZ.length) {
                j.cZ[n6].ag = dataInputStream.readInt();
                j.cZ[n6].ax = dataInputStream.readInt();
                j.cZ[n6].Z = dataInputStream.readInt();
                j.cZ[n6].aD = dataInputStream.readInt();
                j.cZ[n6].t = dataInputStream.readUTF();
                j.cZ[n6].ae = dataInputStream.readInt();
                j.cZ[n6].ab = dataInputStream.readInt();
                j.cZ[n6].an = dataInputStream.readBoolean();
                if (!j.cZ[n6].t.equals("-1")) {
                    j.l().g(j.cZ[n6]);
                }
                ++n6;
            }
            int n7 = 0;
            while (n7 < j.h.length) {
                n2 = 0;
                while (n2 < j.h[n7].length) {
                    j.h[n7][n2] = dataInputStream.readInt();
                    ++n2;
                }
                ++n7;
            }
            n2 = 0;
            while (n2 < j.h.length) {
                if (j.h[n2][0] != -1) {
                    j.e = n2;
                    break;
                }
                ++n2;
            }
            int n8 = 0;
            while (n8 < j.ca.length) {
                j.ca[n8] = dataInputStream.readByte();
                ++n8;
            }
            int n9 = dataInputStream.readInt();
            Enumeration enumeration = j.o.keys();
            while (enumeration.hasMoreElements()) {
                String string2 = (String)enumeration.nextElement();
                j.o.put(string2, "0");
            }
            int n10 = 0;
            while (n10 < n9) {
                String string3 = dataInputStream.readUTF();
                String string4 = dataInputStream.readUTF();
                j.o.put(string3, string4);
                System.out.println("ssss44=" + string3 + ":" + string4);
                ++n10;
            }
            j.cN = j.cQ = dataInputStream.readUTF();
            System.out.println("FFG=" + j.cN);
            j.dB.removeAllElements();
            n9 = dataInputStream.readInt();
            System.out.println("len=" + n9);
            int n11 = 0;
            while (n11 < n9) {
                int n12 = dataInputStream.readInt();
                n = dataInputStream.readInt();
                System.out.println("@@@=" + n11 + ":" + n12 + ":" + n);
                d d2 = new d(n12, n);
                j.dB.addElement(d2);
                ++n11;
            }
            j.dC.removeAllElements();
            n9 = dataInputStream.readInt();
            int n13 = 0;
            while (n13 < n9) {
                i i2 = new i(dataInputStream.readInt(), dataInputStream.readInt());
                j.dC.addElement(i2);
                ++n13;
            }
            n = 0;
            while (n < k.J.length) {
                k.J[n][2] = dataInputStream.readUTF();
                ++n;
            }
            j.cF[0] = dataInputStream.readInt();
            j.cF[1] = dataInputStream.readInt();
            j.cy = dataInputStream.readInt();
            j.bT = true;
            if (recordStore == null) break block32;
            try {
                recordStore.closeRecordStore();
            }
            catch (Exception exception) {
                Exception exception3 = exception;
                exception.printStackTrace();
            }
        }
        return;
        catch (Exception exception) {
            block33: {
                try {
                    Exception exception4 = exception;
                    exception.printStackTrace();
                    if (recordStore == null) break block33;
                }
                catch (Throwable throwable) {
                    if (recordStore != null) {
                        try {
                            recordStore.closeRecordStore();
                        }
                        catch (Exception exception5) {
                            Exception exception6 = exception5;
                            exception5.printStackTrace();
                        }
                    }
                    throw throwable;
                }
                try {
                    recordStore.closeRecordStore();
                }
                catch (Exception exception7) {
                    Exception exception8 = exception7;
                    exception7.printStackTrace();
                }
            }
            return;
        }
    }

    public static final void b() {
        RecordStore recordStore = null;
        try {
            System.out.println("=*****************************************");
            recordStore = RecordStore.openRecordStore((String)"xianchong1", (boolean)true);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
            int n = 0;
            while (n < j.cM.length) {
                dataOutputStream.writeUTF(j.cM[n]);
                ++n;
            }
            dataOutputStream.writeInt(j.bt);
            dataOutputStream.writeInt(j.bK);
            byte[] byArray = byteArrayOutputStream.toByteArray();
            if (recordStore.getNumRecords() == 0) {
                recordStore.addRecord(byArray, 0, byArray.length);
            } else {
                recordStore.setRecord(1, byArray, 0, byArray.length);
            }
            recordStore.closeRecordStore();
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.printStackTrace();
            return;
        }
    }

    public static final void c(String string) {
        RecordStore recordStore = null;
        try {
            Object object;
            int n;
            recordStore = RecordStore.openRecordStore((String)string, (boolean)true);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
            int n2 = 0;
            while (n2 < j.cY.length) {
                dataOutputStream.writeInt(j.cY[n2].ag);
                dataOutputStream.writeInt(j.cY[n2].ax);
                dataOutputStream.writeInt(j.cY[n2].Z);
                dataOutputStream.writeInt(j.cY[n2].aD);
                dataOutputStream.writeUTF(j.cY[n2].t);
                dataOutputStream.writeInt(j.cY[n2].ae);
                dataOutputStream.writeInt(j.cY[n2].ab);
                dataOutputStream.writeBoolean(j.cY[n2].an);
                ++n2;
            }
            int n3 = 0;
            while (n3 < j.cZ.length) {
                dataOutputStream.writeInt(j.cZ[n3].ag);
                dataOutputStream.writeInt(j.cZ[n3].ax);
                dataOutputStream.writeInt(j.cZ[n3].Z);
                dataOutputStream.writeInt(j.cZ[n3].aD);
                dataOutputStream.writeUTF(j.cZ[n3].t);
                dataOutputStream.writeInt(j.cZ[n3].ae);
                dataOutputStream.writeInt(j.cZ[n3].ab);
                dataOutputStream.writeBoolean(j.cZ[n3].an);
                ++n3;
            }
            int n4 = 0;
            while (n4 < j.h.length) {
                n = 0;
                while (n < j.h[n4].length) {
                    dataOutputStream.writeInt(j.h[n4][n]);
                    ++n;
                }
                ++n4;
            }
            n = 0;
            while (n < j.ca.length) {
                dataOutputStream.writeByte(j.ca[n]);
                ++n;
            }
            Enumeration enumeration = j.o.keys();
            dataOutputStream.writeInt(j.o.size());
            while (enumeration.hasMoreElements()) {
                object = (String)enumeration.nextElement();
                dataOutputStream.writeUTF((String)object);
                dataOutputStream.writeUTF((String)j.o.get(object));
                System.out.println("person=" + (String)j.o.get(object) + ":" + (String)object);
            }
            dataOutputStream.writeUTF(j.cN);
            dataOutputStream.writeInt(j.dB.size());
            int n5 = 0;
            while (n5 < j.dB.size()) {
                object = (d)j.dB.elementAt(n5);
                dataOutputStream.writeInt(((d)object).b);
                dataOutputStream.writeInt(((d)object).a);
                System.out.println("i=" + ((d)object).b + ":" + ((d)object).a);
                ++n5;
            }
            dataOutputStream.writeInt(j.dC.size());
            int n6 = 0;
            while (n6 < j.dC.size()) {
                i i2 = (i)j.dC.elementAt(n6);
                dataOutputStream.writeInt(i2.b);
                dataOutputStream.writeInt(i2.a);
                ++n6;
            }
            int n7 = 0;
            while (n7 < k.J.length) {
                dataOutputStream.writeUTF(k.J[n7][2]);
                ++n7;
            }
            dataOutputStream.writeInt(j.u[j.q].af);
            dataOutputStream.writeInt(j.u[j.q].aR);
            dataOutputStream.writeInt(j.cy);
            byte[] byArray = byteArrayOutputStream.toByteArray();
            if (recordStore.getNumRecords() == 0) {
                recordStore.addRecord(byArray, 0, byArray.length);
            } else {
                recordStore.setRecord(1, byArray, 0, byArray.length);
            }
            recordStore.closeRecordStore();
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.printStackTrace();
            return;
        }
    }

    public static final Image a(Image image, int n, int n2) {
        int n3 = image.getWidth();
        int n4 = image.getHeight();
        Image image2 = Image.createImage((int)n, (int)n4);
        Graphics graphics = image2.getGraphics();
        int n5 = (n3 << 16) / n;
        int n6 = n5 / 2;
        int n7 = 0;
        while (n7 < n) {
            graphics.setClip(n7, 0, 1, n4);
            graphics.drawImage(image, n7 - (n6 >> 16), 0, 20);
            n6 += n5;
            ++n7;
        }
        Image image3 = Image.createImage((int)n, (int)n2);
        graphics = image3.getGraphics();
        n5 = (n4 << 16) / n2;
        n6 = n5 / 2;
        int n8 = 0;
        while (n8 < n2) {
            graphics.setClip(0, n8, n, 1);
            graphics.drawImage(image2, 0, n8 - (n6 >> 16), 20);
            n6 += n5;
            ++n8;
        }
        return image3;
    }

    public static final void a(Graphics graphics, Image image, int n, int n2, int n3, int n4, int n5, int n6) {
        int n7 = graphics.getClipX();
        int n8 = graphics.getClipY();
        int n9 = graphics.getClipWidth();
        int n10 = graphics.getClipHeight();
        graphics.setClip(n, n2, n5, n6);
        graphics.clipRect(n, n2, n5, n6);
        graphics.drawImage(image, n - n3, n2 - n4, 0);
        graphics.setClip(n7, n8, n9, n10);
    }

    public static final int a(int n, int n2) {
        int n3 = n;
        int n4 = 1;
        while (n4 < n2) {
            n3 *= n;
            ++n4;
        }
        if (n2 == 0) {
            return 1;
        }
        return n3;
    }
}

