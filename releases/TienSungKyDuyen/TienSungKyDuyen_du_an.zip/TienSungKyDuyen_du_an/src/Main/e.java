/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Font
 *  javax.microedition.lcdui.Graphics
 *  javax.microedition.lcdui.Image
 */
package Main;

import Main.a;
import Main.j;
import Main.k;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import rf.b;

public final class e
implements k {
    static Font a;
    static int b;
    int c;
    int d = 4;
    static byte[] e;
    public static int f;
    int g;
    public static int h;
    static int i;
    public static e j;

    static {
        f = 36;
        i = 1;
        e = new byte[k.E.length];
        a = Font.getFont((int)0, (int)0, (int)8);
        a.stringWidth("\u5979");
        b = a.getHeight();
    }

    public final void a(Graphics graphics, int n, int n2, int n3, int n4, int n5, int n6, int n7, boolean bl) {
        graphics.setColor(n5);
        graphics.fillRect(n + 2, n2 + 2, n3 - 2, n4 - 2);
        graphics.setColor(n6);
        graphics.drawRect(n + 1, n2 + 1, n3 - 2, n4 - 2);
        graphics.setColor(n7);
        graphics.drawRect(n + 2, n2 + 2, n3 - 4, n4 - 4);
        graphics.drawRect(n + 3, n2 + 3, n3 - 6, n4 - 6);
    }

    final void a(Graphics graphics, Image image, int n, int n2, int n3, int n4) {
        int n5 = image.getWidth() / 2;
        int n6 = image.getHeight() / 2;
        Main.j.b(graphics, image, n, n2, 0, 0, n5, n6);
        Main.j.b(graphics, image, n + n3 - n5, n2, n5, 0, n5, n6);
        Main.j.b(graphics, image, n, n2 + n4 - n6, 0, n6, n5, n6);
        Main.j.b(graphics, image, n + n3 - n5, n2 + n4 - n6, n5, n6, n5, n6);
    }

    public final void a(Graphics graphics, Image image, int n, int n2, int n3, int n4, boolean bl, int n5, int n6, int n7) {
        this.a(graphics, n, n2, n3, n4, n5, n6, n7, bl);
        if (image != null) {
            this.a(graphics, image, n, n2, n3, n4);
        }
    }

    public final int a(Graphics graphics, String[][] stringArray, int n, int n2, int n3, int n4, int n5, int n6, boolean bl, int n7) {
        graphics.setFont(a);
        int n8 = 0;
        int n9 = 0;
        int n10 = 0;
        n9 = n5 / stringArray.length;
        n8 = stringArray.length;
        if (n9 < b + 10) {
            n9 = b + 10;
            n8 = n5 / n9;
            n10 = stringArray.length / n8;
            if (stringArray.length % n8 == 0 && n10 != 0) {
                --n10;
            }
        }
        this.g = n6 / n8;
        int n11 = n8 + this.g * n8;
        if (this.g == n10 && stringArray.length % n8 != 0) {
            n11 = this.g * n8 + stringArray.length % n8;
        }
        int n12 = 0;
        int n13 = 0;
        if (this.d * this.c < n4 + 20) {
            ++this.c;
        }
        int n14 = 0 + this.g * n8;
        while (n14 < n11) {
            n12 = bl ? n2 + n4 / 2 - a.stringWidth(stringArray[n14][n]) / 2 : n2 + 18;
            n13 = n3 + n9 / 2 - b / 2 + n9 * (n14 - this.g * n8);
            switch (n7) {
                case 0: {
                    if (n14 == n6) {
                        graphics.setColor(15697266);
                        graphics.fillRect(n2 + 4, n13 - 2, n4 - 8, b + 4);
                    }
                    graphics.setColor(0xFFFFFF);
                    graphics.drawString(stringArray[n14][n], n12, n13, 0);
                    break;
                }
                case 1: {
                    if (n14 == n6) {
                        Main.j.N[0].b(n12, n13 + 17);
                        Main.j.N[0].b(graphics);
                        Main.j.N[0].a(false);
                    }
                    graphics.setColor(7685632);
                    graphics.drawString(stringArray[n14][n], n12, n13, 0);
                    boolean bl2 = false;
                    int n15 = n12 + a.stringWidth(stringArray[0][0]) + 20;
                    int n16 = n13;
                    int n17 = Main.j.aM.getWidth();
                    int n18 = Main.j.aM.getHeight();
                    if (!bl) {
                        Main.j.b(graphics, Main.j.aM, n15, n16 + k.v / 2 - n18 / 2, 0, 0, n17 / 2, n18);
                        int n19 = n15 + n17 / 2 + 5;
                        graphics.drawString("" + e[n14], n19, n13, 0);
                        Main.j.b(graphics, Main.j.aM, n19 += a.stringWidth(String.valueOf(e[n14])) + 5, n16 + k.v / 2 - n18 / 2, n17 / 2, 0, n17 / 2, n18);
                        graphics.drawString(stringArray[n14][2], n19 + n17 / 2 + 2, n13, 0);
                    }
                    if (Main.j.dp != 6 || Main.j.dr != 0 || n14 >= Main.j.dq - 1) break;
                    graphics.drawImage(Main.j.aY, 150, n16 + k.v / 2 - n18 / 2 - Main.j.aY.getHeight() / 2, 0);
                }
            }
            ++n14;
        }
        if (!bl) {
            if (Main.a.d().l() && !Main.j.bW) {
                if (--i < 1) {
                    i = 1;
                }
                Main.e.e[n6] = (byte)i;
            } else if (Main.a.d().v() && !Main.j.bW) {
                if (i < 9) {
                    ++i;
                }
                Main.e.e[n6] = (byte)i;
            }
        }
        return n9;
    }

    public final void a(Graphics graphics, String[] stringArray, int n, int n2, int n3, int n4, int n5, boolean bl, int n6) {
        graphics.setFont(a);
        int n7 = 0;
        int n8 = 0;
        int n9 = 0;
        int n10 = 10;
        if (n6 == 2) {
            n10 = 5;
        }
        n8 = n4 / stringArray.length;
        n7 = stringArray.length;
        if (n8 < b + n10) {
            n8 = b + n10;
            n7 = n4 / n8;
            n9 = stringArray.length / n7;
            if (stringArray.length % n7 == 0 && n9 != 0) {
                --n9;
            }
        }
        this.g = n5 / n7;
        int n11 = n7 + this.g * n7;
        if (this.g == n9 && stringArray.length % n7 != 0) {
            n11 = this.g * n7 + stringArray.length % n7;
        }
        int n12 = 0;
        int n13 = 0;
        if (this.d * this.c < n3 + 20) {
            ++this.c;
        }
        int n14 = 0 + this.g * n7;
        while (n14 < n11) {
            n12 = bl ? n + n3 / 2 - a.stringWidth(stringArray[n14]) / 2 : n;
            n13 = n2 + n8 / 2 - b / 2 + n8 * (n14 - this.g * n7);
            switch (n6) {
                case 0: {
                    if (Main.j.df != 4 && n14 == n5) {
                        graphics.setColor(15697266);
                        graphics.fillRect(n + 4, n13 - 2, n3 - 8, b + 4);
                    }
                    graphics.setColor(0xFFFFFF);
                    graphics.drawString(stringArray[n14], n12, n13, 0);
                    break;
                }
                case 1: {
                    if (n14 == n5) {
                        Main.j.N[0].b(n12, n13 + 17);
                        Main.j.N[0].b(graphics);
                        Main.j.N[0].a(false);
                    }
                    graphics.setColor(7685632);
                    graphics.drawString(stringArray[n14], n12, n13, 0);
                    break;
                }
                case 2: {
                    n12 += 15;
                    int n15 = 0;
                    if (Main.j.t == 320) {
                        n15 = 44;
                    }
                    String[] stringArray2 = new String[]{"\u4e00:", "\u4e8c:", "\u4e09:"};
                    if (n14 == n5) {
                        int n16 = Main.j.aM.getWidth();
                        int n17 = Main.j.aM.getHeight();
                        Main.j.b(graphics, Main.j.aM, n12 - n16 / 2 - 4, n13 + k.v / 2 - n17 / 2, 0, 0, n16 / 2, n17);
                        Main.j.b(graphics, Main.j.aM, n12 + a.stringWidth(stringArray[n14]) + 4, n13 + k.v / 2 - n17 / 2, n16 / 2, 0, n16 / 2, n17);
                    }
                    graphics.setColor(7685632);
                    graphics.drawString(stringArray2[n14], 30 + n15, n13, 0);
                    graphics.drawString(stringArray[n14], n12, n13, 0);
                }
            }
            ++n14;
        }
    }

    public final void a(Graphics graphics, int[] nArray, int n, int n2, int n3, int n4) {
        graphics.setFont(a);
        int n5 = 0;
        int n6 = 0;
        int n7 = 0;
        n6 = n3 / nArray.length;
        n5 = nArray.length;
        if (n6 < b + 10) {
            n6 = b + 10;
            n5 = n3 / n6;
            n7 = nArray.length / n5;
            if (nArray.length % n5 == 0 && n7 != 0) {
                --n7;
            }
        }
        this.g = n4 / n5;
        int n8 = n5 + this.g * n5;
        if (this.g == n7 && nArray.length % n5 != 0) {
            n8 = this.g * n5 + nArray.length % n5;
        }
        int n9 = n;
        int n10 = 0;
        int n11 = 0 + this.g * n5;
        while (n11 < n8) {
            n10 = n2 + n6 / 2 - b / 2 + n6 * (n11 - this.g * n5);
            if (nArray[n11] != -1) {
                graphics.drawImage(Main.j.cl[nArray[n11]], n9, n10, 0);
            }
            ++n11;
        }
    }

    public final int[] a(Graphics graphics, Image image, int n, int n2, int n3, int n4, int n5, int n6) {
        graphics.setFont(a);
        int n7 = 0;
        int n8 = 0;
        int n9 = 0;
        int n10 = image.getHeight() / n;
        n8 = n5 / n;
        n7 = n;
        if (n8 < n10 + 5) {
            n8 = n10 + 5;
            n7 = n5 / n8;
            n9 = n / n7;
            if (n % n7 == 0 && n9 != 0) {
                --n9;
            }
        }
        this.g = n6 / n7;
        int n11 = n7 + this.g * n7;
        if (this.g == n9 && n % n7 != 0) {
            n11 = this.g * n7 + n % n7;
        }
        int n12 = 0;
        n12 = n2;
        int n13 = 0;
        n13 = n3 + n8 / 2;
        if (this.d * this.c < n4 + 20) {
            ++this.c;
        }
        int n14 = 0 + this.g * n7;
        while (n14 < n11) {
            graphics.setColor(0xFFFFFF);
            n12 = n2 + n4 / 2 - image.getWidth() / 2;
            n13 = n3 + n8 / 2 - "ui_select".length() / 2 + n8 * (n14 - this.g * n7);
            if (n14 == n6 && Main.j.ac == 0) {
                Main.j.N[0].b(n12 + 4, n13 + 17 + 1);
                Main.j.N[0].b(graphics);
                Main.j.N[0].a(false);
            }
            Main.j.b(graphics, image, n12, n13, 0, n14 * n10, image.getWidth(), n10);
            ++n14;
        }
        int[] nArray = new int[]{n12, n13};
        return nArray;
    }

    public final void a(Graphics graphics, int n, int n2, int n3, int n4) {
        if (Main.j.a != null) {
            graphics.drawRGB(Main.j.a, 0, n3, n, n2, n3, n4, true);
            return;
        }
        graphics.setColor(0);
        graphics.fillRect(n, n2, n3, n4);
    }

    public static final e a() {
        if (j == null) {
            j = new e();
        }
        return j;
    }

    public final void b(Graphics graphics, int n, int n2, int n3, int n4) {
        if (n4 == 0) {
            graphics.drawImage(Main.j.P[16], n2, n3, 0);
        }
        Main.j.b(graphics, Main.j.P[17], n2, n3, 0, n * Main.j.P[17].getHeight() / 3, Main.j.P[17].getWidth(), Main.j.P[17].getHeight() / 3);
    }

    final void a(Graphics graphics, int n, int n2, int n3, int n4, int n5) {
        if (n3 > n4) {
            n3 = n4;
        }
        int n6 = n3 * f / n4;
        boolean bl = false;
        graphics.setColor(0x393439);
        graphics.fillRect(n, n2, f, 4);
        if (n5 == 0) {
            graphics.setColor(16750236);
            graphics.fillRect(n, n2, n6, 1);
            graphics.setColor(0xFF555A);
            graphics.fillRect(n, n2 + 1, n6, 2);
            graphics.setColor(12403511);
            graphics.fillRect(n, n2 + 3, n6, 1);
            return;
        }
        if (n5 == 1) {
            graphics.setColor(0xCEEFFF);
            graphics.fillRect(n, n2, n6, 1);
            graphics.setColor(5930495);
            graphics.fillRect(n, n2 + 1, n6, 2);
            graphics.setColor(1588413);
            graphics.fillRect(n, n2 + 3, n6, 1);
            return;
        }
        if (n5 == 2) {
            graphics.setColor(11269545);
            graphics.fillRect(n, n2, n6, 1);
            graphics.setColor(973064);
            graphics.fillRect(n, n2 + 1, n6, 2);
            graphics.setColor(688135);
            graphics.fillRect(n, n2 + 3, n6, 1);
        }
    }

    public final void a(Graphics graphics, String string) {
        int n = Main.j.t - 40;
        int n2 = 0;
        if (Main.j.bF) {
            rf.b.b(string + "^", n - 10);
            Main.j.bF = false;
        }
        n2 = rf.b.f * (k.v + 10);
        int n3 = Main.j.t / 2 - n / 2;
        int n4 = Main.j.s / 2 - n2 / 2;
        graphics.setClip(0, 0, Main.j.t, Main.j.s);
        this.a(graphics, Main.j.P[0], 0, n4, Main.j.t, n2, false, 0xFFFFFF, 11499058, 15709554);
        Main.j.l().b(graphics, string, n, n2, n3 + 10, n4 + 5, 7685632);
    }

    final void b(Graphics graphics, Image image, int n, int n2, int n3, int n4) {
        int n5 = image.getWidth() / 12;
        int n6 = image.getHeight();
        int n7 = Main.j.P[20].getWidth() / 6;
        int n8 = Main.j.P[20].getHeight();
        if (image == Main.j.P[23]) {
            n5 = image.getWidth() / 5;
        }
        Main.j.b(graphics, Main.j.P[20], n, n2, n7 * n4, 0, n7, n8);
        int n9 = n + n7 / 2 - n5 / 2;
        int n10 = n2 + n8 / 2 - n6 / 2;
        Main.j.b(graphics, image, n9, n10, n3 * n5, 0, n5, n6);
    }

    public final void a(Graphics graphics, int n, int n2, int n3) {
        int n4 = Main.j.P[13].getWidth();
        int n5 = Main.j.P[13].getHeight();
        boolean bl = false;
        graphics.drawImage(Main.j.P[13], n, n2, 0);
        graphics.drawImage(Main.j.P[13], n + n3 - n4, n2, 0);
        graphics.setColor(0xFFEFDE);
        graphics.fillRect(n + n4, n2 + 6, n3 - n4 * 2, n5 - 12);
        graphics.setColor(5321759);
        graphics.drawRect(n + n4, n2 + 6, n3 - n4 * 2, n5 - 12);
        graphics.setColor(13947080);
        graphics.drawRect(n + n4 + 1, n2 + 6 + 1, n3 - n4 * 2 - 2, n5 - 12 - 2);
        graphics.setColor(15709555);
        graphics.drawRect(n + n4 + 2, n2 + 6 + 2, n3 - n4 * 2 - 4, n5 - 12 - 4);
    }

    public final void a(Graphics graphics, int n, int n2, String string) {
        int n3 = Main.j.t - 20;
        boolean bl = false;
        if (Main.j.bE) {
            rf.b.a(string + "^", n3 - 10);
            Main.j.bE = false;
        }
        graphics.setClip(0, 0, Main.j.t, Main.j.s);
        this.a(graphics, Main.j.P[0], 0, 0, Main.j.t, Main.j.s, false, 0xFFFFFF, 11499058, 15709554);
        if (Main.j.cX == 4) {
            String[] stringArray = new String[]{"\u6781\u54c1\u9752\u9f99", "\u521d\u7ea7\u9752\u9f99"};
            int n4 = 0;
            while (n4 < stringArray.length) {
                graphics.drawString(stringArray[n4], Main.j.t / 2 - a.stringWidth(stringArray[n4]) / 2, 5 + (k.v + 10) * n4, 0);
                ++n4;
            }
            graphics.setColor(0xFF0000);
            graphics.drawString(stringArray[h], Main.j.t / 2 - a.stringWidth(stringArray[h]) / 2, 5 + (k.v + 10) * h, 0);
            Main.j.l().a(graphics, string, Main.j.t, Main.j.s - 20 - 100, n, 100, 7685632);
            if (Main.a.d().x()) {
                h = h > 0 ? --h : stringArray.length - 1;
                Main.j.bE = true;
            } else if (Main.a.d().f()) {
                h = h < stringArray.length - 1 ? ++h : 0;
                Main.j.bE = true;
            }
            return;
        }
        Main.j.l().a(graphics, string, Main.j.t, Main.j.s - 30, n, n2, 7685632);
    }

    public final void b(Graphics graphics, int n, int n2, int n3) {
        if (Main.j.p == 2) {
            graphics.setColor(0xFFF9EF);
            graphics.fillRect(0, 0, Main.j.t, Main.j.s);
            graphics.setColor(0xCC9900);
            graphics.drawRect(0, 0, Main.j.t - 1, Main.j.s - 1);
            graphics.setColor(16763695);
            graphics.drawRect(1, 1, Main.j.t - 3, Main.j.s - 3);
            return;
        }
        int n4 = n3 / Main.j.P[14].getHeight();
        boolean bl = false;
        if (n3 % Main.j.P[14].getHeight() != 0) {
            ++n4;
        }
        graphics.setColor(0xFFF9EF);
        graphics.fillRect(n + 7 + Main.j.P[14].getWidth(), n2 + Main.j.P[12].getHeight(), Main.j.P[12].getWidth() - 14 - Main.j.P[14].getWidth() * 2, n4 * Main.j.P[14].getHeight());
        if (Main.j.t != 320) {
            graphics.drawImage(Main.j.P[12], n, n2, 0);
        }
        n2 += Main.j.P[12].getHeight();
        int n5 = n + 7;
        int n6 = n5 - 7 + Main.j.P[12].getWidth() - 7 - Main.j.P[14].getWidth();
        int n7 = 0;
        while (n7 < n4) {
            graphics.drawImage(Main.j.P[14], n5, n2 + n7 * Main.j.P[14].getHeight(), 0);
            Main.j.a(graphics, Main.j.P[14], n6, n2 + n7 * Main.j.P[14].getHeight(), 0, 0, Main.j.P[14].getWidth(), Main.j.P[14].getHeight());
            ++n7;
        }
        if (Main.j.t != 320) {
            graphics.drawRegion(Main.j.P[12], 0, 0, Main.j.P[12].getWidth(), Main.j.P[12].getHeight(), 1, n, n2 + n4 * Main.j.P[14].getHeight(), 0);
            Main.j.b(graphics, Main.j.P[10], n + 12, n2 + n4 * Main.j.P[14].getHeight(), 0, 0, Main.j.P[10].getWidth() / 2, Main.j.P[10].getHeight());
            Main.j.b(graphics, Main.j.P[10], n + Main.j.P[12].getWidth() - 12 - Main.j.P[10].getWidth() / 2, n2 + n4 * Main.j.P[14].getHeight(), Main.j.P[10].getWidth() / 2, 0, Main.j.P[10].getWidth() / 2, Main.j.P[10].getHeight());
            return;
        }
        Main.j.b(graphics, Main.j.P[10], 5, Main.j.s - Main.j.P[10].getHeight(), 0, 0, Main.j.P[10].getWidth() / 2, Main.j.P[10].getHeight());
        Main.j.b(graphics, Main.j.P[10], 320 - Main.j.P[10].getWidth() / 2 - 5, Main.j.s - Main.j.P[10].getHeight(), Main.j.P[10].getWidth() / 2, 0, Main.j.P[10].getWidth() / 2, Main.j.P[10].getHeight());
    }
}

