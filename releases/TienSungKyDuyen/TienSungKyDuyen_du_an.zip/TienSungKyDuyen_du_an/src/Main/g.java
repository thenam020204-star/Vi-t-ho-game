/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Graphics
 */
package Main;

import Main.k;
import javax.microedition.lcdui.Graphics;

public final class g
implements k {
    char a = (char)91;
    char b = (char)93;
    public static g c;

    public final int a(char[] cArray, Graphics graphics, int n, int n2, int n3, int n4, int n5) {
        int n6 = 0;
        int n7 = 0;
        String string = new String(cArray, n5, cArray.length - n5);
        string.indexOf(this.a);
        string.indexOf(this.b);
        int n8 = n5;
        while (n8 < cArray.length) {
            graphics.setColor(n4);
            if (cArray[n8] != this.b && cArray[n8] != this.a) {
                graphics.drawString(cArray[n8] + "", n6 + n2, n3 + n7 * k.v, 20);
                n6 += k.D.charWidth(cArray[n8]);
            }
            if (n6 >= n - 5 - k.D.charWidth(cArray[n8 + 1 >= cArray.length - 1 ? cArray.length - 1 : n8 + 1])) {
                n6 = 0;
                if (++n7 == 2) {
                    return n8;
                }
            }
            if (n8 == cArray.length - 1) {
                return n8;
            }
            ++n8;
        }
        return 0;
    }

    public static final g a() {
        if (c == null) {
            c = new g();
        }
        return c;
    }
}

