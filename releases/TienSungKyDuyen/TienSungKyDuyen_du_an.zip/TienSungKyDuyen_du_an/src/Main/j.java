/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Graphics
 *  javax.microedition.lcdui.Image
 */
package Main;

import Main.GameMidlet;
import Main.a;
import Main.b;
import Main.c;
import Main.d;
import Main.e;
import Main.g;
import Main.h;
import Main.i;
import Main.k;
import Main.l;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Random;
import java.util.Vector;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import rf.f;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class j
implements k {
    public static int[] a;
    public static rf.h b;
    private int dJ = 0;
    private int dK = 0;
    private int dL = 0;
    private int dM = 0;
    private int dN = 16;
    private int dO = 16;
    private int dP;
    private long dQ;
    public static boolean c;
    public String d;
    public static int e;
    public String f;
    public static String g;
    public static int[][] h;
    long i;
    long j;
    int k;
    int l;
    int[] m;
    int[] n;
    public static Hashtable o;
    private rf.c dR;
    public static byte p;
    public static int q;
    static int r;
    public static int s;
    public static int t;
    public static rf.e[] u;
    public static Vector L;
    static rf.e[] M;
    static rf.e[] N;
    int[] O;
    public static Image[] P;
    protected rf.g Q = null;
    int R;
    int S;
    boolean T;
    private char[] dS;
    public static int U;
    int V;
    static int W;
    int X;
    int Y;
    int Z;
    int aa;
    public static int ab;
    public static int ac;
    public static int ad;
    public int ae;
    int af;
    int ag;
    public int ah;
    public static Image ai;
    public int aj;
    public int ak;
    public Image al;
    public Image am;
    public int[] an;
    public Image ao;
    int[] ap;
    int[] aq;
    public static int ar;
    public int as;
    public static int at;
    public String[] au;
    public rf.e av;
    boolean aw;
    boolean ax;
    public static j ay;
    public long az;
    public int aA;
    static Image aB;
    static Image aC;
    public static Image aD;
    public Image aE;
    public Image aF;
    static Image aG;
    public static Image aH;
    Image aI;
    static Image aJ;
    static Image aK;
    static Image aL;
    static Image aM;
    static Image aN;
    Image aO;
    Image aP;
    Image aQ;
    public static Image aR;
    public static Image aS;
    static Image aT;
    public static Image aU;
    public static Image aV;
    public static Image aW;
    static Image aX;
    static Image aY;
    static Image aZ;
    static Image ba;
    public static Image bb;
    static Image bc;
    static Image bd;
    int[] be;
    int[] bf;
    int[] bg;
    static int bh;
    static boolean bi;
    static boolean bj;
    public static boolean bk;
    public static boolean bl;
    boolean bm;
    public static boolean[] bn;
    public static boolean[] bo;
    public static boolean bp;
    public boolean bq;
    static boolean br;
    public static boolean bs;
    public static int bt;
    public static boolean bu;
    static boolean bv;
    boolean bw = false;
    public static boolean bx;
    boolean by;
    boolean bz = true;
    int bA = 2;
    boolean bB;
    public static boolean bC;
    public boolean bD;
    public static boolean bE;
    public static boolean bF;
    boolean bG;
    static boolean bH;
    public static boolean bI;
    public static boolean bJ;
    public static int bK;
    public static boolean bL;
    public static int bM;
    boolean bN;
    public static boolean bO;
    boolean bP;
    static boolean bQ;
    boolean bR;
    public static boolean bS;
    public static boolean bT;
    public static boolean bU;
    public static boolean bV;
    public static boolean bW;
    public static boolean bX;
    public static boolean bY;
    public static boolean bZ;
    public static byte[] ca;
    public static boolean cb;
    boolean cc = true;
    public static boolean cd;
    boolean ce;
    boolean cf;
    boolean cg;
    boolean ch;
    public boolean ci;
    boolean cj;
    public byte ck;
    static Image[] cl;
    public int[] cm;
    public int[] cn;
    public int co;
    public int cp;
    public static int cq;
    public static String cr;
    static int cs;
    public int ct;
    public int cu = 0;
    static int cv;
    public static int cw;
    public static int cx;
    public static int cy;
    static String[] cz;
    static String cA;
    public static h cB;
    public static byte[][] cC;
    public static String[][] cD;
    static int cE;
    public static int[] cF;
    int cG;
    int cH;
    static int cI;
    Random cJ;
    String[] cK;
    public static int cL;
    public static String[] cM;
    public static String cN;
    public static l cO;
    public static l cP;
    public static String cQ;
    int cR;
    int cS;
    static int cT;
    int cU;
    String[] cV;
    static int cW;
    public static int cX;
    public static rf.e[] cY;
    public static rf.e[] cZ;
    public static rf.e da;
    public static rf.e db;
    public static rf.e dc;
    public static rf.e[] dd;
    public static rf.e de;
    public static int df;
    String dg;
    public String dh;
    public static String di;
    String dj;
    String dk;
    static String dl;
    String dm;
    static String dn;
    static String do;
    public static int dp;
    public static int dq;
    public static int dr;
    public long ds;
    int[][] dt;
    int[][] du = new int[][]{{14, 106}, {12, 102}, {20, 104}, {9, 108}};
    String[][] dv;
    String[][] dw;
    static int dx;
    static int dy;
    int[] dz = new int[]{136, 126, 167, 135};
    int dA;
    public static Vector dB;
    public static Vector dC;
    static int dD;
    static int dE;
    static int dF;
    public static int dG;
    int dH;
    int dI;

    static {
        df = 1;
        dp = -1;
        c = false;
        b = null;
        cD = new String[][]{{"player0.png", ""}, {"player.png", ""}, {"qc0.png", ""}, {"qc1.png", ""}, {"qc2.png", ""}, {"qc3.png", ""}};
        String[] stringArray = new String[]{"jineng1", "jineng2", "jineng3", "jineng4", "jineng5"};
        (new String[1])[0] = "boss1";
        q = -1;
        bp = true;
        dD = 20;
        dE = 30;
        cE = 100;
        cs = 100;
        cv = 0;
        U = 0;
        bu = true;
        bO = false;
        dG = -1;
        db = new rf.e();
        da = new rf.e();
        bY = true;
        bi = true;
        bE = true;
        bF = true;
        cx = 0;
        bt = 1;
        bK = 1;
        r = -1;
        o = new Hashtable();
        L = new Vector();
        u = null;
        cC = new byte[6][6];
        h = new int[3][2];
        cY = new rf.e[6];
        cZ = new rf.e[44];
        cy = 100;
        cL = 0;
        bM = -1;
        bI = false;
        bJ = false;
        bx = true;
        cF = new int[2];
        at = 0;
        bo = new boolean[6];
        bn = new boolean[6];
        cr = null;
        dB = new Vector();
        dC = new Vector();
        ca = new byte[50];
        cM = new String[]{"\u7a7a", "\u7a7a", "\u7a7a"};
        cz = new String[]{"xian1", "xian2", "xian3"};
        dd = new rf.e[2];
        de = new rf.e();
        dc = new rf.e();
    }

    public j() {
        new Random();
        this.cR = 0;
        this.cS = 0;
        this.cU = 0;
        this.aI = null;
        this.dm = "\u6e38\u620f\u8bbe\u8ba1\u4e86\u5343\u53d8\u4e07\u5316\u7684\u5bf9\u6218\u3002\u591a\u79cd\u7684\u62db\u5f0f\u4e2d\uff0c\u65e2\u6709\u5f3a\u5f31\u4e4b\u5206\uff0c\u53c8\u6709\u76f8\u8f85\u76f8\u514b\u7684\u5173\u7cfb\uff0c\u9700\u8981\u901a\u8fc7\u9057\u4f20\u7684\u65b9\u5f0f\u5c3d\u91cf\u4f7f\u5f97\u4f60\u7684\u7cbe\u7075\u5b66\u4f1a\u8f83\u5f3a\u7684\u62db\u5f0f\u53d1\u6325\u5176\u6700\u4f73\u7684\u6548\u679c\u3002^\u65b9\u5411\u952e\u53ca2\u30014\u30016\u30018\u952e\u79fb\u52a8\u3002\u9a91\u5ba0:0\u952e\u3002\u6e38\u620f\u4e2d\u83dc\u5355/\u6218\u6597\u4e2d\u83dc\u5355\uff1a\u5de6\u8f6f\u952e\u3002\u786e\u5b9a\uff1a\u5de6\u8f6f\u952e\u30015\u3001\u4e2d\u952e^";
        this.dj = "\u5173\u4e8e^\u5317\u4eac\u4e2d\u9510\u638c\u8baf\u4e3a\u4ed9\u5ba0\u5947\u7f18\u7684\u8f6f\u4ef6\u8457\u4f5c\u4eba\u3002\u5317\u4eac\u4e2d\u9510\u638c\u8baf\u6388\u6743\u5146\u8363\u8054\u5408\u5728\u4e2d\u56fd\u5927\u9646\u4ece\u4e8b\u6e38\u620f\u7684\u5546\u4e1a\u8fd0\u8425\u3002\u5146\u8363\u8054\u5408\u540c\u65f6\u8d1f\u8d23\u5904\u7406\u6e38\u620f\u8fd0\u8425\u7684\u76f8\u5173\u5ba2\u670d\u548c\u6280\u672f\u652f\u6301^\u8fd0\u8425\u5546\uff1a^\u5146\u8363\u8054\u5408\uff08\u5317\u4eac\uff09\u79d1\u6280\u53d1\u5c55\u6709\u9650\u516c\u53f8^\u7b80\u79f0\uff1a^\u5146\u8363\u8054\u5408^\u5ba2\u670d\u90ae\u7bb1:^service@zrong.cn^\u5ba2\u670d\u7535\u8bdd:^010-82212999^";
        this.j = 100L;
        this.bR = true;
        this.be = new int[]{0, 0};
        this.bg = new int[]{0, 0};
        this.bf = new int[]{0, 0};
        this.cG = 0;
        this.O = new int[]{0, 0, 0, 0, 0};
        this.dH = 0;
        this.dI = 0;
        this.dR = null;
        this.dP = 0;
        this.dQ = 0L;
        this.an = new int[2];
        this.cm = new int[2];
        this.cn = new int[2];
        this.ap = new int[]{55, 230};
        this.m = new int[]{180, 130};
        this.aq = new int[]{55, 230};
        this.n = new int[]{180, 130};
        if (p == 2) {
            aR = rf.b.a("/Image/key.png");
        }
        t = Main.a.p;
        s = Main.a.o;
        this.cJ = new Random();
        a = new int[t * s];
        int n = 0;
        while (n < a.length) {
            Main.j.a[n] = -2013265920;
            ++n;
        }
        aL = rf.b.a("/Image/jiantou.png");
        aN = rf.b.a("/Image/jiantou22.png");
        aT = rf.b.a("/Image/load.png");
        P = new Image[Main.k.C.length];
        int n2 = 0;
        while (n2 < P.length) {
            Main.j.P[n2] = rf.b.a("/Image/" + Main.k.C[n2] + ".png");
            ++n2;
        }
        bb = rf.b.a("/Image/shop_sms.png");
        aW = rf.b.a("/Image/ui_num10.png");
        if (this.aO == null) {
            this.aO = rf.b.a("/Image/jt1.png");
            this.aP = rf.b.a("/Image/jt2.png");
            this.aQ = rf.b.a("/Image/jt3.png");
        }
        c = false;
    }

    public final void a(rf.e e2, rf.e e3, int n) {
        this.as = n;
        this.ag = 0;
        this.S = 0;
        this.dA = 0;
        if (n == 0 && e2 != null & e3 != null) {
            bQ = false;
            this.av.aa = (byte)-1;
            e3.ai = false;
            e3.aa = (byte)-1;
            e2.ai = false;
            e2.aa = (byte)-1;
            int n2 = 0;
            while (n2 < cY.length) {
                Main.j.cY[n2].aq = false;
                ++n2;
            }
            if (this.cm[0] >= this.cm[1]) {
                this.cm[0] = 0;
            } else {
                this.cm[1] = 0;
            }
        }
        if (df == 4) {
            this.av.aS = true;
            Main.j.cY[Main.j.h[Main.j.e][0]].aS = true;
        }
        if (n == 5) {
            if (e3.aa == 1) {
                this.b(e3, e2);
                this.dH = this.ap[0] + aB.getWidth() / 2;
                this.dI = this.ap[1];
            }
            if (e2.aa == 1) {
                this.b(e2, e3);
                this.dH = this.m[0];
                this.dI = this.m[1] - aC.getHeight();
            }
        }
    }

    public final void a(int n) {
        this.e(n);
        dF = 0;
        aS = null;
        switch (this.ct) {
            case 5: {
                aD = null;
                break;
            }
            case 7: {
                this.aI = null;
            }
        }
        switch (n) {
            case 15: {
                bF = true;
                aS = rf.b.a("/Image/last.png");
                break;
            }
            case 3: {
                dF = 0;
                this.dg = Main.k.H[Math.abs(this.cJ.nextInt()) % Main.k.H.length] + "^";
                bF = true;
                if (!bF) break;
                rf.b.b(this.dg, t - 30);
                bF = false;
                cW = 0;
                this.V = 0;
                break;
            }
            case 9: {
                this.dg = Main.k.G[Math.abs(this.cJ.nextInt()) % Main.k.G.length] + "^";
                bF = true;
                if (!bF) break;
                rf.b.b(this.dg, t - 20);
                bF = false;
                cW = 0;
                this.V = 0;
                break;
            }
            case 12: {
                if (aU != null) break;
                aU = rf.b.a("/Image/logo.png");
                break;
            }
            case 8: {
                bF = true;
                aU = null;
                Main.a.d().a();
                aV = rf.b.a("/Image/menu.png");
                if (p == 6) {
                    aV = rf.b.a(aV, t, s);
                }
                aS = rf.b.a("/Image/last.png");
                if (bY) {
                    Main.j.z();
                    this.f("/Image/2.mid");
                    this.x();
                }
                rf.b.a();
            }
        }
        if (n == 0) {
            this.cR = 0;
            this.cH = 0;
            cI = 4;
            this.dg = Main.k.G[Math.abs(this.cJ.nextInt()) % Main.k.G.length] + "^";
            bF = true;
            if (bF) {
                rf.b.b(this.dg, t - 30);
                bF = false;
                cW = 0;
                this.V = 0;
            }
        }
        this.ct = df;
        df = n;
        if (n == 2) {
            bj = false;
        } else if (n == 4) {
            int n2;
            int n3;
            this.V = 0;
            this.aa = 0;
            int n4 = 0;
            while (n4 < cY.length) {
                n3 = 0;
                while (n3 < h.length) {
                    if (n4 == h[n3][0] && h[n3][0] != -1) break;
                    if (n3 == h.length - 1 && Main.j.cY[n4].au != -1) {
                        ++this.aa;
                        ++this.V;
                    }
                    ++n3;
                }
                ++n4;
            }
            if (this.V != 0) {
                this.bg = new int[this.V];
                this.V = 0;
                n3 = 0;
                while (n3 < cY.length) {
                    n2 = 0;
                    while (n2 < h.length) {
                        if (n3 == h[n2][0] && h[n2][0] != -1) break;
                        if (n2 == h.length - 1 && Main.j.cY[n3].au != -1) {
                            this.bg[this.V++] = n3;
                        }
                        ++n2;
                    }
                    ++n3;
                }
            }
            this.V = 0;
            n3 = 0;
            while (n3 < h.length) {
                if (h[n3][0] != -1) {
                    ++this.aa;
                    ++this.V;
                }
                ++n3;
            }
            this.bf = new int[this.V];
            this.V = 0;
            n2 = 0;
            while (n2 < h.length) {
                if (h[n2][0] != -1) {
                    this.bf[this.V++] = h[n2][0];
                }
                ++n2;
            }
        }
        this.V = 0;
        this.cH = 0;
        bI = false;
        this.bB = false;
        bF = true;
        this.bN = true;
    }

    public final void b(int n) {
        this.cS = 0;
        this.cR = 0;
        int n2 = 0;
        bE = true;
        this.ce = false;
        switch (n) {
            case 72: {
                bE = true;
                break;
            }
            case 11: {
                cT = 3;
                aB = rf.b.a("/Image/guai" + Main.k.z[30][1] + ".png");
                break;
            }
            case 14: {
                bE = true;
                bI = false;
                bW = false;
                cw = 0;
                break;
            }
            case 6: {
                int n3;
                dq = Integer.parseInt(String.valueOf(o.get("taskMain")));
                if (dq == 0) {
                    this.dv = new String[1][2];
                    this.dv[0][0] = "\u76ee\u524d\u6ca1\u6709\u4efb\u52a1";
                    this.dv[0][1] = "";
                } else {
                    this.dv = new String[dq][2];
                    n3 = 0;
                    while (n3 < dq) {
                        this.dv[n3][0] = Main.k.I[n3][0];
                        this.dv[n3][1] = Main.k.I[n3][1];
                        ++n3;
                    }
                }
                n2 = 0;
                n3 = 0;
                while (n3 < Main.k.J.length) {
                    if (Main.k.J[n3][2].equals("1")) {
                        ++n2;
                    }
                    ++n3;
                }
                if (n2 == 0) {
                    this.dw = new String[1][2];
                    this.dw[0][0] = "\u76ee\u524d\u6ca1\u6709\u4efb\u52a1";
                    this.dw[0][1] = "";
                    break;
                }
                this.dw = new String[n2][2];
                n2 = 0;
                int n4 = 0;
                while (n4 < Main.k.J.length) {
                    if (Main.k.J[n4][2].equals("1")) {
                        this.dw[n2][0] = Main.k.J[n4][0];
                        this.dw[n2][1] = Main.k.J[n4][1];
                        ++n2;
                    }
                    ++n4;
                }
                break;
            }
            case 10: {
                ai = rf.b.a("/Image/fb22_big.png");
                break;
            }
            case 7: {
                di = "";
                bF = true;
                int n5 = 0;
                while (n5 < cY.length) {
                    if (!Main.j.cY[n5].t.equals("-1")) {
                        ++n2;
                    }
                    ++n5;
                }
                if (dp == 8) {
                    this.be = new int[n2 + 1];
                    this.be[0] = -1;
                    n2 = 1;
                } else {
                    this.be = new int[n2];
                    n2 = 0;
                }
                int n6 = 0;
                while (n6 < cY.length) {
                    if (!Main.j.cY[n6].t.equals("-1")) {
                        this.be[n2] = n6;
                        ++n2;
                    }
                    ++n6;
                }
                if (n != 7) break;
                aB = rf.b.a("/Image/" + Main.j.cY[this.be[this.cS]].t + ".png");
                break;
            }
            case 9: {
                if (df == 4) {
                    int n7;
                    n2 = 0;
                    int n8 = 0;
                    while (n8 < cY.length) {
                        n7 = 0;
                        while (n7 < h.length) {
                            if (h[n7][0] != -1 && n8 == h[n7][0]) {
                                ++n2;
                            }
                            ++n7;
                        }
                        ++n8;
                    }
                    this.be = new int[n2];
                    n2 = 0;
                    n7 = 0;
                    while (n7 < cY.length) {
                        int n9 = 0;
                        while (n9 < h.length) {
                            if (h[n9][0] != -1 && n7 == h[n9][0]) {
                                this.be[n2] = h[n9][0];
                                ++n2;
                            }
                            ++n9;
                        }
                        ++n7;
                    }
                    aB = rf.b.a("/Image/" + Main.j.cY[this.be[0]].t + ".png");
                    break;
                }
                di = "";
                bF = true;
                int n10 = 0;
                while (n10 < cY.length) {
                    if (!Main.j.cY[n10].t.equals("-1")) {
                        ++n2;
                    }
                    ++n10;
                }
                if (dp == 8) {
                    this.be = new int[n2 + 1];
                    this.be[0] = -1;
                    n2 = 1;
                } else {
                    this.be = new int[n2];
                    n2 = 0;
                }
                int n11 = 0;
                while (n11 < cY.length) {
                    if (!Main.j.cY[n11].t.equals("-1")) {
                        this.be[n2] = n11;
                        ++n2;
                    }
                    ++n11;
                }
                break;
            }
            case 70: {
                int n12;
                n2 = 0;
                int n13 = 0;
                while (n13 < cY.length) {
                    n12 = 0;
                    while (n12 < h.length) {
                        if (h[n12][0] != -1 && n13 == h[n12][0]) {
                            ++n2;
                        }
                        ++n12;
                    }
                    ++n13;
                }
                this.be = new int[n2];
                n2 = 0;
                n12 = 0;
                while (n12 < cY.length) {
                    int n14 = 0;
                    while (n14 < h.length) {
                        if (h[n14][0] != -1 && n12 == h[n14][0]) {
                            this.be[n2] = h[n14][0];
                            ++n2;
                        }
                        ++n14;
                    }
                    ++n12;
                }
                aB = rf.b.a("/Image/" + Main.j.cY[this.be[0]].t + ".png");
                break;
            }
            case 8: {
                n2 = 0;
                int n15 = 0;
                while (n15 < h.length) {
                    if (h[n15][0] != -1) {
                        ++n2;
                    }
                    ++n15;
                }
                this.be = new int[n2];
                n2 = 0;
                int n16 = 0;
                while (n16 < h.length) {
                    if (h[n16][0] != -1) {
                        this.be[n2] = h[n16][0];
                        ++n2;
                    }
                    ++n16;
                }
                int n17 = 0;
                while (n17 < cY.length) {
                    if (n17 == h[0][0]) {
                        this.cS = n17 + 1;
                    }
                    ++n17;
                }
                break;
            }
            case 16: 
            case 17: {
                int n18 = 0;
                while (n18 < cY.length) {
                    if (!Main.j.cY[n18].t.equals("-1")) {
                        ++n2;
                    }
                    ++n18;
                }
                this.be = new int[n2];
                n2 = 0;
                int n19 = 0;
                while (n19 < cY.length) {
                    if (!Main.j.cY[n19].t.equals("-1")) {
                        this.be[n2] = n19;
                        ++n2;
                    }
                    ++n19;
                }
                aB = rf.b.a("/Image/" + Main.j.cY[this.be[this.cS]].t + ".png");
                break;
            }
            case 18: {
                int n20 = 0;
                while (n20 < cZ.length) {
                    if (!Main.j.cZ[n20].t.equals("-1")) {
                        ++n2;
                    }
                    ++n20;
                }
                if (n2 == 0) {
                    this.bR = true;
                    break;
                }
                this.bR = false;
                this.be = new int[n2];
                n2 = 0;
                int n21 = 0;
                while (n21 < cZ.length) {
                    if (!Main.j.cZ[n21].t.equals("-1")) {
                        this.be[n2] = n21;
                        ++n2;
                    }
                    ++n21;
                }
                aB = rf.b.a("/Image/" + Main.j.cZ[this.be[this.cS]].t + ".png");
            }
        }
        bv = false;
        this.cu = dp;
        dp = n;
        this.cR = 0;
        this.bB = false;
        if (dp != 4) {
            Main.a.d().a();
        }
    }

    public static final void a() {
        ++Main.l.a;
    }

    public final void a(rf.e e2, int n) {
        if (e2.Y <= n) {
            this.f(e2);
            e2.Y = n;
            e2.ao = true;
            this.aE = rf.b.a("/Image/zt" + n + ".png");
            this.aj = 0;
        } else {
            this.aE = rf.b.a("/Image/zt" + e2.Y + ".png");
        }
        dl = "";
        switch (n) {
            case 0: {
                e2.al = false;
                e2.aj = false;
                e2.ak = false;
                e2.U = "1/2";
                dl = "\u9ebb\u75f9\u72b6\u6001,";
                break;
            }
            case 1: {
                e2.aj = false;
                dl = "\u7981\u9522\u72b6\u6001,";
                break;
            }
            case 2: {
                e2.U = "1/2";
                e2.X = "8/10";
                break;
            }
            case 3: {
                break;
            }
            case 4: {
                e2.ar = true;
                e2.al = false;
                e2.aj = false;
                e2.ak = false;
                e2.az = 0;
                e2.W = "125/100";
                e2.U = "0";
                dl = "\u77f3\u5316\u72b6\u6001,";
            }
        }
        this.a(e2);
        this.n();
    }

    public final void b(rf.e e2, int n) {
        if (e2.Y <= n) {
            this.f(e2);
            e2.Y = n;
            e2.ao = true;
            this.aF = rf.b.a("/Image/zt" + n + ".png");
            this.ak = 0;
        }
        switch (n) {
            case 0: {
                e2.al = false;
                e2.aj = false;
                e2.ak = false;
                e2.U = "1/2";
                e2.az = e2.az * this.c(e2.U)[0] / this.c(e2.U)[1];
                return;
            }
            case 1: {
                e2.aj = false;
                e2.V = "125/100";
                return;
            }
            case 2: {
                e2.U = "1/2";
                e2.X = "8/10";
                e2.az = e2.az * this.c(e2.U)[0] / this.c(e2.U)[1];
                e2.ay = e2.ay * this.c(e2.X)[0] / this.c(e2.X)[1];
                return;
            }
            case 3: {
                return;
            }
            case 4: {
                e2.W = "125/100";
                e2.ar = true;
                e2.al = false;
                e2.aj = false;
                e2.ak = false;
                e2.az = 0;
                e2.aB = e2.aB * this.c(e2.W)[0] / this.c(e2.W)[1];
                e2.U = "0";
            }
        }
    }

    public final void a(String string, String string2, int[] nArray, String string3, int n) {
        byte by = 0;
        if (n == 0 || n == 1) {
            by = 2;
        }
        cB.a("/sr/" + string + ".sr", by);
        rf.a a2 = new rf.a(Main.j.cB.o, Main.j.cB.q, Main.j.cB.t, n);
        rf.e e2 = new rf.e(a2);
        if (n == 0) {
            this.a(e2, string2);
        } else {
            int n2 = Integer.parseInt(string2.substring(0, 1));
            String string4 = string2.substring(1, 2);
            Main.j.a(e2, n2, string4, -1);
        }
        e2.t = string;
        e2.r = new int[25];
        e2.b(nArray[0] * this.dO + 8, nArray[1] * this.dN + 8);
        string.equals("player");
        ++r;
        if (string.equals("player")) {
            q = r;
        }
        L.addElement(e2);
    }

    public final void a(Vector vector) {
        Image[] imageArray = new Image[vector.size()];
        String string = "guai" + h[e][1] + ".png";
        int n = 0;
        while (n < vector.size()) {
            imageArray[n] = rf.b.a("/Image/" + (String)vector.elementAt(n));
            vector.elementAt(n);
            Object var5_5 = null;
            boolean bl = false;
            String string2 = (String)vector.elementAt(n);
            string2.equals(string);
            ++n;
        }
        new f(Main.j.cB.b, imageArray);
    }

    public final void a(String string) {
        cB.a("/dat/" + string + ".dat", (byte)1);
        int n = Main.j.cB.b.length / 7;
        rf.d d2 = new rf.d(n);
        int n2 = 0;
        while (n2 < n) {
            d2.a(Main.j.cB.b[0 + n2 * 7], Main.j.cB.b[1 + n2 * 7], Main.j.cB.b[2 + n2 * 7], Main.j.cB.b[3 + n2 * 7], Main.j.cB.b[4 + n2 * 7], Main.j.cB.b[5 + n2 * 7]);
            ++n2;
        }
        this.dR = new rf.c(d2, Main.j.cB.h, Main.j.cB.f, this.dO, this.dN);
        int n3 = 0;
        while (n3 < Main.j.cB.m.length) {
            this.a(Main.j.cB.m[n3]);
            ++n3;
        }
    }

    public final void a(byte[] byArray) {
        byte by = byArray[0];
        boolean bl = false;
        rf.a a2 = new rf.a(Main.j.cB.i[by - 1], Main.j.cB.k, Main.j.cB.j, 2);
        int n = 1;
        while (n < byArray.length / 2) {
            rf.e e2 = new rf.e(a2);
            e2.b(byArray[n * 2 + 1] * this.dO + this.dO / 2, byArray[n * 2] * this.dN + this.dN / 2);
            e2.t = "obj-" + by + "-" + (n - 1);
            this.b(e2);
            ++n;
        }
    }

    /*
     * Handled impossible loop by duplicating code
     * Enabled aggressive block sorting
     */
    public final void b() {
        block7: {
            int n;
            block6: {
                this.a(Main.j.cB.c);
                this.e();
                this.g();
                if (q != -1) {
                    if (cs == 25 || cs == 26 || cs == 27 || cs == 28) {
                        Main.j.a(u[q], 100, -1);
                    }
                    if (cL != 0) {
                        Main.j.a(u[q], this.du[cL - 1][1], -1);
                    }
                }
                this.bz = false;
                n = 0;
                if (!true) break block6;
                Main.e.a();
                if (n >= Main.e.e.length) break block7;
            }
            do {
                Main.e.a();
                Main.e.e[n] = 1;
                ++n;
                Main.e.a();
            } while (n < Main.e.e.length);
        }
        if (u[q] != null) {
            this.Q.a(0, 0, Main.j.u[Main.j.q].af - (Main.j.b.t + (Main.j.b.k >> 1)), Main.j.u[Main.j.q].aR - (Main.j.b.A + (Main.j.b.h >> 1)));
        }
    }

    public final void c() {
        if (this.bw || bT) {
            Main.j.u[Main.j.q].af = cF[0];
            Main.j.u[Main.j.q].aR = cF[1];
            Main.j.u[Main.j.q].T = this.ah;
            if (this.ah == 1) {
                this.a(u[q], "U");
            } else if (this.ah == 2) {
                this.a(u[q], "D");
            } else if (this.ah == 3) {
                this.a(u[q], "L");
            } else if (this.ah == 4) {
                this.a(u[q], "R");
            }
            bT = false;
        }
        int n = 0;
        while (n < u.length) {
            u[n].b();
            ++n;
        }
        this.a(2);
    }

    public static final rf.e a(String string, int n) {
        String string2 = "";
        if (string.indexOf("guai") != -1 && string.indexOf("zhua") == -1) {
            string2 = string;
            string = "guai8";
        }
        cB.a("/sr/" + string + ".sr", (byte)4);
        rf.e e2 = new rf.e(new rf.a(Main.j.cB.o, Main.j.cB.q, Main.j.cB.t, n));
        string = string2;
        e2.ah = new Image[Main.j.cB.s.length];
        int n2 = 0;
        while (n2 < e2.ah.length) {
            e2.ah[n2] = rf.b.a("/Image/" + Main.j.cB.s[n2]);
            ++n2;
        }
        e2.t = string;
        return e2;
    }

    public final void d() {
        N = new rf.e[1];
        Main.j.N[0] = Main.j.a("ui_select", 5);
        Main.j.N[0].t = "ui_select";
        Main.j.N[0].aO = 0;
    }

    public final void e() {
        this.dK = t;
        this.dJ = s;
        b = new rf.h(this.dL, this.dM, this.dK, this.dJ, this.dO, this.dN, 0, true);
        this.Q = new rf.g();
        this.Q.a(this.dR);
        this.Q.a(this.E());
        this.Q.a(b);
        this.Q.b();
    }

    public final void f() {
        switch (cE) {
            case 100: 
            case 102: 
            case 104: 
            case 106: 
            case 108: {
                this.C();
                break;
            }
            case 101: 
            case 103: 
            case 105: 
            case 107: 
            case 109: {
                this.D();
            }
        }
        this.cj = this.Q.b(q, 0, Main.j.u[Main.j.q].aL, Main.j.u[Main.j.q].aM);
        if (this.cj) {
            Main.j.u[Main.j.q].aL = 0;
            Main.j.u[Main.j.q].aM = 0;
        }
        if (Main.a.d().p()) {
            int n;
            int n2 = 0;
            if (!bp) {
                bI = true;
                bF = true;
                di = "\u4e0d\u80fd\u5207\u6362";
                return;
            }
            int n3 = 0;
            while (n3 < cY.length) {
                n = 0;
                while (n < this.du.length) {
                    if (Main.j.cY[n3].ae == this.du[n][0]) {
                        ++n2;
                    }
                    ++n;
                }
                ++n3;
            }
            if (n2 == 0) {
                bI = true;
                bF = true;
                di = "\u80cc\u5305\u4e2d\u6ca1\u6709\u53ef\u9a91\u7684\u4ed9\u5ba0";
                return;
            }
            this.dt = new int[n2 + 1][2];
            this.dt[0][0] = 100;
            this.dt[0][1] = 0;
            n2 = 1;
            n = 0;
            while (n < cY.length) {
                int n4 = 0;
                while (n4 < this.du.length) {
                    if (Main.j.cY[n].ae == this.du[n4][0]) {
                        this.dt[n2][0] = this.du[n4][1];
                        this.dt[n2++][1] = n4 + 1;
                    }
                    ++n4;
                }
                ++n;
            }
            this.cR = this.cR < this.dt.length - 1 ? ++this.cR : 0;
            cL = this.dt[this.cR][1];
            Main.j.a(u[q], this.dt[this.cR][0], -1);
            Main.j.u[Main.j.q].aM = 5;
            Main.a.d().a();
        }
    }

    private void C() {
        Main.j.u[Main.j.q].aL = 0;
        if (bM != 1) {
            Main.j.u[Main.j.q].aM = 0;
        }
        int n = 0;
        if (cE == 100) {
            n = 101;
        } else if (cE == 108) {
            n = 109;
        } else if (cE == 104) {
            n = 105;
        } else if (cE == 106) {
            n = 107;
        } else if (cE == 102) {
            n = 103;
        }
        if (Main.a.d().k()) {
            Main.j.u[Main.j.q].aL = -6;
            Main.j.u[Main.j.q].aM = 0;
            Main.j.u[Main.j.q].T = 3;
            Main.j.a(u[q], n, -1);
            return;
        }
        if (Main.a.d().u()) {
            Main.j.u[Main.j.q].aL = 6;
            Main.j.u[Main.j.q].aM = 0;
            Main.j.u[Main.j.q].T = 4;
            Main.j.a(u[q], n, -1);
            return;
        }
        if (Main.a.d().w()) {
            Main.j.u[Main.j.q].aM = -6;
            Main.j.u[Main.j.q].aL = 0;
            Main.j.u[Main.j.q].T = 1;
            Main.j.a(u[q], n, -1);
            return;
        }
        if (Main.a.d().e()) {
            Main.j.u[Main.j.q].aM = 6;
            Main.j.u[Main.j.q].aL = 0;
            Main.j.u[Main.j.q].T = 2;
            Main.j.a(u[q], n, -1);
        }
    }

    private void D() {
        ++dF;
        if (Main.l.h && Main.j.u[Main.j.q].aO != 24 && Main.l.b != 50) {
            this.k();
        }
        int n = 0;
        int n2 = 0;
        if (cE == 101) {
            n = 101;
            n2 = 100;
        } else if (cE == 109) {
            n = 109;
            n2 = 108;
        } else if (cE == 105) {
            n = 105;
            n2 = 104;
        } else if (cE == 107) {
            n = 107;
            n2 = 106;
        } else if (cE == 103) {
            n = 103;
            n2 = 102;
        }
        if (Main.a.d().k()) {
            Main.j.u[Main.j.q].aL = -6;
            Main.j.u[Main.j.q].aM = 0;
            Main.j.u[Main.j.q].T = 3;
            Main.j.a(u[q], n, -1);
            u[q].a((byte)2);
            return;
        }
        if (Main.a.d().u()) {
            Main.j.u[Main.j.q].aL = 6;
            Main.j.u[Main.j.q].aM = 0;
            Main.j.u[Main.j.q].T = 4;
            Main.j.a(u[q], n, -1);
            u[q].a((byte)0);
            return;
        }
        if (Main.a.d().w()) {
            Main.j.u[Main.j.q].aM = -6;
            Main.j.u[Main.j.q].aL = 0;
            if (Main.j.u[Main.j.q].aO == 24) {
                if (Main.j.u[Main.j.q].aP == 0) {
                    Main.j.u[Main.j.q].T = 4;
                    u[q].a((byte)0);
                } else {
                    Main.j.u[Main.j.q].T = 3;
                    u[q].a((byte)2);
                }
            } else {
                Main.j.u[Main.j.q].T = 1;
                u[q].a((byte)0);
            }
            Main.j.a(u[q], n, -1);
            return;
        }
        if (Main.a.d().e()) {
            Main.j.u[Main.j.q].aM = 6;
            Main.j.u[Main.j.q].aL = 0;
            if (Main.j.u[Main.j.q].aO == 24) {
                if (Main.j.u[Main.j.q].aP == 0) {
                    Main.j.u[Main.j.q].T = 4;
                    u[q].a((byte)0);
                } else {
                    Main.j.u[Main.j.q].T = 3;
                    u[q].a((byte)2);
                }
            } else {
                Main.j.u[Main.j.q].T = 2;
                u[q].a((byte)0);
            }
            Main.j.a(u[q], n, -1);
            return;
        }
        if (cE != 25 && cE != 26 && cE != 27) {
            if (cE == 28) {
                return;
            }
            if (dG == -1) {
                Main.j.u[Main.j.q].aM = 0;
                Main.j.u[Main.j.q].aL = 0;
                Main.j.a(u[q], n2, -1);
            }
        }
    }

    public static final void a(rf.e e2, int n, String string, int n2) {
        e2.aO = n;
        e2.P = n2;
        e2.a(n, true);
        if (string.equals("R")) {
            e2.a((byte)0);
            return;
        }
        e2.a((byte)2);
    }

    public static final void a(rf.e e2, int n, int n2) {
        e2.aN = 0;
        e2.P = n2;
        cs = cE;
        cE = n;
        o.put("playerState", String.valueOf(n));
        switch (cE) {
            case 100: {
                if (dF >= dE) {
                    dF = 0;
                }
                if (e2.T == 1) {
                    e2.a(0, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 2) {
                    e2.a(1, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 3) {
                    e2.a(2, false);
                    e2.a((byte)2);
                    return;
                }
                if (e2.T != 4) break;
                e2.a(2, false);
                e2.a((byte)0);
                return;
            }
            case 101: {
                if (e2.T == 1) {
                    e2.a(3, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 2) {
                    e2.a(4, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 3) {
                    e2.a(5, false);
                    e2.a((byte)2);
                    return;
                }
                if (e2.T != 4) break;
                e2.a(5, false);
                e2.a((byte)0);
                return;
            }
            case 102: {
                if (e2.T == 1) {
                    e2.a(6, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 2) {
                    e2.a(7, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 3) {
                    e2.a(8, false);
                    e2.a((byte)2);
                    return;
                }
                if (e2.T != 4) break;
                e2.a(8, false);
                e2.a((byte)0);
                return;
            }
            case 103: {
                if (e2.T == 1) {
                    e2.a(9, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 2) {
                    e2.a(10, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 3) {
                    e2.a(11, false);
                    e2.a((byte)2);
                    return;
                }
                if (e2.T != 4) break;
                e2.a(11, false);
                e2.a((byte)0);
                return;
            }
            case 104: {
                if (e2.T == 1) {
                    e2.a(12, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 2) {
                    e2.a(13, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 3) {
                    e2.a(14, false);
                    e2.a((byte)2);
                    return;
                }
                if (e2.T != 4) break;
                e2.a(14, false);
                e2.a((byte)0);
                return;
            }
            case 105: {
                if (e2.T == 1) {
                    e2.a(15, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 2) {
                    e2.a(16, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 3) {
                    e2.a(17, false);
                    e2.a((byte)2);
                    return;
                }
                if (e2.T != 4) break;
                e2.a(17, false);
                e2.a((byte)0);
                return;
            }
            case 106: {
                if (e2.T == 1) {
                    e2.a(18, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 2) {
                    e2.a(19, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 3) {
                    e2.a(20, false);
                    e2.a((byte)2);
                    return;
                }
                if (e2.T != 4) break;
                e2.a(20, false);
                e2.a((byte)0);
                return;
            }
            case 107: {
                if (e2.T == 1) {
                    e2.a(21, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 2) {
                    e2.a(22, false);
                    e2.a((byte)0);
                    return;
                }
                if (e2.T == 3) {
                    e2.a(23, false);
                    e2.a((byte)2);
                    return;
                }
                if (e2.T != 4) break;
                e2.a(23, false);
                e2.a((byte)0);
                return;
            }
            case 108: {
                if (e2.T == 1) {
                    e2.a(24, false);
                    if (e2.aP == 0) {
                        e2.a((byte)0);
                        e2.T = 3;
                    } else {
                        e2.a((byte)2);
                        e2.T = 4;
                    }
                    return;
                }
                if (e2.T == 2) {
                    e2.a(24, false);
                    if (e2.aP == 2) {
                        e2.a((byte)2);
                        e2.T = 4;
                    } else {
                        e2.T = 3;
                        e2.a((byte)0);
                    }
                    return;
                }
                if (e2.T == 3) {
                    e2.a(24, false);
                    e2.a((byte)2);
                    return;
                }
                if (e2.T != 4) break;
                e2.a(24, false);
                e2.a((byte)0);
                return;
            }
            case 109: {
                if (e2.T == 1) {
                    e2.a(24, false);
                    if (e2.aP == 0) {
                        e2.a((byte)0);
                        e2.T = 3;
                    } else {
                        e2.a((byte)2);
                        e2.T = 4;
                    }
                    return;
                }
                if (e2.T == 2) {
                    e2.a(24, false);
                    if (e2.aP == 2) {
                        e2.a((byte)2);
                        e2.T = 4;
                    } else {
                        e2.T = 3;
                        e2.a((byte)0);
                    }
                    return;
                }
                if (e2.T == 3) {
                    e2.a(24, false);
                    e2.a((byte)2);
                    return;
                }
                if (e2.T != 4) break;
                e2.a(24, false);
                e2.a((byte)0);
                return;
            }
            default: {
                System.out.println("=WW######");
                e2.a(n, true);
            }
        }
    }

    public final void g() {
        u = this.E();
    }

    public final void a(rf.e e2) {
        e2.aE = (e2.k - 1) * (e2.aD + 1) + 11 + 22 * e2.o;
        e2.aF = e2.l * (e2.aD - 1) + 15 + e2.o;
        e2.ay = (e2.p + e2.o + 5) * e2.aD / 20 + e2.o + 1;
        e2.aG = e2.q * (e2.aD + 10) / 16 + 19 + 3 * e2.o;
        e2.aG = e2.aG * this.c(e2.X)[0] / this.c(e2.X)[1];
        e2.aA = (2 * e2.m + e2.l + e2.p) * e2.aD / 50 + 3 * e2.o + 8;
        e2.aB = (e2.k - 1) * e2.aD / 10 + 3 * e2.o - 2;
        e2.aG = e2.aG * this.c(e2.W)[0] / this.c(e2.W)[1];
        e2.az = (e2.m + e2.q - 3) * (e2.aD - 1) / 20 + 16;
        e2.U = "1/2";
        e2.az = e2.aG * this.c(e2.U)[0] / this.c(e2.U)[1];
        e2.aC = (e2.aD + 9 * e2.o * e2.o - 8) * e2.aD;
    }

    private rf.e[] E() {
        if (L.size() <= 0) {
            return null;
        }
        rf.e[] eArray = new rf.e[L.size()];
        int n = 0;
        while (n < eArray.length) {
            eArray[n] = (rf.e)L.elementAt(n);
            ++n;
        }
        return eArray;
    }

    public final void a(int n, int n2) {
        this.R = n;
        if (this.R == -1) {
            this.ae = n2;
        }
    }

    public final void a(int n, String[] stringArray) {
        this.cV = stringArray;
    }

    final void c(int n) {
        i i2 = null;
        if (dC.size() != 0) {
            int n2 = 0;
            while (n2 < dC.size()) {
                i2 = (i)dC.elementAt(n2);
                if (i2.b == n) {
                    ++i2.a;
                    this.bD = true;
                    this.dh = Main.k.E[i2.b][0];
                    break;
                }
                if (n2 == dC.size() - 1) {
                    i2 = new i(n, 1);
                    dC.addElement(i2);
                    this.bD = true;
                    this.dh = Main.k.E[i2.b][0];
                }
                ++n2;
            }
            return;
        }
        i2 = new i(n, 1);
        dC.addElement(i2);
        this.bD = true;
        this.dh = Main.k.E[i2.b][0];
    }

    final void d(int n) {
        d d2 = null;
        if (dB.size() != 0) {
            int n2 = 0;
            while (n2 < dB.size()) {
                d2 = (d)dB.elementAt(n2);
                if (d2.b == n) {
                    ++d2.a;
                    this.bD = true;
                    this.dh = Main.k.E[d2.b][0];
                    break;
                }
                if (n2 == dB.size() - 1) {
                    d2 = new d(n, 1);
                    dB.addElement(d2);
                    this.bD = true;
                    this.dh = Main.k.E[d2.b][0];
                }
                ++n2;
            }
            return;
        }
        d2 = new d(n, 1);
        dB.addElement(d2);
        this.bD = true;
        this.dh = Main.k.E[d2.b][0];
    }

    public final void b(int n, int n2) {
        this.Q.a(n, n2, 10);
    }

    public final void a(String string, String[] stringArray, String string2, int[] nArray, String string3, String string4) {
        this.d = string;
        this.f = string3;
        g = null;
        this.ci = false;
        this.au = new String[stringArray.length];
        int n = 0;
        while (n < this.au.length) {
            this.au[n] = stringArray[n];
            System.out.println(" fight_Spid[i]=" + this.au[n]);
            ++n;
        }
        int n2 = string2.indexOf("%");
        ar = Integer.parseInt(string2.substring(0, n2));
        this.an[0] = nArray[0];
        this.an[1] = nArray[1];
    }

    public final void a(String string, String string2, String string3, String string4, String string5, String string6) {
        this.d = string;
        this.f = string4;
        g = string6;
        if (g.equals("-1")) {
            g = null;
        }
        this.au = new String[1];
        this.au[0] = string2;
        this.an[0] = Integer.parseInt(string3);
        this.an[1] = Integer.parseInt(string3);
        this.ci = !string5.equals("0");
        at = 1;
        this.a(3);
    }

    public final int a(rf.e[] eArray, rf.e e2) {
        int n = 0;
        int n2 = 0;
        while (n2 < eArray.length) {
            if (eArray[n2].t.equals("-1")) {
                eArray[n2].ag = e2.ag;
                eArray[n2].ax = 0;
                eArray[n2].t = e2.t;
                eArray[n2].aD = e2.aD;
                eArray[n2].n = e2.n;
                eArray[n2].aH = e2.aH;
                eArray[n2].ae = Integer.parseInt(e2.t.substring(4, e2.t.length()));
                this.g(eArray[n2]);
                ++n;
                break;
            }
            ++n2;
        }
        return n;
    }

    public final void a(String string, String string2) {
        if (cx == 1) {
            this.b(72);
            cX = 5;
        }
    }

    public final void b(rf.e e2) {
        ++r;
        L.addElement(e2);
    }

    public final void a(String string, String string2, String string3, String string4, String string5, String string6, String string7, String string8) {
        int n = Integer.parseInt(string4);
        int n2 = Integer.parseInt(string5);
        int n3 = Integer.parseInt(string3);
        boolean bl = string6.equals("true");
        int n4 = Integer.parseInt(string7);
        int n5 = Integer.parseInt(string8);
        if (u != null) {
            Main.j.d((String)string).aQ = string2;
            Main.j.d(string).a(n3, n, n2, bl, n4, n5);
            return;
        }
        Main.j.e((String)string).aQ = string2;
        Main.j.e(string).a(n3, n, n2, bl, n4, n5);
    }

    public final void c(int n, int n2) {
        if (n2 == 0) {
            return;
        }
        if (cy < n2 * Integer.parseInt(Main.k.E[n][2])) {
            bI = true;
            bF = true;
            di = "\u91d1\u94b1\u4e0d\u8db3\uff01";
            if (cx == 1) {
                this.b(72);
                cX = 3;
            }
            return;
        }
        cy -= n2 * Integer.parseInt(Main.k.E[n][2]);
        i i2 = null;
        if (dC.size() != 0) {
            int n3 = 0;
            while (n3 < dC.size()) {
                i2 = (i)dC.elementAt(n3);
                if (i2.b == n) {
                    i2.a += n2;
                    break;
                }
                if (n3 == dC.size() - 1) {
                    i2 = new i(n, n2);
                    dC.addElement(i2);
                    break;
                }
                ++n3;
            }
        } else {
            i2 = new i(n, n2);
            dC.addElement(i2);
        }
        bI = true;
        bF = true;
        di = Main.k.E[n][0] + "x" + n2 + "\u8d2d\u4e70\u6210\u529f\uff01";
    }

    public final void d(int n, int n2) {
        if (n2 == 0) {
            return;
        }
        if (cy < n2 * Integer.parseInt(Main.k.E[n][2])) {
            bI = true;
            bF = true;
            di = "\u91d1\u94b1\u4e0d\u8db3\uff01";
            if (cx == 1) {
                this.b(72);
                cX = 3;
            }
            return;
        }
        cy -= n2 * Integer.parseInt(Main.k.E[n][2]);
        d d2 = null;
        if (dB.size() != 0) {
            int n3 = 0;
            while (n3 < dB.size()) {
                d2 = (d)dB.elementAt(n3);
                if (d2.b == n) {
                    d2.a += n2;
                    break;
                }
                if (n3 == dB.size() - 1) {
                    d2 = new d(n, n2);
                    dB.addElement(d2);
                    break;
                }
                ++n3;
            }
        } else {
            d2 = new d(n, n2);
            dB.addElement(d2);
        }
        bI = true;
        bF = true;
        di = Main.k.E[n][0] + "x" + n2 + "\u8d2d\u4e70\u6210\u529f\uff01";
    }

    public final void h() {
        switch (this.cH) {
            case 0: {
                Main.b.a = 0;
                cN = cQ;
                if (this.bw) {
                    if (!this.bz) {
                        this.j();
                    }
                } else {
                    this.i();
                }
                if (bT) {
                    rf.b.b(cz[cT]);
                }
                if (df == 4) {
                    o.put("fightPut", "1");
                } else {
                    o.put("fightPut", "0");
                }
                cO = null;
                this.d();
                ++this.cH;
                return;
            }
            case 1: {
                aB = rf.b.a("/Image/guai" + h[e][1] + ".png");
                ++this.cH;
                return;
            }
            case 2: {
                if (cN == null) {
                    cN = this.f;
                }
                cB.a("/pak/" + cN, (byte)0);
                ++this.cH;
                return;
            }
            case 3: {
                cO = new l(Main.j.cB.e, Main.j.cB.n);
                ++this.cH;
            }
        }
    }

    public final void b(String string, String string2) {
        try {
            this.aI = rf.b.a("/Image/" + string + ".png");
            this.dk = string2;
            this.dk = Main.j.a(this.dk, "@", "^");
            this.a(7);
            bE = true;
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.printStackTrace();
            return;
        }
    }

    public final boolean b(String string) {
        if (this.dQ == 0L) {
            this.dQ = System.currentTimeMillis();
        }
        if (System.currentTimeMillis() - this.dQ > (long)Integer.parseInt(string)) {
            this.dQ = 0L;
            return true;
        }
        return false;
    }

    public final void e(int n, int n2) {
        this.Q.a(n, n2, 0);
    }

    public final void e(int n) {
        switch (n) {
            case 9: {
                aV = null;
                return;
            }
            case 8: {
                this.i();
                rf.g.a();
                return;
            }
            case 4: {
                rf.g.a();
                return;
            }
            case 5: {
                this.i();
                rf.g.a();
            }
        }
    }

    public final void i() {
        int n;
        if (u != null) {
            n = 0;
            while (n < u.length) {
                Main.j.u[n] = null;
                ++n;
            }
            u = null;
        }
        L.removeAllElements();
        this.dR = null;
        b = null;
        this.Q = null;
        if (rf.f.a != null) {
            n = 0;
            while (n < rf.f.a.length) {
                rf.f.a[n] = null;
                ++n;
            }
        }
        if (cB != null && Main.j.cB.c != null) {
            Main.j.cB.c.removeAllElements();
        }
        r = -1;
        this.aE = null;
    }

    public final void j() {
        aX = null;
        ba = null;
        aG = null;
        this.dR = null;
        this.ao = null;
        this.al = null;
        this.am = null;
        bd = null;
        aC = null;
        this.aF = null;
        this.aE = null;
        int n = 0;
        while (n < Main.j.M[0].ah.length) {
            Main.j.M[0].ah[n] = null;
            ++n;
        }
        int n2 = 0;
        while (n2 < dd.length) {
            int n3 = 0;
            while (n3 < Main.j.dd[n2].ah.length) {
                Main.j.dd[n2].ah[n3] = null;
                ++n3;
            }
            ++n2;
        }
        aC = null;
        Main.j.M[0] = null;
        b = null;
        if (Main.j.cB.c != null) {
            Main.j.cB.c.removeAllElements();
        }
        r = -1;
    }

    public static final void a(Graphics graphics, Image image, int n, int n2, int n3, int n4, int n5, int n6) {
        if (image == null) {
            return;
        }
        int n7 = graphics.getClipWidth();
        int n8 = graphics.getClipHeight();
        int n9 = 0;
        while (n9 < n5) {
            graphics.setClip(n + n9, n2, 1, n6);
            graphics.drawImage(image, n + n9 * 2 - n3 - n5 + 1, n2 - n4, 0);
            ++n9;
        }
        graphics.setClip(0, 0, n7, n8);
    }

    public final void a(Graphics graphics) {
        if (p == 2) {
            Main.j.b(graphics, P[10], 10, s - P[10].getHeight() - 10, 0, 0, P[10].getWidth() / 2, P[10].getHeight());
        }
    }

    private void x(Graphics graphics) {
        graphics.setColor(0xFFFFFF);
        graphics.drawString("\u786e\u5b9a", 1, s - Main.k.v - 1, 0);
    }

    public final void b(Graphics graphics) {
        this.b(graphics, "\u662f\u5426\u9000\u51fa\u6e38\u620f\uff1f");
        if (Main.a.d().j()) {
            this.a(8);
            bs = false;
            this.b(-1);
        } else if (Main.a.d().t()) {
            bs = false;
        }
        Main.a.d().a();
        Main.a.d().s = false;
    }

    public final void c(Graphics graphics) {
        this.c(graphics, "\u786e\u5b9a\u9000\u51fa\uff1f^");
        this.x(graphics);
        this.z(graphics);
        if (Main.a.d().j()) {
            this.a(15);
            bs = false;
        } else if (Main.a.d().t()) {
            bs = false;
        }
        Main.a.d().a();
        Main.a.d().s = false;
    }

    public final void a(Graphics graphics, int n) {
        this.a(graphics, n, cY);
        if (this.cf) {
            this.b(graphics, "\u662f\u5426\u653e\u751f\u8be5\u4ed9\u5ba0");
        }
        if (Main.a.d().l()) {
            this.cR = 0;
            if (this.cS > 0) {
                --this.cS;
            }
            aB = rf.b.a("/Image/" + Main.j.cY[this.be[this.cS]].t + ".png");
        } else if (Main.a.d().v()) {
            this.cR = 0;
            if (this.cS < this.be.length - 1) {
                ++this.cS;
            }
            aB = rf.b.a("/Image/" + Main.j.cY[this.be[this.cS]].t + ".png");
        }
        if (Main.a.d().i() || Main.a.d().n()) {
            if (!this.cf) {
                this.cf = true;
            } else {
                int n2;
                int n3 = 0;
                boolean bl = false;
                int n4 = 0;
                while (n4 < h.length) {
                    if (h[n4][0] != -1) {
                        ++n3;
                    }
                    if (h[n4][0] == this.be[this.cS]) {
                        bl = true;
                    }
                    ++n4;
                }
                if (n3 == 1 && bl) {
                    this.cf = false;
                    bI = true;
                    bF = true;
                    bE = true;
                    di = Main.j.cY[this.be[this.cS]].aH + "\u653e\u751f\u5931\u8d25\uff01" + "\u81f3\u5c11\u8981\u6709\u4e00\u4e2a\u4ed9\u5ba0\u53c2\u52a0\u6218\u6597";
                    return;
                }
                Main.j.cY[this.be[this.cS]].ae = -1;
                Main.j.cY[this.be[this.cS]].ab = -1;
                Main.j.cY[this.be[this.cS]].t = "-1";
                int n5 = 0;
                while (n5 < h.length) {
                    if (h[n5][0] == this.be[this.cS]) {
                        Main.j.h[n5][1] = -1;
                        Main.j.h[n5][0] = -1;
                    }
                    ++n5;
                }
                this.cf = false;
                bI = true;
                bF = true;
                bE = true;
                di = Main.j.cY[this.be[this.cS]].aH + "\u653e\u751f\u6210\u529f";
                int n6 = 0;
                while (n6 < cY.length) {
                    if (this.be[this.cS] != cY.length - 1 && n6 > this.be[this.cS]) {
                        rf.e e2 = cY[n6 - 1];
                        Main.j.cY[n6 - 1] = cY[n6];
                        Main.j.cY[n6] = e2;
                        n2 = 0;
                        while (n2 < h.length) {
                            if (h[n2][0] == n6) {
                                Main.j.h[n2][0] = n6 - 1;
                                Main.j.h[n2][1] = Main.j.cY[n6 - 1].ae;
                            }
                            ++n2;
                        }
                    }
                    ++n6;
                }
                int n7 = 0;
                while (n7 < h.length) {
                    if (h[n7][0] != -1) {
                        e = n7;
                    }
                    ++n7;
                }
                n2 = this.be.length - 1;
                this.be = new int[n2];
                n2 = 0;
                int n8 = 0;
                while (n8 < cY.length) {
                    if (!Main.j.cY[n8].t.equals("-1")) {
                        this.be[n2] = n8;
                        ++n2;
                    }
                    ++n8;
                }
                this.cS = this.cS != 0 ? --this.cS : this.be.length - 1;
                aB = rf.b.a("/Image/" + Main.j.cY[this.be[this.cS]].t + ".png");
            }
        } else if (Main.a.d().s()) {
            if (this.cf) {
                this.cf = false;
            } else {
                aB = rf.b.a("/Image/" + Main.j.cY[Main.j.h[Main.j.e][0]].t + ".png");
                Main.j.i(0);
                Main.j.a();
                this.b(-1);
            }
        }
        Main.a.d().a();
    }

    final void a(Graphics graphics, rf.e e2, rf.e e3) {
        boolean bl = false;
        int n = 0;
        ++this.dA;
        e2.aS = e3.aa == 1 && this.as == 3 && this.dA <= 4 ? this.dA % 2 != 0 : true;
        e3.aS = e2.aa == 1 && this.as == 3 && this.dA <= 4 ? this.dA % 2 != 0 : true;
        graphics.drawImage(this.am, 0, 0, 0);
        Main.j.a(graphics, this.am, 0 + this.am.getWidth(), 0, 0, 0, this.am.getWidth(), this.am.getHeight());
        graphics.drawImage(this.am, 0, s - this.am.getHeight(), 0);
        Main.j.a(graphics, this.am, 0 + this.am.getWidth(), s - this.am.getHeight(), 0, 0, this.am.getWidth(), this.am.getHeight());
        n = this.am.getHeight();
        graphics.drawImage(this.ao, 0, n, 0);
        n = s - this.ao.getHeight() - this.am.getHeight();
        Main.j.a(graphics, this.ao, 0, n, 0, 0, this.ao.getWidth(), this.ao.getHeight());
        n = s / 2 - this.al.getHeight() / 2;
        graphics.drawImage(this.al, 0, n, 0);
        if (e2.aS && aB != null) {
            if (t == 320) {
                this.ap[0] = 10;
                this.aq[0] = 10;
                this.aq[1] = this.ap[1] = s - Main.k.v - 75;
            }
            graphics.drawImage(bd, this.aq[0] + aB.getWidth() / 2, this.aq[1] + aB.getHeight() + 7, 33);
            Main.j.a(graphics, aB, this.ap[0], this.ap[1], 0, 0, aB.getWidth(), aB.getHeight());
        }
        if (e3.aS && aC != null) {
            if (t == 320) {
                this.n[0] = this.m[0] = t - aC.getWidth() + 8;
                this.n[1] = this.m[1] = Main.k.v + aC.getHeight() + 5;
            }
            graphics.drawImage(bd, this.n[0], this.n[1] + 7, 33);
            graphics.drawImage(aC, this.m[0], this.m[1], 33);
        }
        int n2 = 5;
        int n3 = 270;
        int n4 = 204;
        int n5 = 20;
        if (t == 320) {
            n2 = 240;
            n3 = 144;
            n4 = 162;
            n5 = 54;
        }
        Main.e.a().b(graphics, P[23], n2, n3, e2.n, e2.n + 1);
        Main.e.a().b(graphics, P[23], n4, n5, e3.n, e3.n + 1);
        boolean bl2 = false;
        boolean bl3 = false;
        int n6 = 37;
        int n7 = 116;
        if (t == 320) {
            n6 = 128;
            n7 = 50;
        }
        if (this.d(e2, e3)[0] > this.d(e2, e3)[1]) {
            dd[0].b(195, 204);
            dd[0].b(graphics);
            dd[1].b(n6, n7);
            dd[1].b(graphics);
        } else if (this.d(e2, e3)[0] < this.d(e2, e3)[1]) {
            dd[0].b(37, 116);
            dd[0].b(graphics);
            dd[1].b(195, 204);
            dd[1].b(graphics);
        }
        dd[0].a(false);
        dd[1].a(false);
        int n8 = 0;
        int n9 = 0;
        int n10 = 0;
        if (t == 320) {
            n8 = 79;
            n9 = 30;
            n10 = 30;
        }
        Main.e.a();
        Main.e.a.stringWidth(e2.aH);
        int n11 = 0;
        Main.e.a();
        boolean bl4 = false;
        Main.e.a().a(graphics, 151 + n10, 310 - n8, e2.ag, e2.aE, 0);
        Main.e.a().b(graphics, 0, 190 + n10, 304 - n8, 1);
        Main.e.a();
        this.a(graphics, 151 + Main.e.f + n10, 310 - n8, e2.ag, e2.aE, 1);
        Main.e.a().a(graphics, 52, 310 - n8, e2.ax, e2.aF, 1);
        Main.e.a().b(graphics, 1, 20, 304 - n8, 1);
        Main.e.a();
        this.a(graphics, 52 + Main.e.f, 310 - n8, e2.ax, e2.aF, 1);
        if (t == 320) {
            rf.b.a(graphics, "" + e2.aD + "\u7ea7", 77, 200, 0, 0xFFFF00, 0);
        } else if (p == 2) {
            rf.b.a(graphics, "" + e2.aD + "\u7ea7", 5, 200, 0, 0xFFFF00, 0);
        } else {
            rf.b.a(graphics, "" + e2.aD + "\u7ea7", 35, 285, 0, 0xFFFF00, 0);
        }
        if (e2.Y != -1) {
            if (t == 320) {
                graphics.drawImage(this.aE, 81, 148, 0);
            } else {
                graphics.drawImage(this.aE, 10, 188, 0);
            }
        }
        Main.j.b(graphics, aZ, 144 + n8, 266 - n8, (4 - Main.j.cY[Main.j.h[Main.j.e][0]].o) * aZ.getWidth() / 4, 0, aZ.getWidth() / 4, aZ.getHeight());
        int n12 = t / 2;
        Main.e.a();
        n11 = n12 - Main.e.a.stringWidth(e3.aH) / 2;
        rf.b.a(graphics, e3.aH, n11, 0, 7750407, 0xFFFF00, 0);
        Main.e.a().a(graphics, 52, 6, e3.ag, e3.aE, 0);
        Main.e.a().b(graphics, 0, 20, 2, 1);
        Main.e.a();
        this.a(graphics, 52 + Main.e.f, 6, e3.ag, e3.aE, 1);
        if (p == 2) {
            rf.b.a(graphics, "" + e3.aD + "\u7ea7", 150, 25, 0, 0xFFFF00, 0);
        } else {
            rf.b.a(graphics, "" + e3.aD + "\u7ea7", 175, 25, 0, 0xFFFF00, 0);
        }
        if (e3.Y != -1) {
            graphics.drawImage(this.aF, 188, 99 - n9, 0);
        }
        Main.j.b(graphics, aZ, 53, 34, (4 - this.av.o) * aZ.getWidth() / 4, 0, aZ.getWidth() / 4, aZ.getHeight());
    }

    public final void b(Graphics graphics, rf.e e2, rf.e e3) {
        int n;
        int n2;
        switch (this.as) {
            case 0: {
                this.e(graphics, e2, e3);
                break;
            }
            case 1: {
                this.f(graphics, e2, e3);
                break;
            }
            case 2: {
                this.a(e2, e3);
                break;
            }
            case 10: {
                this.h(graphics, e2, e3);
                break;
            }
            case 9: {
                break;
            }
            case 3: {
                rf.e e4 = null;
                Object var5_5 = null;
                if (e2.aa == 1) {
                    e4 = e3;
                    e3.af = this.m[0];
                    e4.aR = this.m[1];
                }
                if (e3.aa == 1) {
                    e4 = e2;
                    e2.af = this.ap[0];
                    e4.aR = this.ap[1];
                }
                if (!dc.c()) {
                    if (e4.equals(e2)) {
                        dc.b(e4.af + aB.getWidth() / 2, e4.aR + aB.getHeight() / 2 + 10);
                    } else {
                        dc.b(e4.af, e4.aR);
                    }
                    dc.b(graphics);
                } else if (e3.aa == 1 || e2.aa == 1) {
                    this.a(e2, e3, 5);
                }
                dc.a(true);
                break;
            }
            case 5: {
                this.c(graphics, e2, e3);
                break;
            }
            case 6: {
                this.d(graphics, e2, e3);
                break;
            }
            case 7: {
                if (bI || !bx) break;
                bx = false;
                this.b(70);
                break;
            }
            case 8: {
                if (bI) break;
                if (e3.aa == 1) {
                    if (cN.equals(cA)) {
                        this.a(0);
                        n2 = 0;
                        while (n2 < cY.length) {
                            this.g(cY[n2]);
                            Main.j.cY[n2].ag = Main.j.cY[n2].aE;
                            Main.j.cY[n2].an = false;
                            ++n2;
                        }
                        break;
                    }
                    this.a(14);
                    break;
                }
                if (this.bq) {
                    this.c(e2, e3);
                    o.put("isWin", "true");
                    if (at == 0) {
                        o.put("fight_Value", "1");
                    } else {
                        o.put("fight_Value", "3");
                    }
                    this.bq = false;
                }
                if (bI) break;
                bI = true;
                bF = true;
                bJ = true;
                di = "";
                n2 = 0;
                while (n2 < this.aa) {
                    di = this.Z < this.bf.length ? di + Main.j.cY[this.bf[this.Z]].aH + "\u83b7\u5f97" + Main.j.cY[this.bf[this.Z]].Q + "\u7ecf\u9a8c^" : di + Main.j.cY[this.bg[this.Z - this.bf.length]].aH + "\u83b7\u5f97" + Main.j.cY[this.bg[this.Z - this.bf.length]].Q + "\u7ecf\u9a8c^";
                    ++this.Z;
                    ++n2;
                }
                this.Z = 0;
                this.aa = 0;
                this.a(null, null, 11);
                break;
            }
            case 11: {
                if (bI) break;
                if (this.bD) {
                    bI = true;
                    bF = true;
                    bJ = true;
                    di = "\u83b7\u5f97" + this.dh + "x1^\u83b7\u5f97" + this.ae + "\u91d1";
                    this.a(null, null, 12);
                    break;
                }
                di = "";
                this.a(null, null, 13);
                break;
            }
            case 12: {
                if (bI) break;
                di = "";
                di = "\u606d\u559c\u5347\u7ea7\uff01^";
                n2 = 0;
                while (n2 < cY.length) {
                    if (Main.j.cY[n2].aq) {
                        bI = true;
                        bF = true;
                        bJ = true;
                        di = di + Main.j.cY[n2].aH + "\u5347\u7ea7\uff01\u76ee\u524d\u7b49\u7ea7:" + Main.j.cY[n2].aD + "\u7ea7^";
                    }
                    ++n2;
                }
                if (bI) {
                    this.a(null, null, 13);
                    break;
                }
                this.a(null, null, 13);
                break;
            }
            case 13: {
                if (bI) break;
                this.a(0);
            }
        }
        n2 = 5 + this.co - e2.o;
        if (n2 < this.aj) {
            this.f(e2);
        }
        if ((n = 5 + this.cp - e3.o) < this.ak) {
            this.f(e3);
        }
    }

    public final void a(Graphics graphics, rf.e e2) {
        M[0].b(graphics);
        M[0].b(t / 2, s / 2);
        switch (Main.j.M[0].aO) {
            case 0: {
                if (M[0].c()) {
                    Main.b.a(0);
                    if (this.ch) {
                        ++Main.l.a;
                        this.cg = true;
                        this.cU = 1;
                        M[0].a(1);
                        this.ch = false;
                    }
                }
                M[0].a(false);
            }
        }
        if (Main.j.M[0].aO != 0) {
            if (Main.a.d().w() || Main.a.d().k()) {
                if (this.cU > 0) {
                    --this.cU;
                }
                if (this.cU == 0) {
                    this.cU = 6;
                }
                M[0].a(this.cU);
            } else if (Main.a.d().e() || Main.a.d().u()) {
                this.cU = this.cU < 6 ? ++this.cU : 0;
                if (this.cU == 0) {
                    this.cU = 1;
                }
                M[0].a(this.cU);
            } else if (Main.a.d().h() || Main.a.d().m()) {
                if (Main.j.M[0].aO == 5) {
                    if (e2.ak && !e2.ar) {
                        this.b(70);
                    } else {
                        bI = true;
                        bF = true;
                        di = dl + "\u4e0d\u80fd\u6362\u4ed9\u5ba0";
                    }
                }
                if (Main.j.M[0].aO == 4) {
                    int n = (60 + e2.aD - this.av.aD + e2.o * e2.o - this.av.o * this.av.o) * 4 / 10;
                    int n2 = Math.abs(this.cJ.nextInt()) % 100;
                    if (!e2.aj) {
                        bI = true;
                        bF = true;
                        di = dl + "\u4e0d\u80fd\u9003\u8dd1";
                        return;
                    }
                    if (!e2.ar && at == 0 && n2 < n) {
                        bI = true;
                        bF = true;
                        di = "\u9003\u8dd1\u6210\u529f";
                        this.b(15);
                        o.put("fight_Value", "1");
                    } else {
                        bI = true;
                        bF = true;
                        di = "\u9003\u8dd1\u5931\u8d25";
                        this.b(-1);
                        this.a(e2, this.av, 0);
                    }
                } else if (Main.j.M[0].aO == 2) {
                    this.b(14);
                } else if (Main.j.M[0].aO == 1) {
                    this.cR = 0;
                    this.b(13);
                } else if (Main.j.M[0].aO == 3) {
                    this.b(9);
                } else if (Main.j.M[0].aO == 6) {
                    this.b(72);
                    cX = 7;
                }
            }
        }
        Main.a.d();
        Main.a.a = -99;
    }

    public final void d(Graphics graphics) {
        int n = 0;
        int n2 = 0;
        while (n2 < cY.length) {
            if (!Main.j.cY[n2].t.equals("-1")) {
                ++n;
            }
            ++n2;
        }
        this.be = new int[n + 1];
        this.be[0] = -1;
        n = 1;
        int n3 = 0;
        while (n3 < cY.length) {
            if (!Main.j.cY[n3].t.equals("-1")) {
                this.be[n] = n3;
                ++n;
            }
            ++n3;
        }
        int n4 = 0;
        int n5 = 200 / P[14].getHeight();
        if (200 % P[14].getHeight() != 0) {
            ++n5;
        }
        int n6 = t / 2 - P[12].getWidth() / 2;
        int n7 = s / 2 - (n5 * P[14].getHeight() + P[12].getHeight() * 2) / 2;
        Main.e.a().b(graphics, n6, n7, 200);
        n4 = (Main.k.v + 5) * 3;
        String[] stringArray = new String[]{"\u7a7a", "\u7a7a", "\u7a7a"};
        String[] stringArray2 = null;
        stringArray2 = new String[3];
        int n8 = 0;
        while (n8 < h.length) {
            stringArray2[n8] = h[n8][0] != -1 ? Main.j.cY[Main.j.h[n8][0]].aH : "\u7a7a\u51fa\u8be5\u4f4d\u7f6e";
            ++n8;
        }
        if (p == 2) {
            Main.e.a().a(graphics, stringArray2, n6 + 10, 10, P[12].getWidth() - 30, n4, this.cR, true, 2);
        } else {
            Main.e.a().a(graphics, stringArray2, n6 + 10, n7 + 15, P[12].getWidth() - 30, n4, this.cR, true, 2);
        }
        int[] nArray = new int[]{19, 85, 154, 150};
        int n9 = 0;
        if (t == 320) {
            n9 = 38;
        }
        if (h[this.cR][1] != -1) {
            this.a(graphics, nArray[0] + 15 + n9, n7 - 125 + nArray[1] + 5, h[this.cR][0], cY);
        }
        if (this.bB) {
            this.a(graphics, 0, cY);
        }
        if (Main.a.d().x()) {
            Main.j.N[0].y = 0;
            if (!this.bB) {
                --this.cR;
                if (this.cR < 0) {
                    this.cR = 2;
                }
            }
            if (h[this.cR][0] == -1) {
                this.cS = 0;
            } else {
                int n10 = 0;
                while (n10 < cY.length) {
                    if (n10 == h[this.cR][0]) {
                        this.cS = n10 + 1;
                    }
                    ++n10;
                }
            }
            return;
        }
        if (Main.a.d().f()) {
            Main.j.N[0].y = 0;
            if (!this.bB) {
                ++this.cR;
                if (this.cR > 2) {
                    this.cR = 0;
                }
            }
            if (h[this.cR][0] == -1) {
                this.cS = 0;
            } else {
                int n11 = 0;
                while (n11 < cY.length) {
                    if (n11 == h[this.cR][0]) {
                        this.cS = n11 + 1;
                    }
                    ++n11;
                }
            }
            return;
        }
        if (Main.a.d().l() && df == 2) {
            int n12;
            --this.cS;
            if (this.cS < 0) {
                this.cS = this.be.length - 1;
            }
            int n13 = 0;
            while (n13 < h.length) {
                System.out.println("Fightpets[" + n13 + "][0]=" + h[n13][0] + ":" + this.be[this.cS] + ":" + this.cS);
                n12 = 0;
                if (h[n13][0] == this.be[this.cS] && this.be[this.cS] != -1) {
                    n12 = 1;
                }
                block6: while (n12 != 0) {
                    n12 = 0;
                    --this.cS;
                    if (this.cS < 0) {
                        this.cS = 0;
                    }
                    int n14 = 0;
                    while (n14 < h.length) {
                        if (h[n14][0] == this.be[this.cS] && this.be[this.cS] != -1) {
                            n12 = 1;
                            continue block6;
                        }
                        ++n14;
                    }
                }
                ++n13;
            }
            if (this.be[this.cS] == -1) {
                Main.j.h[this.cR][0] = -1;
                Main.j.h[this.cR][1] = -1;
            } else {
                Main.j.h[this.cR][0] = this.be[this.cS];
                Main.j.h[this.cR][1] = Main.j.cY[this.be[this.cS]].ae;
            }
            n12 = 0;
            while (n12 < h.length) {
                if (h[n12][0] != -1) {
                    e = n12;
                    break;
                }
                ++n12;
            }
            return;
        }
        if (Main.a.d().v() && df == 2) {
            int n15;
            System.out.println("r=" + this.cR + ":" + this.cS);
            this.cS = this.cS < this.be.length - 1 ? ++this.cS : 0;
            System.out.println("r2=" + this.cR + ":" + this.cS);
            int n16 = 0;
            while (n16 < h.length) {
                System.out.println("Fightpets[" + n16 + "][0]=" + h[n16][0] + ":" + this.be[this.cS] + ":" + this.cS);
                n15 = 0;
                if (h[n16][0] == this.be[this.cS] && this.be[this.cS] != -1) {
                    n15 = 1;
                }
                block10: while (n15 != 0) {
                    n15 = 0;
                    ++this.cS;
                    if (this.cS > this.be.length - 1) {
                        this.cS = 0;
                    }
                    int n17 = 0;
                    while (n17 < h.length) {
                        if (h[n17][0] == this.be[this.cS] && this.be[this.cS] != -1) {
                            n15 = 1;
                            continue block10;
                        }
                        ++n17;
                    }
                }
                ++n16;
            }
            if (this.be[this.cS] == -1) {
                Main.j.h[this.cR][0] = -1;
                Main.j.h[this.cR][1] = -1;
            } else {
                Main.j.h[this.cR][0] = this.be[this.cS];
                Main.j.h[this.cR][1] = Main.j.cY[this.be[this.cS]].ae;
            }
            n15 = 0;
            while (n15 < h.length) {
                if (h[n15][0] != -1) {
                    e = n15;
                    break;
                }
                ++n15;
            }
            return;
        }
        if (Main.a.d().i()) {
            if (df == 2) {
                if (this.bB) {
                    this.bB = false;
                } else {
                    int n18 = 0;
                    int n19 = 0;
                    while (n19 < h.length) {
                        if (h[n19][0] != -1) {
                            ++n18;
                        }
                        ++n19;
                    }
                    if (n18 == 0) {
                        bF = true;
                        bE = true;
                        bI = true;
                        di = "\u6218\u6597\u4f4d\u7f6e\u4e0d\u80fd\u5168\u7a7a";
                        return;
                    }
                    this.b(5);
                }
            } else if (df == 4 && !bI) {
                if (h[this.cR][0] != -1) {
                    if (Main.j.cY[Main.j.h[this.cR][0]].ag <= 1) {
                        bI = true;
                        bF = true;
                        di = Main.j.cY[Main.j.h[this.cR][0]].aH + "\u5df2\u6b7b\u4ea1\uff01";
                    } else {
                        e = this.cR;
                        aB = rf.b.a("/Image/" + Main.j.cY[Main.j.h[this.cR][0]].t + ".png");
                        Main.j.h[this.cR][1] = Main.j.cY[Main.j.h[this.cR][0]].ae;
                        this.g(cY[h[this.cR][0]]);
                        cY[h[this.cR][0]].b(this.m[0], this.m[1]);
                        this.a(cY[h[this.cR][0]], this.av, 0);
                        this.b(-1);
                        Main.j.dd[0].y = 0;
                        Main.j.dd[1].y = 0;
                        this.by = false;
                    }
                } else {
                    bI = true;
                    bF = true;
                    di = "\u8bf7\u9009\u62e9\u6218\u6597\u4ed9\u5ba0\uff01";
                }
            }
            return;
        }
        if (Main.a.d().s()) {
            if (df == 2) {
                if (this.bB) {
                    this.bB = false;
                } else {
                    int n20 = 0;
                    int n21 = 0;
                    while (n21 < h.length) {
                        if (h[n21][0] != -1) {
                            ++n20;
                        }
                        ++n21;
                    }
                    if (n20 == 0) {
                        bF = true;
                        bE = true;
                        bI = true;
                        di = "\u6218\u6597\u4f4d\u7f6e\u4e0d\u80fd\u5168\u7a7a";
                        return;
                    }
                    this.b(5);
                }
                return;
            }
            if (df == 4 && !this.by) {
                this.b(this.cu);
            }
        }
    }

    public final void a(Graphics graphics, int n, int n2, int n3, rf.e[] eArray) {
        int[][] nArrayArray;
        Main.e.a().b(graphics, 0, n + 10, n2 + 127, 0);
        Main.e.a().b(graphics, 1, n + 10, n2 + 147, 0);
        Main.e.a().b(graphics, 2, n + 10, n2 + 167, 0);
        Main.e.a().a(graphics, n + 45, n2 + 127 + 5, eArray[n3].ag, eArray[n3].aE, 0);
        Main.e.a().a(graphics, n + 45, n2 + 147 + 5, eArray[n3].ax, eArray[n3].aF, 1);
        Main.e.a().a(graphics, n + 45, n2 + 167 + 5, eArray[n3].Z, eArray[n3].aC, 2);
        Main.e.a();
        this.a(graphics, n + 45 + Main.e.f, n2 + 127 + 5, eArray[n3].ag, eArray[n3].aE, 0);
        Main.e.a();
        this.a(graphics, n + 45 + Main.e.f, n2 + 147 + 5, eArray[n3].ax, eArray[n3].aF, 0);
        Main.e.a();
        this.a(graphics, n + 45 + Main.e.f, n2 + 167 + 5, eArray[n3].Z, eArray[n3].aC, 0);
        int n4 = 0;
        int n5 = 0;
        int n6 = eArray[n3].ay;
        int n7 = eArray[n3].aG;
        int n8 = eArray[n3].aA;
        int n9 = eArray[n3].aB;
        int n10 = eArray[n3].az;
        int n11 = eArray[n3].aD;
        int n12 = eArray[n3].au;
        int n13 = -1;
        int n14 = 0;
        while (n14 < h.length) {
            if (h[n14][0] == n3 && dp != 18) {
                n13 = n14;
                break;
            }
            ++n14;
        }
        int n15 = 0;
        if (t == 320) {
            n15 = 2;
            nArrayArray = new int[][]{{12, 185, 0, n6}, {12, 201, 1, n7}, {12, 217, 2, n8}, {121, 130, 5, n12}, {121, 146, 6, n13 + 1}, {121, 162, 7, n11}};
        } else {
            nArrayArray = new int[][]{{12, 185, 0, n6}, {12, 201, 1, n7}, {12, 217, 2, n8}, {12, 233, 3, n9}, {12, 249, 4, n10}, {121, 130, 5, n12}, {121, 146, 6, n13 + 1}, {121, 162, 7, n11}};
        }
        int n16 = 0;
        while (n16 < nArrayArray.length) {
            n4 = P[4].getWidth();
            n5 = P[4].getHeight() / 13;
            if (n16 == 5 - n15) {
                Main.j.b(graphics, P[4], n + nArrayArray[n16][0], n2 + nArrayArray[n16][1], 0, nArrayArray[n16][2] * n5, n4, n5);
                if (n12 >= 0) {
                    graphics.drawImage(cl[n12], n + nArrayArray[5][0] + n4 + 10 - 2, n2 + nArrayArray[5][1] + 2 - 3, 0);
                } else {
                    rf.b.a(graphics, "\u7a7a", n + nArrayArray[5 - n15][0] + n4 + 10 - 2, n2 + nArrayArray[5 - n15][1] + 2 - 3, 0xFF0000, 0, 0);
                }
            } else if (n16 == 4) {
                Main.j.b(graphics, P[4], n + nArrayArray[n16][0], n2 + nArrayArray[n16][1], 0, nArrayArray[n16][2] * n5, n4, n5);
                if (nArrayArray[n16][3] > 0) {
                    rf.b.a(graphics, P[7], nArrayArray[n16][3], n + nArrayArray[n16][0] + n4 + 10, n2 + nArrayArray[n16][1] + 2, 0);
                } else {
                    rf.b.a(graphics, "\u7a7a", n + nArrayArray[n16][0] + n4 + 10, n2 + nArrayArray[n16][1] + 2, 0xFF0000, 0, 0);
                }
            } else if (nArrayArray[n16][3] >= 0) {
                Main.j.b(graphics, P[4], n + nArrayArray[n16][0], n2 + nArrayArray[n16][1], 0, nArrayArray[n16][2] * n5, n4, n5);
                rf.b.a(graphics, P[7], nArrayArray[n16][3], n + nArrayArray[n16][0] + n4 + 10, n2 + nArrayArray[n16][1] + 2, 0);
            }
            ++n16;
        }
        int n17 = eArray[n3].p;
        int n18 = eArray[n3].l;
        int n19 = eArray[n3].k;
        int n20 = eArray[n3].q;
        int n21 = eArray[n3].m;
        int[][] nArrayArray2 = t == 320 ? new int[][]{{87, 185, 8, n17}, {87, 201, 9, n18}, {87, 217, 10, n19}} : new int[][]{{87, 185, 8, n17}, {87, 201, 9, n18}, {87, 217, 10, n19}, {87, 233, 11, n20}, {87, 249, 12, n21}};
        int n22 = 0;
        while (n22 < nArrayArray2.length) {
            n4 = P[4].getWidth();
            n5 = P[4].getHeight() / 13;
            if (nArrayArray2[n22][3] != -1) {
                Main.j.b(graphics, P[4], n + nArrayArray2[n22][0], n2 + nArrayArray2[n22][1], 0, nArrayArray2[n22][2] * n5, n4, n5);
                rf.b.a(graphics, P[7], nArrayArray2[n22][3], n + nArrayArray2[n22][0] + n4 + 10, n2 + nArrayArray2[n22][1] + 2, 0);
            }
            ++n22;
        }
    }

    public final void a(Graphics graphics, String string) {
        Main.e.a().a(graphics, P[18], 0, 0, t, s, false, 10173496, 14662027, 10173496);
        bF = true;
        Main.j.a(graphics, string, 10, 20);
        graphics.setClip(0, 0, t, s);
        Main.j.b(graphics, P[10], t - 3 - P[10].getWidth() / 2, s - P[10].getHeight() - 3, P[10].getWidth() / 2, 0, P[10].getWidth() / 2, P[10].getHeight());
        if (!Main.a.d().j() && Main.a.d().t()) {
            bC = false;
            bk = false;
            cW = 0;
        }
        Main.a.d().a();
        Main.a.d().s = false;
    }

    public final void b(Graphics graphics, int n) {
        int[] nArray;
        String[] stringArray;
        Vector vector = null;
        Vector vector2 = null;
        if (n == 0) {
            vector = dB;
        } else if (n == 1) {
            vector = dC;
        } else if (n == 3) {
            vector = dB;
            vector2 = dC;
        }
        boolean bl = false;
        int n2 = 200 / P[14].getHeight();
        if (200 % P[14].getHeight() != 0) {
            ++n2;
        }
        int n3 = t / 2 - P[12].getWidth() / 2;
        int n4 = s / 2 - (n2 * P[14].getHeight() + P[12].getHeight() * 2) / 2;
        Main.e.a().b(graphics, n3, n4, 200);
        int[] nArray2 = new int[]{20, 19, 148, 22};
        if (n == 0) {
            Main.e.a().a(graphics, null, n3 + nArray2[0], n4 + nArray2[1], nArray2[2], nArray2[3], false, 0xFFFFFF, 11499058, 15709554);
        }
        int n5 = 0;
        n5 = cy >= 100 && cy < 1000 ? 3 : (cy >= 1000 && cy < 10000 ? 4 : 5);
        int n6 = P[21].getWidth() + 5 + n5 * P[7].getWidth() / 10;
        int n7 = n3 + nArray2[0] + nArray2[2] / 2 - n6 / 2;
        int n8 = n4 + nArray2[1] + nArray2[3] / 2 - P[21].getHeight() / 2;
        int n9 = n4 + nArray2[1] + nArray2[3] / 2 - P[7].getHeight() / 2;
        if (n == 0 || n == 1) {
            if (vector.size() == 0) {
                stringArray = new String[1];
                nArray = new int[1];
                stringArray[0] = n == 0 ? "\u6ca1\u6709\u7269\u54c1" : "\u6ca1\u6709\u6cd5\u5b9d";
                nArray[0] = -1;
            } else {
                stringArray = new String[vector.size()];
                nArray = new int[vector.size()];
            }
        } else {
            int n10;
            int n11 = vector.size();
            if (n11 + (n10 = vector2.size() - 1) <= 0) {
                stringArray = new String[1];
                nArray = new int[1];
                stringArray[0] = "\u6ca1\u6709\u7269\u54c1\u53ef\u5356";
                nArray[0] = -1;
            } else if (vector2 == null) {
                stringArray = new String[vector.size()];
                nArray = new int[vector.size()];
            } else {
                stringArray = new String[vector.size() + vector2.size() - 1];
                nArray = new int[vector.size() + vector2.size() - 1];
            }
        }
        d d2 = null;
        i i2 = null;
        int[] nArray3 = new int[]{20, 162, 148, 68};
        int n12 = 0;
        while (n12 < (vector2 == null ? vector.size() : vector.size() + vector2.size() - 1)) {
            if (n == 0) {
                d2 = (d)vector.elementAt(n12);
                stringArray[n12] = Main.k.E[d2.b][0] + "    x" + String.valueOf(d2.a);
                nArray[n12] = d2.b;
                if (n12 == this.cR) {
                    Main.e.a().a(graphics, P[11], n3 + nArray3[0], n4 + nArray3[1], nArray3[2], nArray3[3], false, 10173496, 14662027, 10173496);
                    this.a(graphics, Main.k.E[d2.b][1] + "^", 130, 60, n3 + nArray3[0] + 10, n4 + nArray3[1] + 10, 0xFFFFFF);
                    graphics.setClip(0, 0, t, s);
                }
            } else if (n == 1) {
                i2 = (i)vector.elementAt(n12);
                if (i2.b == 21) {
                    nArray[n12] = i2.b;
                    stringArray[n12] = Main.k.E[i2.b][0];
                } else {
                    nArray[n12] = i2.b;
                    stringArray[n12] = Main.k.E[i2.b][0] + "    x" + String.valueOf(i2.a);
                }
                if (n12 == this.cR) {
                    Main.e.a().a(graphics, P[11], n3 + nArray3[0], n4 + nArray3[1], nArray3[2], nArray3[3], false, 10173496, 14662027, 10173496);
                    this.a(graphics, Main.k.E[i2.b][1] + "^", 90, 60, n3 + nArray3[0] + 10 + 50, n4 + nArray3[1] + 10, 0xFFFFFF);
                    graphics.setClip(0, 0, t, s);
                    if (ai == null) {
                        ai = rf.b.a("/Image/fb" + (i2.b - 21 + 22) + "_big.png");
                    }
                    graphics.drawImage(ai, n3 + nArray3[0] + 10, n4 + nArray3[1] + 10, 0);
                    de.b(n3 + nArray3[0] + 10 + 25, n4 + nArray3[1] + 10 + 35);
                    de.b(graphics);
                    de.a(true);
                    graphics.setClip(0, 0, t, s);
                }
            } else if (n == 3) {
                if (n12 < vector.size()) {
                    d2 = (d)vector.elementAt(n12);
                    stringArray[n12] = Main.k.E[d2.b][0] + "    x" + String.valueOf(d2.a) + "  " + Integer.parseInt(Main.k.E[d2.b][3]) + "\u91d1";
                    nArray[n12] = d2.b;
                    if (n12 == this.cR) {
                        Main.e.a().a(graphics, P[11], n3 + nArray3[0], n4 + nArray3[1], nArray3[2], nArray3[3], false, 10173496, 14662027, 10173496);
                        this.a(graphics, Main.k.E[d2.b][1] + "^", 130, 60, n3 + nArray3[0] + 10, n4 + nArray3[1] + 10, 0xFFFFFF);
                        graphics.setClip(0, 0, t, s);
                    }
                } else {
                    i2 = (i)vector2.elementAt(n12 - vector.size() + 1);
                    if (i2.b == 21) {
                        nArray[n12] = i2.b;
                        stringArray[n12] = Main.k.E[i2.b][0] + nArray[n12];
                    } else {
                        nArray[n12] = i2.b;
                        stringArray[n12] = Main.k.E[i2.b][0];
                    }
                    if (n12 == this.cR) {
                        Main.e.a().a(graphics, P[11], n3 + nArray3[0], n4 + nArray3[1], nArray3[2], nArray3[3], false, 10173496, 14662027, 10173496);
                        this.a(graphics, Main.k.E[i2.b][1] + "^", 90, 60, n3 + nArray3[0] + 10 + 50, n4 + nArray3[1] + 10, 0xFFFFFF);
                        graphics.setClip(0, 0, t, s);
                        if (ai == null) {
                            ai = rf.b.a("/Image/fb" + (i2.b - 21 + 22) + "_big.png");
                        }
                        graphics.drawImage(ai, n3 + nArray3[0] + 10, n4 + nArray3[1] + 10, 0);
                        de.b(n3 + nArray3[0] + 10 + 25, n4 + nArray3[1] + 10 + 35);
                        de.b(graphics);
                        de.a(true);
                        graphics.setClip(0, 0, t, s);
                    }
                }
            }
            ++n12;
        }
        if (n == 0) {
            if (cy < 0) {
                cy = 0;
            }
            graphics.drawImage(P[21], n7, n8, 0);
            rf.b.b(graphics, P[7], cy, n7 + P[21].getWidth() + 5, n9, 5);
        }
        Main.e.a().a(graphics, stringArray, n3 + nArray2[0] + 45, n4 + nArray2[1] + nArray2[3], nArray2[2], 200 - nArray3[3] - 10, this.cR, false, 1);
        Main.e.a().a(graphics, nArray, n3 + nArray2[0] + 10, n4 + nArray2[1] + nArray2[3], 200 - nArray3[3] - 10, this.cR);
        if (this.bB) {
            this.a(graphics, 1, cY);
        }
        if (Main.a.d().x()) {
            if (!this.bB) {
                Main.j.N[0].y = 0;
                --this.cR;
                if (this.cR < 0) {
                    this.cR = stringArray.length - 1;
                }
                ai = rf.b.a("/Image/fb" + (nArray[this.cR] + 22) + "_big.png");
                bE = true;
                this.ck = (byte)nArray[this.cR];
                System.out.println("dd=" + this.ck + ":" + this.cR);
            }
            return;
        }
        if (Main.a.d().f()) {
            if (!this.bB) {
                Main.j.N[0].y = 0;
                ++this.cR;
                if (this.cR > stringArray.length - 1) {
                    this.cR = 0;
                }
                bE = true;
                this.ck = (byte)nArray[this.cR];
                ai = rf.b.a("/Image/fb" + (nArray[this.cR] + 22) + "_big.png");
            }
            return;
        }
        if (Main.a.d().l()) {
            if (this.bB) {
                --this.cS;
                if (this.cS < 0) {
                    this.cS = this.be.length - 1;
                }
                aB = rf.b.a("/Image/" + Main.j.cY[this.cS].t + ".png");
            }
            return;
        }
        if (Main.a.d().v()) {
            if (this.bB) {
                ++this.cS;
                if (this.cS > this.be.length - 1) {
                    this.cS = 0;
                }
                aB = rf.b.a("/Image/" + Main.j.cY[this.cS].t + ".png");
            }
            return;
        }
        if (Main.a.d().i() || Main.a.d().n()) {
            if (this.as == 1 || df == 2) {
                if (!this.bB) {
                    this.ck = (byte)nArray[this.cR];
                }
                if (n == 3) {
                    this.ce = false;
                    if (stringArray[0].indexOf("\u6ca1\u6709") == -1) {
                        this.g(this.ck, 1);
                    }
                    this.cR = 0;
                    Main.a.d().a();
                    return;
                }
                if (stringArray[0].indexOf("\u6ca1\u6709") == -1) {
                    if (this.ck == 17 || this.ck == 18 || this.ck == 19 || this.ck == 20) {
                        if (this.ci) {
                            bI = true;
                            bF = true;
                            di = "\u6b64\u602a\u6709\u4e3b\uff0c\u4e0d\u80fd\u6293\u53d6\uff01";
                            return;
                        }
                        if (df == 4) {
                            db = Main.j.a(Main.k.B[6], 0);
                            Main.j.cY[this.cS].aa = 0;
                            this.a(cY[this.cS], this.av, (int)this.ck, this.cS);
                            this.a(cY[this.cS], this.av, 9);
                            this.b(-1);
                            this.bB = false;
                        }
                    } else if (!this.bB) {
                        this.bB = true;
                        di = "";
                        bF = true;
                        this.V = 0;
                        int n13 = 0;
                        while (n13 < cY.length) {
                            if (!Main.j.cY[n13].t.equals("-1")) {
                                ++this.V;
                            }
                            ++n13;
                        }
                        this.be = new int[this.V];
                        this.V = 0;
                        int n14 = 0;
                        while (n14 < cY.length) {
                            if (!Main.j.cY[n14].t.equals("-1")) {
                                this.be[this.V] = n14;
                                ++this.V;
                            }
                            ++n14;
                        }
                        this.V = 0;
                        aB = rf.b.a("/Image/guai" + Main.j.cY[0].ae + ".png");
                        db = Main.j.a(Main.k.B[2], 0);
                        this.cS = 0;
                    } else {
                        if (Main.j.cY[this.cS].ag <= 0 && (this.ck == 0 || this.ck == 1 || this.ck == 2)) {
                            bI = true;
                            bF = true;
                            di = Main.j.cY[this.cS].aH + "\u5df2\u6b7b\u4ea1\uff0c\u8bf7\u5148\u590d\u6d3b\uff01";
                            return;
                        }
                        Main.j.cY[this.cS].aa = 0;
                        db = Main.j.a(Main.k.B[2], 0);
                        if (df == 4) {
                            this.a(cY[this.cS], null, 9);
                            this.a(cY[this.cS], null, (int)this.ck, this.cS);
                        } else {
                            if (n == 1 && Main.j.cY[this.cS].au != -1) {
                                this.a(cY[this.cS], null, 21, this.cS);
                            }
                            if (this.ck != 21) {
                                this.a(cY[this.cS], null, (int)this.ck, this.cS);
                            }
                            this.bB = false;
                        }
                    }
                }
            }
            this.cR = 0;
            return;
        }
        if (Main.a.d().s()) {
            if (n == 3) {
                Main.j.i(0);
                Main.j.a();
                this.b(-1);
                return;
            }
            if (this.bB) {
                cY[this.cS].b(this.m[0], this.m[1]);
                this.bB = false;
                return;
            }
            aB = rf.b.a("/Image/guai" + h[e][1] + ".png");
            this.cS = 0;
            this.b(this.cu);
        }
    }

    public final void c(Graphics graphics, int n) {
        this.a(graphics, n, cY);
        if (this.cf) {
            this.b(graphics, "\u662f\u5426\u5bc4\u5b58\u8be5\u4ed9\u5ba0");
        }
        if (Main.a.d().l()) {
            this.cR = 0;
            if (this.cS > 0) {
                --this.cS;
            }
            aB = rf.b.a("/Image/" + Main.j.cY[this.be[this.cS]].t + ".png");
        } else if (Main.a.d().v()) {
            this.cR = 0;
            if (this.cS < this.be.length - 1) {
                ++this.cS;
            }
            aB = rf.b.a("/Image/" + Main.j.cY[this.be[this.cS]].t + ".png");
        }
        if (Main.a.d().i() || Main.a.d().n()) {
            if (!this.cf) {
                this.cf = true;
            } else {
                int n2;
                int n3 = 0;
                boolean bl = false;
                int n4 = 0;
                while (n4 < h.length) {
                    if (h[n4][0] != -1) {
                        ++n3;
                    }
                    if (h[n4][0] == this.be[this.cS]) {
                        bl = true;
                    }
                    ++n4;
                }
                if (n3 == 1 && bl) {
                    this.cf = false;
                    bI = true;
                    bF = true;
                    bE = true;
                    di = Main.j.cY[this.be[this.cS]].aH + "\u5bc4\u5b58\u5931\u8d25\uff01" + "\u81f3\u5c11\u8981\u6709\u4e00\u4e2a\u4ed9\u5ba0\u53c2\u52a0\u6218\u6597";
                    return;
                }
                int n5 = 0;
                int n6 = 0;
                while (n6 < cZ.length) {
                    if (Main.j.cZ[n6].t.equals("-1")) {
                        ++n5;
                        Main.j.cZ[n6] = cY[this.be[this.cS]].a();
                        this.g(cZ[n6]);
                        break;
                    }
                    ++n6;
                }
                if (n5 == 0) {
                    this.cf = false;
                    bI = true;
                    bF = true;
                    bE = true;
                    di = "\u5bc4\u5b58\u5931\u8d25\uff01\u5b58\u50a8\u5df2\u6ee1\uff01\u8bf7\u5148\u653e\u751f\u4ed9\u5ba0";
                    return;
                }
                Main.j.cY[this.be[this.cS]].ae = -1;
                Main.j.cY[this.be[this.cS]].ab = -1;
                Main.j.cY[this.be[this.cS]].t = "-1";
                int n7 = 0;
                while (n7 < h.length) {
                    if (h[n7][0] == this.be[this.cS]) {
                        Main.j.h[n7][1] = -1;
                        Main.j.h[n7][0] = -1;
                    }
                    ++n7;
                }
                this.cf = false;
                bI = true;
                bF = true;
                bE = true;
                di = Main.j.cY[this.be[this.cS]].aH + "\u5bc4\u5b58\u6210\u529f";
                int n8 = 0;
                while (n8 < cY.length) {
                    if (this.be[this.cS] != cY.length - 1 && n8 > this.be[this.cS]) {
                        rf.e e2 = cY[n8 - 1];
                        Main.j.cY[n8 - 1] = cY[n8];
                        Main.j.cY[n8] = e2;
                        n2 = 0;
                        while (n2 < h.length) {
                            if (h[n2][0] == n8) {
                                Main.j.h[n2][0] = n8 - 1;
                                Main.j.h[n2][1] = Main.j.cY[n8 - 1].ae;
                            }
                            ++n2;
                        }
                    }
                    ++n8;
                }
                int n9 = 0;
                while (n9 < h.length) {
                    if (h[n9][0] != -1) {
                        e = n9;
                    }
                    ++n9;
                }
                n2 = this.be.length - 1;
                this.be = new int[n2];
                n2 = 0;
                int n10 = 0;
                while (n10 < cY.length) {
                    if (!Main.j.cY[n10].t.equals("-1")) {
                        this.be[n2] = n10;
                        ++n2;
                    }
                    ++n10;
                }
                this.cS = this.cS != 0 ? --this.cS : this.be.length - 1;
                aB = rf.b.a("/Image/" + Main.j.cY[this.be[this.cS]].t + ".png");
            }
        } else if (Main.a.d().s()) {
            if (this.cf) {
                this.cf = false;
            } else {
                aB = rf.b.a("/Image/" + Main.j.cY[Main.j.h[Main.j.e][0]].t + ".png");
                Main.j.i(0);
                Main.j.a();
                this.b(-1);
            }
        }
        Main.a.d().a();
    }

    public final void a(rf.e e2, Graphics graphics) {
        boolean bl = false;
        int n = 200 / P[14].getHeight();
        if (200 % P[14].getHeight() != 0) {
            ++n;
        }
        int n2 = t / 2 - P[12].getWidth() / 2;
        int n3 = s / 2 - (n * P[14].getHeight() + P[12].getHeight() * 2) / 2;
        Main.e.a().b(graphics, n2, n3, 200);
        int[] nArray = new int[]{20, 19, 148, 22};
        int[] nArray2 = new int[]{20, 162, 148, 68};
        int n4 = 0;
        int n5 = h[e][0];
        int n6 = 0;
        while (n6 < cC[n5].length) {
            if (cC[n5][n6] != -1) {
                ++n4;
            }
            ++n6;
        }
        String[][] stringArray = new String[n4][3];
        n4 = 0;
        int n7 = 0;
        while (n7 < cC[n5].length) {
            if (cC[n5][n7] != -1) {
                stringArray[n4][0] = Main.k.F[cC[n5][n7]][1];
                stringArray[n4][1] = Main.k.F[cC[n5][n7]][2];
                stringArray[n4][2] = String.valueOf(cC[n5][n7]);
                ++n4;
            }
            ++n7;
        }
        Main.e.a().a(graphics, stringArray, 0, n2 + nArray[0], n3 + nArray[1] + nArray[3], nArray[2], 200 - nArray2[3], this.cR, true, 1);
        Main.e.a().a(graphics, P[11], n2 + nArray2[0], n3 + nArray2[1], nArray2[2], nArray2[3], false, 10173496, 14662027, 10173496);
        this.a(graphics, stringArray[this.cR][1] + "^", 130, 50, n2 + nArray2[0] + 10, n3 + nArray2[1] + 10, 0xFFFFFF);
        if (Main.a.d().x()) {
            Main.j.N[0].y = 0;
            --this.cR;
            if (this.cR < 0) {
                this.cR = stringArray.length - 1;
            }
            bE = true;
        } else if (Main.a.d().f()) {
            Main.j.N[0].y = 0;
            ++this.cR;
            if (this.cR > stringArray.length - 1) {
                this.cR = 0;
            }
            bE = true;
        }
        if (Main.a.d().b != -99) {
            if (Main.a.d().i() || Main.a.d().n()) {
                bE = true;
                int n8 = 0;
                while (n8 < 6) {
                    if (cC[h[e][0]][n8] == Integer.parseInt(stringArray[this.cR][2])) {
                        if (e2.ar) {
                            bI = true;
                            bF = true;
                            this.b(-1);
                            bv = false;
                            di = dl + "\u8bf7\u5148\u89e3\u9664\u77f3\u5316\u6216\u9009\u62e9\u7834";
                            this.a(cY[h[e][0]], this.av, 0);
                            return;
                        }
                        if (!e2.al && Integer.parseInt(Main.k.F[Integer.parseInt(stringArray[this.cR][2])][8]) > 0) {
                            bI = true;
                            bF = true;
                            di = dl + "\u4e0d\u80fd\u9009\u62e9\u6280\u80fd";
                            return;
                        }
                        if (e2.ax >= Integer.parseInt(Main.k.F[Integer.parseInt(stringArray[this.cR][2])][8])) {
                            e2.at = Integer.parseInt(Main.k.F[Integer.parseInt(stringArray[this.cR][2])][3]);
                            this.cG = Integer.parseInt(Main.k.F[Integer.parseInt(stringArray[this.cR][2])][6]);
                            this.e(e2);
                            this.b(-1);
                            this.a(null, null, 2);
                            e2.aa = 1;
                            int n9 = 0;
                            while (n9 < Main.k.F.length) {
                                if (Main.k.F[n9][0].equals(String.valueOf(e2.n)) && Main.k.F[n9][3].equals(String.valueOf(e2.at))) {
                                    e2.ax -= Integer.parseInt(Main.k.F[n9][8]);
                                    if (Main.k.F[n9][5].indexOf("-1") != -1) {
                                        e2.ao = false;
                                    } else {
                                        int n10;
                                        int n11;
                                        n2 = Math.abs(this.cJ.nextInt()) % 100;
                                        if (n2 <= (n11 = Integer.parseInt(Main.k.F[n9][5].substring(0, n10 = Main.k.F[n9][5].indexOf("%"))))) {
                                            this.co = e2.at;
                                            if (Main.k.F[n9][4].indexOf("-1") == -1) {
                                                if (Main.k.F[n9][4].indexOf("\u9ebb\u75f9") != -1) {
                                                    this.b(this.av, 0);
                                                } else if (Main.k.F[n9][4].indexOf("\u7981\u9522") != -1) {
                                                    this.b(this.av, 1);
                                                } else if (Main.k.F[n9][4].indexOf("\u51b0\u51bb") != -1) {
                                                    this.b(this.av, 2);
                                                } else if (Main.k.F[n9][4].indexOf("\u71c3\u70e7") != -1) {
                                                    this.b(this.av, 3);
                                                } else if (Main.k.F[n9][4].indexOf("\u77f3\u5316") != -1) {
                                                    this.b(this.av, 4);
                                                }
                                            }
                                        } else {
                                            this.av.ao = false;
                                        }
                                    }
                                }
                                ++n9;
                            }
                        } else {
                            bI = true;
                            bF = true;
                            di = "\u6cd5\u672f\u4e0d\u8db3";
                            return;
                        }
                    }
                    ++n8;
                }
                return;
            }
            if (Main.a.d().s()) {
                bE = true;
                this.b(this.cu);
            }
        }
    }

    private void y(Graphics graphics) {
        graphics.setColor(0xFFFFFF);
        graphics.drawString("\u9000\u51fa", t - Main.k.w * 2 - 1, s - Main.k.v - 1, 0);
    }

    public final void e(Graphics graphics) {
        if (aU != null) {
            graphics.drawImage(aU, t / 2 - aU.getWidth() / 2, s / 2 - aU.getHeight() / 2, 0);
            ++this.V;
            if (this.V > 10) {
                this.V = 0;
                this.a(8);
            }
        }
    }

    public final void a(Graphics graphics, int n, int n2, int n3, int n4, int n5) {
        if (n3 < 0) {
            n3 = 0;
        }
        int n6 = aW.getWidth() / 11;
        int n7 = aW.getHeight();
        String string = String.valueOf(n3);
        if (n5 == 1) {
            n -= (string.length() + 1 + String.valueOf(n4).length()) * n6;
            n2 -= n7;
        } else {
            n2 -= n7 / 2;
        }
        rf.b.a(graphics, aW, n3, n, n2, 0);
        Main.j.b(graphics, aW, n + string.length() * n6, n2, 10 * n6, 0, n6, n7);
        rf.b.a(graphics, aW, n4, n + (string.length() + 1) * n6, n2, 0);
    }

    public final void f(Graphics graphics) {
        if (!(bS || bX || bC || bk || bs || bL)) {
            Main.a.d().c = -99;
        }
        String[] stringArray = new String[]{"\u65b0\u6e38\u620f", "\u7ee7\u7eed\u6e38\u620f", "\u66f4\u591a\u6e38\u620f", "\u58f0\u97f3\u8bbe\u7f6e", "\u5e2e\u52a9\u4fe1\u606f", "\u5173\u4e8e\u4fe1\u606f", "\u9000\u51fa\u6e38\u620f"};
        graphics.drawImage(aV, 0, 0, 0);
        graphics.drawImage(this.aO, t / 2 - rf.b.a.stringWidth(stringArray[1]) / 2 - this.aO.getWidth() - 11, s - Main.k.v * 3 + Main.k.v / 2 - this.aO.getHeight() / 2, 0);
        graphics.drawImage(this.aP, t / 2 + rf.b.a.stringWidth(stringArray[1]) / 2 + 10, s - Main.k.v * 3 + Main.k.v / 2 - this.aO.getHeight() / 2, 0);
        rf.b.a(graphics, stringArray[this.cR], t / 2 - rf.b.a.stringWidth(stringArray[this.cR]) / 2, s - Main.k.v * 3, 0xFFFFFF, -16777216, 0);
        if (this.cR == 2) {
            rf.b.a(graphics, stringArray[this.cR], t / 2 - rf.b.a.stringWidth(stringArray[this.cR]) / 2, s - Main.k.v * 3, 0xFFFFFF, 0xFF0000, 0);
        }
        if (!(!Main.a.d().k() || bS || bX || bC || bs || bk || bL)) {
            this.cR = this.cR > 0 ? --this.cR : stringArray.length - 1;
        } else if (!(!Main.a.d().u() || bS || bX || bC || bs || bk || bL)) {
            this.cR = this.cR < stringArray.length - 1 ? ++this.cR : 0;
        } else if (!((!Main.a.d().h() || bS || bX || bC || bs || bk || bL) && (!Main.a.d().m() || bS || bX || bC || bs || bk || bL))) {
            if (this.cR == 0) {
                this.cc = true;
                this.bz = true;
                this.a(9);
                if (!GameMidlet.i) {
                    o.put("jq", "0");
                } else {
                    o.put("jq", GameMidlet.l);
                }
            } else if (this.cR == 1) {
                this.cc = false;
                if (!bS) {
                    bS = true;
                }
            } else if (this.cR == 2) {
                bL = true;
            } else if (this.cR == 3) {
                bX = true;
            } else if (this.cR == 4) {
                bC = true;
            } else if (this.cR == 5) {
                bk = true;
            } else if (this.cR == 6) {
                bs = true;
            }
        } else if (Main.a.d().r() && this.cR == 1) {
            bS = false;
        }
        Main.a.d().a();
        if (bS) {
            this.k(graphics);
        } else if (bX) {
            this.m(graphics);
        } else if (bC) {
            this.a(graphics, this.dm);
        } else if (bk) {
            this.a(graphics, this.dj);
        } else if (bL) {
            bF = true;
            this.g(graphics);
        } else if (bs) {
            bF = true;
            this.c(graphics);
        }
        Main.a.d().c = -99;
    }

    public final void g(Graphics graphics) {
        this.c(graphics, "\u66f4\u591a\u7cbe\u5f69\u6e38\u620f^\u5c3d\u5728\u6e38\u620f\u9891\u9053^wap.xjoys.com^");
        this.x(graphics);
        this.z(graphics);
        if (Main.a.d().j()) {
            try {
                GameMidlet.b.platformRequest("http://gamepie.g188.net/gamecms/go/jpgd");
                GameMidlet.b.a();
            }
            catch (Exception exception) {}
        } else if (Main.a.d().t()) {
            bL = false;
        }
        Main.a.d().a();
        Main.a.d().s = false;
    }

    public final void h(Graphics graphics) {
        this.c(graphics, "\u66f4\u591a\u7cbe\u5f69\u6e38\u620f^\u5c3d\u5728\u6e38\u620f\u9891\u9053^wap.xjoys.com^");
        this.x(graphics);
        this.y(graphics);
        if (Main.a.d().j()) {
            try {
                GameMidlet.b.platformRequest("http://gamepie.g188.net/gamecms/go/jpgd");
                GameMidlet.b.a();
            }
            catch (Exception exception) {}
        } else if (Main.a.d().t()) {
            GameMidlet.b.a();
        }
        Main.a.d().a();
        Main.a.d().s = false;
    }

    public final void i(Graphics graphics) {
        graphics.setColor(0);
        graphics.fillRect(0, 0, t, s);
        graphics.setColor(0xFFFFFF);
        String string = "\u6682\u505c";
        graphics.drawString(string, t / 2 - Main.k.w, s / 2, 0);
        this.z(graphics);
        if (Main.a.d().e == Main.a.d().k) {
            if (bY) {
                this.f("/Image/2.mid");
                this.x();
            }
            bO = false;
        }
        Main.a.d();
        Main.a.a = -99;
        Main.a.d().b = -99;
        Main.a.d().c = -99;
        Main.a.d().d = -99;
        Main.a.d().e = -99;
    }

    public final void j(Graphics graphics) {
        boolean bl = false;
        int n = 200 / P[14].getHeight();
        if (200 % P[14].getHeight() != 0) {
            ++n;
        }
        int n2 = t / 2 - P[12].getWidth() / 2;
        int n3 = s / 2 - (n * P[14].getHeight() + P[12].getHeight() * 2) / 2;
        Main.e.a().b(graphics, n2, n3, 200);
        int n4 = aM.getWidth() / 2;
        int n5 = aM.getHeight();
        int[] nArray = new int[]{20, 19, 148, 22};
        int[] nArray2 = new int[]{20, 162, 148, 68};
        Main.e.a().a(graphics, P[11], n2 + nArray2[0], n3 + nArray2[1], nArray2[2], nArray2[3], false, 10173496, 14662027, 10173496);
        this.a(graphics, Main.k.z[cT * 10 + this.cS][2] + "^", 130, 60, n2 + nArray2[0] + 10, n3 + nArray2[1] + 10, 0xFFFFFF);
        graphics.setClip(0, 0, t, s);
        if (ca[cT * 10 + this.cS] == 1) {
            graphics.drawImage(aB, t / 2, n3 + nArray[1] + nArray[3] + 80, 33);
        } else {
            graphics.drawImage(bc, t / 2, n3 + nArray[1] + nArray[3] + 80, 33);
        }
        graphics.setColor(0);
        rf.b.a(graphics, Main.k.z[cT * 10 + this.cS][0], t / 2, n3 + nArray[1] + nArray[3] + 80 + 20, 0xFFFFFF, 0xFF0000, 33);
        de.b(n2 + t / 2 - aB.getWidth() / 2, n3 + nArray[1] + nArray[3] + 80 - aB.getHeight() + 35);
        de.b(graphics);
        de.a(true);
        int n6 = 5 * (P[23].getWidth() / 5);
        int n7 = t / 2 - n6 / 2;
        int n8 = 0;
        while (n8 < 5) {
            Main.e.a().b(graphics, P[23], n7 + n8 * P[23].getWidth() / 5, 3, n8, 0);
            if (n8 == this.cR) {
                Main.e.a().b(graphics, P[23], n7 + n8 * P[23].getWidth() / 5, 3, n8, 1);
            }
            ++n8;
        }
        Main.j.b(graphics, aM, n7 - n4, n3 - 20 + 5, 0, 0, n4, n5);
        Main.j.b(graphics, aM, n7 + 5 * P[23].getWidth() / 5, n3 - 20 + 5, n4, 0, n4, n5);
        if (Main.a.d().l()) {
            this.cR = this.cR > 0 ? --this.cR : 4;
            this.cS = 0;
            if (this.cR == 0) {
                cT = 3;
            } else if (this.cR == 1) {
                cT = 0;
            } else if (this.cR == 2) {
                cT = 1;
            } else if (this.cR == 3) {
                cT = 2;
            } else if (this.cR == 4) {
                cT = 4;
            }
            bE = true;
            aB = rf.b.a("/Image/guai" + Main.k.z[cT * 10 + this.cS][1] + ".png");
        } else if (Main.a.d().v()) {
            this.cR = this.cR < 4 ? ++this.cR : 0;
            this.cS = 0;
            if (this.cR == 0) {
                cT = 3;
            } else if (this.cR == 1) {
                cT = 0;
            } else if (this.cR == 2) {
                cT = 1;
            } else if (this.cR == 3) {
                cT = 2;
            } else if (this.cR == 4) {
                cT = 4;
            }
            bE = true;
            aB = rf.b.a("/Image/guai" + Main.k.z[cT * 10 + this.cS][1] + ".png");
        }
        if (Main.a.d().x()) {
            bE = true;
            --this.cS;
            if (this.cS < 0) {
                this.cS = 9;
            }
            aB = rf.b.a("/Image/guai" + Main.k.z[cT * 10 + this.cS][1] + ".png");
        } else if (Main.a.d().f()) {
            bE = true;
            ++this.cS;
            if (this.cS > 9) {
                this.cS = 0;
            }
            aB = rf.b.a("/Image/guai" + Main.k.z[cT * 10 + this.cS][1] + ".png");
        } else if (Main.a.d().s()) {
            this.cS = 0;
            this.b(this.cu);
        }
        Main.a.d().a();
    }

    public final void a(Graphics graphics, int n, rf.e[] eArray) {
        int n2;
        Object object;
        int n3;
        int n4;
        Object object2;
        boolean bl = false;
        int n5 = 230 / P[14].getHeight();
        if (230 % P[14].getHeight() != 0) {
            ++n5;
        }
        int n6 = t / 2 - P[12].getWidth() / 2;
        int n7 = s / 2 - (n5 * P[14].getHeight() + P[12].getHeight() * 2) / 2 + 10;
        Main.e.a().b(graphics, n6, n7, 230);
        int n8 = aM.getWidth() / 2;
        int n9 = aM.getHeight();
        if (dp == 18 && this.bR) {
            graphics.setColor(0);
            graphics.drawString("\u6ca1\u6709\u5bc4\u5b58\u7684\u4ed9\u5ba0", t / 2, s / 2, 17);
            return;
        }
        if (dp != 8 || n != 0 || this.cS != 0) {
            object2 = new int[]{15, 19, 80, 22};
            if (p != 2) {
                Main.e.a().a(graphics, null, n6 + object2[0], n7 + object2[1], (int)object2[2], (int)object2[3], false, 0xFFFFFF, 11499058, 15709554);
            }
            String string = eArray[this.be[this.cS]].aH;
            n4 = n6 + object2[0] + object2[2] / 2 - Main.e.a.stringWidth(string) / 2;
            n3 = n7 + object2[3];
            graphics.setColor(0);
            graphics.drawString(string, n4, n3, 0);
            object = new int[]{105, 18, 66, 108};
            if (p == 2) {
                object = new int[]{105, 18, 80, 108};
            }
            this.V = 0;
            n2 = 0;
            while (n2 < Main.k.F.length) {
                if (eArray[this.be[this.cS]].aD >= Integer.parseInt(Main.k.F[n2][7]) && eArray[this.be[this.cS]].n == Integer.parseInt(Main.k.F[n2][0])) {
                    ++this.V;
                }
                ++n2;
            }
            this.cK = new String[this.V];
            String[] stringArray = new String[this.V];
            this.V = 0;
            int n10 = 0;
            while (n10 < Main.k.F.length) {
                if (eArray[this.be[this.cS]].aD >= Integer.parseInt(Main.k.F[n10][7]) && eArray[this.be[this.cS]].n == Integer.parseInt(Main.k.F[n10][0])) {
                    this.cK[this.V] = Main.k.F[n10][1];
                    stringArray[this.V] = Main.k.F[n10][2];
                    ++this.V;
                }
                ++n10;
            }
            Main.e.a().a(graphics, P[18], n6 + object[0], n7 + object[1], (int)object[2], (int)object[3], false, 10173496, 14662027, 10173496);
            Main.e.a().a(graphics, this.cK, n6 + object[0], n7 + object[1], (int)object[2], (int)object[3], this.cR, true, 0);
            boolean bl2 = false;
            boolean bl3 = false;
            boolean bl4 = false;
            boolean bl5 = false;
            if (t == 320) {
                graphics.drawImage(aB, 117, 108, 33);
            } else {
                graphics.drawImage(aB, 81, 150, 33);
            }
            if (t == 320) {
                Main.j.b(graphics, aZ, n6 + object2[0] - 3, n3 + object2[1] - 1, (4 - eArray[this.be[this.cS]].o) * aZ.getWidth() / 4, 0, aZ.getWidth() / 4, aZ.getHeight());
                Main.e.a().b(graphics, P[23], 139, 86, eArray[this.be[this.cS]].n, eArray[this.be[this.cS]].n + 1);
            } else {
                Main.j.b(graphics, aZ, n6 + object2[0] - 3, n3 + object2[1] - 1, (4 - eArray[this.be[this.cS]].o) * aZ.getWidth() / 4, 0, aZ.getWidth() / 4, aZ.getHeight());
                Main.e.a().b(graphics, P[23], 100, 123, eArray[this.be[this.cS]].n, eArray[this.be[this.cS]].n + 1);
            }
            this.a(graphics, n6, n7, this.be[this.cS], eArray);
            if (this.bG) {
                Main.e.a().a(graphics, 0, 0, t, s);
                Main.e.a().a(graphics, P[11], n6 + object2[0], n7 + object2[1], 155, 120, false, 10173496, 14662027, 10173496);
                this.a(graphics, stringArray[this.cR] + "^", 150, 100, n6 + object2[0] + 5, n7 + object2[1] + 5, 0xFFFFFF);
            }
        }
        if (dp == 8 && n == 0 && this.cS == 0) {
            object2 = "\u7a7a\u51fa\u8be5\u4f4d\u7f6e";
            graphics.setColor(0xFF0000);
            graphics.drawString((String)object2, t / 2 - Main.e.a.stringWidth((String)object2) / 2, s / 2, 0);
        }
        int n11 = 6 * (P[20].getWidth() / 6);
        int n12 = t / 2 - n11 / 2;
        if (dp == 18 || dp == 17 || t == 320) {
            n4 = 0;
            n3 = 0;
            if (t == 320) {
                n4 = s - 28;
                n3 = 38;
            }
            if (this.cS + 1 >= 10) {
                object = String.valueOf(this.cS + 1);
                int n13 = Integer.parseInt(((String)object).substring(0, 1));
                n2 = Integer.parseInt(((String)object).substring(1, 2));
                Main.e.a().b(graphics, P[19], t / 2 - P[20].getWidth() / 6, 3 + n4, n13, 1);
                Main.e.a().b(graphics, P[19], t / 2, 3 + n4, n2, 1);
                Main.j.b(graphics, aM, t / 2 - P[20].getWidth() / 6 - n8, n7 - 20 + 5 + n4 + n3, 0, 0, n8, n9);
                Main.j.b(graphics, aM, t / 2 - P[20].getWidth() / 6 + 2 * P[20].getWidth() / 6, n7 - 20 + 5 + n4 + n3, n8, 0, n8, n9);
            } else {
                Main.e.a().b(graphics, P[19], t / 2 - P[20].getWidth() / 12, 3 + n4, this.cS + 1, 1);
                Main.j.b(graphics, aM, t / 2 - P[20].getWidth() / 12 - n8, n7 - 20 + 5 + n4 + n3, 0, 0, n8, n9);
                Main.j.b(graphics, aM, t / 2 - P[20].getWidth() / 12 + P[20].getWidth() / 6, n7 - 20 + 5 + n4 + n3, n8, 0, n8, n9);
            }
            return;
        }
        Main.j.b(graphics, aM, n12 - n8, n7 - 20 + 5, 0, 0, n8, n9);
        Main.j.b(graphics, aM, n12 + this.be.length * P[20].getWidth() / 6, n7 - 20 + 5, n8, 0, n8, n9);
        n4 = 0;
        while (n4 < this.be.length) {
            Main.e.a().b(graphics, P[19], n12 + n4 * P[20].getWidth() / 6, 3, n4 + 1, 0);
            if (n4 == this.cS) {
                Main.e.a().b(graphics, P[19], n12 + n4 * P[20].getWidth() / 6, 3, n4 + 1, 1);
            }
            ++n4;
        }
    }

    public final void d(Graphics graphics, int n) {
        this.a(graphics, n, cZ);
        if (this.cf) {
            this.b(graphics, "\u662f\u5426\u628a\u8be5\u4ed9\u5ba0\u653e\u5230\u80cc\u5305\u4e2d");
        }
        if (Main.a.d().l() && !this.bR) {
            this.cR = 0;
            if (this.cS > 0) {
                --this.cS;
            }
            aB = rf.b.a("/Image/" + Main.j.cZ[this.be[this.cS]].t + ".png");
        } else if (Main.a.d().v() && !this.bR) {
            this.cR = 0;
            if (this.cS < this.be.length - 1) {
                ++this.cS;
            }
            aB = rf.b.a("/Image/" + Main.j.cZ[this.be[this.cS]].t + ".png");
        }
        if ((Main.a.d().i() || Main.a.d().n()) && !this.bR) {
            if (!this.cf) {
                this.cf = true;
                return;
            }
            this.cf = false;
            if (!Main.j.cY[Main.j.cY.length - 1].t.equals("-1")) {
                bI = true;
                bF = true;
                bE = true;
                di = "\u80cc\u5305\u5df2\u6ee1\uff01\u8bf7\u5148\u653e\u751f\u6216\u5bc4\u5b58";
                return;
            }
            int n2 = 0;
            while (n2 < cY.length) {
                if (Main.j.cY[n2].t.equals("-1")) {
                    Main.j.cY[n2].ag = Main.j.cZ[this.be[this.cS]].ag;
                    Main.j.cY[n2].ax = Main.j.cZ[this.be[this.cS]].ax;
                    Main.j.cY[n2].t = Main.j.cZ[this.be[this.cS]].t;
                    Main.j.cY[n2].aD = Main.j.cZ[this.be[this.cS]].aD;
                    Main.j.cY[n2].n = Main.j.cZ[this.be[this.cS]].n;
                    Main.j.cY[n2].aH = Main.j.cZ[this.be[this.cS]].aH;
                    Main.j.cY[n2].ae = Integer.parseInt(Main.j.cZ[this.be[this.cS]].t.substring(4, Main.j.cZ[this.be[this.cS]].t.length()));
                    this.g(cY[n2]);
                    Main.j.cZ[this.be[this.cS]].ae = -1;
                    Main.j.cZ[this.be[this.cS]].ab = -1;
                    Main.j.cZ[this.be[this.cS]].t = "-1";
                    break;
                }
                ++n2;
            }
            int n3 = 0;
            while (n3 < cZ.length) {
                if (this.be[this.cS] != cZ.length - 1 && n3 > this.be[this.cS]) {
                    rf.e e2 = cZ[n3 - 1];
                    Main.j.cZ[n3 - 1] = cZ[n3];
                    Main.j.cZ[n3] = e2;
                }
                ++n3;
            }
            int n4 = this.be.length - 1;
            if (n4 == 0) {
                this.bR = true;
            } else {
                this.be = new int[n4];
                n4 = 0;
                int n5 = 0;
                while (n5 < cZ.length) {
                    if (!Main.j.cZ[n5].t.equals("-1")) {
                        this.be[n4] = n5;
                        ++n4;
                    }
                    ++n5;
                }
                this.cS = this.cS != 0 ? --this.cS : this.be.length - 1;
                aB = rf.b.a("/Image/" + Main.j.cZ[this.be[this.cS]].t + ".png");
            }
            return;
        }
        if (Main.a.d().s()) {
            if (this.cf) {
                this.cf = false;
                return;
            }
            Main.j.i(0);
            Main.j.a();
            this.b(-1);
        }
    }

    public final void k(Graphics graphics) {
        boolean bl = false;
        int n = (Main.k.v + 10) * 3;
        if (P[18] == null) {
            Main.j.P[18] = rf.b.a("/Image/" + Main.k.C[18] + ".png");
        }
        Main.e.a().a(graphics, P[18], t / 2 - 60, s / 2 - n / 2, 120, n, false, 10173496, 14662027, 10173496);
        Main.e.a().a(graphics, cM, t / 2 - 60, s / 2 - n / 2, 120, n, cT, true, 0);
        if (Main.a.d().y()) {
            if (--cT < 0) {
                cT = 0;
            }
            return;
        }
        if (Main.a.d().g()) {
            if (++cT > 2) {
                cT = 2;
            }
            return;
        }
        if (Main.a.d().j()) {
            if (!cM[cT].equals("\u7a7a")) {
                this.ce = true;
                bT = true;
                if (df == 8) {
                    this.a(9);
                } else {
                    this.a(0);
                }
                bS = false;
                Main.a.d().s = false;
            }
            return;
        }
        if (Main.a.d().t()) {
            bS = false;
            Main.a.d().s = false;
        }
    }

    public final void l(Graphics graphics) {
        if (p == 2) {
            Main.j.b(graphics, P[10], t - P[10].getWidth() / 2 - 10, s - P[10].getHeight() - 10, P[10].getWidth() / 2, 0, P[10].getWidth() / 2, P[10].getHeight());
        }
    }

    private void z(Graphics graphics) {
        graphics.setColor(0xFFFFFF);
        graphics.drawString("\u8fd4\u56de", t - Main.k.w * 2 - 1, s - Main.k.v - 1, 0);
    }

    public final void b(Graphics graphics, String string) {
        if (P[10] == null) {
            Main.j.P[10] = rf.b.a("/Image/" + Main.k.C[10] + ".png");
        }
        int n = t - 10;
        if (Main.e.a.stringWidth(string) < t - 20) {
            n = t - 10;
        }
        int n2 = (Main.k.v + 10) * 2 + 10;
        Main.e.a().a(graphics, P[18], t / 2 - n / 2, s / 2 - n2 / 2, n, n2, false, 10173496, 14662027, 10173496);
        int n3 = t / 2 - n / 2;
        int n4 = s / 2 - n2 / 2 + n2 - P[10].getHeight() - 2;
        Main.j.b(graphics, P[10], n3 + 3, n4, 0, 0, P[10].getWidth() / 2, P[10].getHeight());
        Main.j.b(graphics, P[10], n3 + n - 3 - P[10].getWidth() / 2, n4, P[10].getWidth() / 2, 0, P[10].getWidth() / 2, P[10].getHeight());
        bF = true;
        this.b(graphics, string + "^", n - 10, n2 - 20, t / 2 - n / 2 + 5, s / 2 - n2 / 2 + 5, 0xFFFFFF);
    }

    public final void b(rf.e e2, Graphics graphics) {
        boolean bl = false;
        int n = 200 / P[14].getHeight();
        if (200 % P[14].getHeight() != 0) {
            ++n;
        }
        int n2 = t / 2 - P[12].getWidth() / 2;
        int n3 = s / 2 - (n * P[14].getHeight() + P[12].getHeight() * 2) / 2;
        Main.e.a().b(graphics, n2, n3, 200);
        int[] nArray = new int[]{20, 19, 148, 22};
        int[] nArray2 = new int[]{20, 162, 148, 68};
        Main.e.a().a(graphics, null, n2 + nArray[0], n3 + nArray[1], nArray[2], nArray[3], false, 0xFFFFFF, 11499058, 15709554);
        int n4 = 0;
        n4 = cy >= 100 && cy < 999 ? 3 : 4;
        int n5 = P[21].getWidth() + 5 + n4 * P[7].getWidth() / 10;
        int n6 = n2 + nArray[0] + nArray[2] / 2 - n5 / 2;
        int n7 = n3 + nArray[1] + nArray[3] / 2 - P[21].getHeight() / 2;
        int n8 = n3 + nArray[1] + nArray[3] / 2 - P[7].getHeight() / 2;
        graphics.drawImage(P[21], n6, n7, 0);
        rf.b.b(graphics, P[7], cy, n6 + P[21].getWidth() + 5, n8, 5);
        String[][] stringArray = new String[Main.k.E.length - 1][Main.k.E[0].length];
        int[] nArray3 = new int[Main.k.E.length - 1];
        if (stringArray[0][0] == null) {
            int n9 = 0;
            while (n9 < stringArray.length) {
                int n10 = 0;
                while (n10 < stringArray[n9].length) {
                    stringArray[n9][n10] = n9 >= 21 ? Main.k.E[n9 + 1][n10] : Main.k.E[n9][n10];
                    ++n10;
                }
                nArray3[n9] = n9 >= 21 ? n9 + 1 : n9;
                ++n9;
            }
        }
        Main.e.a().a(graphics, stringArray, 0, n2 + nArray[0] + 15, n3 + nArray[1] + nArray[3], nArray[2], 200 - nArray2[3], this.cR, false, 1);
        Main.e.a().a(graphics, nArray3, n2 + nArray[0] + 2, n3 + nArray[1] + nArray[3], 200 - nArray2[3], this.cR);
        Main.e.a().a(graphics, P[11], n2 + nArray2[0], n3 + nArray2[1], nArray2[2], nArray2[3], false, 10173496, 14662027, 10173496);
        if (this.cR >= 21) {
            this.a(graphics, stringArray[this.cR][1] + "^", 90, 60, n2 + nArray2[0] + 10 + 50, n3 + nArray2[1] + 10, 0xFFFFFF);
            graphics.setClip(0, 0, t, s);
            graphics.drawImage(ai, n2 + nArray2[0] + 10, n3 + nArray2[1] + 10, 0);
            de.b(n2 + nArray2[0] + 10 + 25, n3 + nArray2[1] + 10 + 35);
            de.b(graphics);
            de.a(true);
            graphics.setClip(0, 0, t, s);
        } else {
            this.a(graphics, stringArray[this.cR][1] + "^", 130, 60, n2 + nArray2[0] + 10, n3 + nArray2[1] + 10, 0xFFFFFF);
            graphics.setClip(0, 0, t, s);
        }
        if (Main.a.d().x() && !bW) {
            Main.j.N[0].y = 0;
            Main.e.i = 1;
            Main.e.e[this.cR] = 1;
            --this.cR;
            if (this.cR < 0) {
                this.cR = stringArray.length - 1;
            }
            ai = rf.b.a("/Image/fb" + (this.cR - 20 + 22) + "_big.png");
            bE = true;
            bI = false;
            bW = false;
            cw = 0;
            return;
        }
        if (Main.a.d().f() && !bW) {
            Main.j.N[0].y = 0;
            Main.e.i = 1;
            Main.e.e[this.cR] = 1;
            ++this.cR;
            if (this.cR > stringArray.length - 1) {
                this.cR = 0;
            }
            ai = rf.b.a("/Image/fb" + (this.cR - 20 + 22) + "_big.png");
            bE = true;
            bI = false;
            bW = false;
            cw = 0;
            return;
        }
        if (Main.a.d().i() || Main.a.d().n()) {
            if (!bW) {
                bW = true;
                bF = true;
                this.ce = true;
                int n11 = Integer.parseInt(stringArray[this.cR][2]) * Main.e.i;
                do = stringArray[this.cR][0] + "x" + Main.e.i + "=" + n11 + "\u91d1\u3002\u662f\u5426\u8d2d\u4e70\uff1f";
            } else {
                this.ce = false;
                bW = false;
                if (this.cR >= 21) {
                    this.c(this.cR + 1, Main.e.i);
                } else {
                    this.d(this.cR, Main.e.i);
                }
                Main.e.e[this.cR] = 1;
                Main.e.i = 1;
            }
            return;
        }
        if (Main.a.d().s()) {
            if (bW) {
                this.ce = false;
                bI = false;
                bW = false;
                cw = 0;
                Main.e.i = 1;
                Main.e.e[this.cR] = (byte)Main.e.i;
                return;
            }
            Main.e.i = 1;
            Main.j.i(0);
            Main.j.a();
            if (df == 2) {
                if (this.cu == 71) {
                    this.b(this.cu);
                } else {
                    this.b(-1);
                }
                return;
            }
            if (this.cu == 72) {
                this.cu = -1;
            }
            this.b(this.cu);
        }
    }

    static final void a(Graphics graphics, String string, int n, int n2) {
        int n3 = 0;
        int n4 = n2;
        boolean bl = false;
        if (bF) {
            rf.b.b(string, t - 20);
            bF = false;
        }
        n3 = (s - n4 * 2) / (10 + rf.b.b);
        int n5 = n;
        int n6 = 0;
        int n7 = 0;
        int n8 = 0;
        if (rf.b.f <= n3) {
            n6 = 0;
            n8 = rf.b.f;
        } else {
            n6 = rf.b.f % n3 == 0 ? rf.b.f / n3 - 1 : rf.b.f / n3;
            n8 = cW < n6 ? n3 : (rf.b.f % n3 == 0 ? n3 : rf.b.f % n3);
        }
        graphics.setFont(rf.b.a);
        graphics.setColor(0xFFFFFF);
        int n9 = cW * n3;
        while (n9 < cW * n3 + n8) {
            n7 = n5;
            graphics.drawString(rf.b.d[n9], n7, n4 + (n9 - cW * n3) * (rf.b.b + 10), 0);
            ++n9;
        }
        if (Main.a.d().y()) {
            cW = cW > 0 ? --cW : n6;
            return;
        }
        if (Main.a.d().g()) {
            if (cW < n6) {
                ++cW;
                return;
            }
            cW = 0;
        }
    }

    final void a(Graphics graphics, String string, int n, int n2, int n3, int n4, int n5) {
        int n6 = 5 + rf.b.b;
        graphics.setFont(rf.b.a);
        graphics.setClip(n3, n4, n, n2);
        if (bE) {
            rf.b.a(string, n);
            bE = false;
            cW = 0;
            this.X = 0;
        }
        graphics.setColor(n5);
        int n7 = 0;
        while (n7 < rf.b.e) {
            graphics.drawString(rf.b.c[n7], n3, n4 + n7 * (rf.b.b + 5) - n6 * cW - this.X * 1, 0);
            ++n7;
        }
        if (rf.b.e * (rf.b.b + 5) > n2) {
            if (this.X * 1 < rf.b.e * (rf.b.b + 5)) {
                ++this.X;
                return;
            }
            this.X = 0;
        }
    }

    final void b(Graphics graphics, String string, int n, int n2, int n3, int n4, int n5) {
        boolean bl = false;
        if (bF) {
            rf.b.b(string, n);
            bF = false;
        }
        graphics.setFont(rf.b.a);
        graphics.setColor(n5);
        int n6 = 0;
        while (n6 < rf.b.f) {
            n3 = t / 2 - Main.e.a.stringWidth(rf.b.d[n6]) / 2;
            graphics.drawString(rf.b.d[n6], n3, n4 + n6 * (rf.b.b + 5), 0);
            ++n6;
        }
        graphics.setClip(0, 0, t, s);
    }

    public final void m(Graphics graphics) {
        this.b(graphics, "\u662f\u5426\u5f00\u542f\u58f0\u97f3\uff1f");
        if (Main.a.d().j()) {
            if (!bY) {
                this.f("/Image/2.mid");
                this.x();
                bY = true;
            }
            bX = false;
        } else if (Main.a.d().t()) {
            Main.j.z();
            bX = false;
            bY = false;
        }
        Main.a.d().a();
        Main.a.d().s = false;
    }

    public final void n(Graphics graphics) {
        int[] nArray = new int[]{6, 7, 8, 9, 10, 11, 12};
        int n = P[15].getHeight() + 35;
        int n2 = t / 2 - P[12].getWidth() / 2;
        int n3 = s / 2 - n / 2 - P[12].getHeight() * 2;
        Main.e.a().b(graphics, n2, n3, n);
        if (System.currentTimeMillis() - this.i >= this.j) {
            this.i = System.currentTimeMillis();
            if (ab < 3) {
                ++ab;
            }
        }
        int n4 = 0;
        while (n4 < ab) {
            ac = n4++;
            Main.e.a().a(graphics, P[15], 7, n2, n3 + P[12].getHeight(), P[12].getWidth(), n, this.cR);
        }
        if (Main.a.d().x()) {
            Main.j.N[0].y = 0;
            --this.cR;
            if (this.cR < 0) {
                this.cR = 6;
            }
        } else if (Main.a.d().f()) {
            Main.j.N[0].y = 0;
            ++this.cR;
            if (this.cR > 6) {
                this.cR = 0;
            }
        } else if (Main.a.d().i() || Main.a.d().n()) {
            this.b(nArray[this.cR]);
            ab = 0;
        } else if (Main.a.d().s()) {
            this.b(-1);
            this.i = 0L;
            ab = 0;
            this.cR = 0;
            Main.j.N[0].y = 0;
            ab = 0;
            this.cR = 0;
        }
        if (!Main.a.d().n()) {
            Main.a.d().a();
        }
    }

    public final void o(Graphics graphics) {
        int[] nArray = new int[]{0, 0, 0, 0, 20};
        int n = P[24].getHeight() + 25;
        int n2 = t / 2 - P[12].getWidth() / 2;
        int n3 = s / 2 - n / 2 - P[12].getHeight() * 2;
        Main.e.a().b(graphics, n2, n3, n);
        if (System.currentTimeMillis() - this.i >= this.j) {
            this.i = System.currentTimeMillis();
            if (ab < 3) {
                ++ab;
            }
        }
        int n4 = 0;
        while (n4 < ab) {
            ac = n4++;
            Main.e.a().a(graphics, P[24], 5, n2, n3 + P[12].getHeight(), P[12].getWidth(), n, this.cS);
        }
        if (Main.a.d().x()) {
            Main.j.N[0].y = 0;
            --this.cS;
            if (this.cS < 0) {
                this.cS = 4;
            }
        } else if (Main.a.d().f()) {
            Main.j.N[0].y = 0;
            ++this.cS;
            if (this.cS > 4) {
                this.cS = 0;
            }
        } else if (!(!Main.a.d().i() && !Main.a.d().n() || cb || bS || bX || bC || bs)) {
            if (this.cS == 0) {
                this.ce = false;
                cb = true;
                cT = 0;
                Main.a.d().c = -99;
                Main.a.d().s = true;
            } else if (this.cS == 1) {
                cT = 0;
                bS = true;
                Main.a.d().c = -99;
                Main.a.d().s = true;
            } else if (this.cS == 2) {
                bX = true;
                Main.a.d().c = -99;
                Main.a.d().s = true;
            } else if (this.cS == 3) {
                bC = true;
                Main.a.d().c = -99;
                Main.a.d().s = true;
            } else if (this.cS == 4) {
                bs = true;
                Main.a.d().c = -99;
                Main.a.d().s = true;
            } else {
                this.b(nArray[this.cS]);
                ab = 0;
            }
        } else if (Main.a.d().s()) {
            ab = 0;
            this.b(5);
            this.i = 0L;
            ab = 0;
            this.cR = 0;
            Main.j.N[0].y = 0;
        }
        Main.a.d().a();
    }

    public final void p(Graphics graphics) {
        boolean bl = false;
        int n = 200 / P[14].getHeight();
        if (200 % P[14].getHeight() != 0) {
            ++n;
        }
        int n2 = t / 2 - P[12].getWidth() / 2;
        int n3 = s / 2 - (n * P[14].getHeight() + P[12].getHeight() * 2) / 2;
        Main.e.a().b(graphics, n2, n3, 200);
        int[] nArray = new int[]{20, 19, 148, 22};
        int[] nArray2 = new int[]{20, 162, 148, 68};
        int n4 = 2 * (P[20].getWidth() / 6);
        int n5 = t / 2 - n4 / 2;
        int n6 = 0;
        while (n6 < 2) {
            Main.e.a().b(graphics, P[19], n5 + n6 * P[20].getWidth() / 6, 3, 10 + n6, 0);
            if (n6 == dr) {
                Main.e.a().b(graphics, P[19], n5 + n6 * P[20].getWidth() / 6, 3, 10 + n6, 1);
            }
            ++n6;
        }
        if (dr == 0) {
            Main.e.a().a(graphics, this.dv, 0, n2 + nArray[0], n3 + nArray[1] + nArray[3], nArray[2], 200 - nArray2[3], this.cR, true, 1);
        } else {
            Main.e.a().a(graphics, this.dw, 0, n2 + nArray[0], n3 + nArray[1] + nArray[3], nArray[2], 200 - nArray2[3], this.cR, true, 1);
        }
        Main.e.a().a(graphics, P[11], n2 + nArray2[0], n3 + nArray2[1], nArray2[2], nArray2[3], false, 10173496, 14662027, 10173496);
        graphics.setColor(0xFFFFFF);
        if (dr == 0) {
            this.a(graphics, this.dv[this.cR][1] + "^", 130, 60, n2 + nArray2[0] + 10, n3 + nArray2[1] + 10, 0xFFFFFF);
        } else {
            this.a(graphics, this.dw[this.cR][1] + "^", 130, 60, n2 + nArray2[0] + 10, n3 + nArray2[1] + 10, 0xFFFFFF);
        }
        if (Main.a.d().x()) {
            this.cR = dr == 0 ? (this.cR <= 0 ? this.dv.length - 1 : --this.cR) : (this.cR <= 0 ? this.dw.length - 1 : --this.cR);
            bE = true;
        } else if (Main.a.d().f()) {
            this.cR = dr == 0 ? (this.cR >= this.dv.length - 1 ? 0 : ++this.cR) : (this.cR >= this.dw.length - 1 ? 0 : ++this.cR);
            bE = true;
        } else if (Main.a.d().l()) {
            dr = dr == 0 ? 1 : 0;
            this.cR = 0;
            bE = true;
        } else if (Main.a.d().v()) {
            dr = dr == 0 ? 1 : 0;
            this.cR = 0;
            bE = true;
        } else if (Main.a.d().s()) {
            this.b(5);
        }
        Main.a.d().a();
    }

    public final void q(Graphics graphics) {
        String[] stringArray = new String[]{"\u5b58\u6863\u4e00", "\u5b58\u6863\u4e8c", "\u5b58\u6863\u4e09"};
        boolean bl = false;
        int n = (Main.k.v + 10) * 3;
        Main.e.a().a(graphics, P[18], t / 2 - 60, s / 2 - n / 2, 120, n, false, 10173496, 14662027, 10173496);
        Main.e.a().a(graphics, cM, t / 2 - 60, s / 2 - n / 2, 120, n, cT, true, 0);
        if (this.ce) {
            this.b(graphics, "\u8bb0\u5f55\u5b58\u5728\u662f\u5426\u8986\u76d6?");
        }
        if (Main.a.d().y() && !this.ce) {
            if (--cT < 0) {
                cT = 0;
            }
            return;
        }
        if (Main.a.d().g() && !this.ce) {
            if (++cT > 2) {
                cT = 2;
            }
            return;
        }
        if (Main.a.d().j()) {
            if (!this.ce) {
                if (!cM[cT].equals("\u7a7a")) {
                    this.ce = true;
                } else {
                    Main.j.cM[Main.j.cT] = stringArray[cT];
                    rf.b.b();
                    rf.b.c(cz[cT]);
                    Main.a.d().s = false;
                    bI = true;
                    di = "\u4fdd\u5b58\u6210\u529f";
                    bE = true;
                    bF = true;
                    cb = false;
                }
            } else {
                this.ce = false;
                Main.j.cM[Main.j.cT] = stringArray[cT];
                rf.b.b();
                rf.b.c(cz[cT]);
                bI = true;
                di = "\u4fdd\u5b58\u6210\u529f";
                bE = true;
                bF = true;
                cb = false;
            }
            return;
        }
        if (Main.a.d().t()) {
            if (this.ce) {
                this.ce = false;
                return;
            }
            cb = false;
            Main.a.d().s = false;
        }
    }

    public final void e(Graphics graphics, int n) {
        this.a(graphics, n, cY);
        if (Main.a.d().x() && !this.bG) {
            --this.cR;
            if (this.cR < 0) {
                this.cR = this.cK.length - 1;
            }
        } else if (Main.a.d().f() && !this.bG) {
            ++this.cR;
            if (this.cR > this.cK.length - 1) {
                this.cR = 0;
            }
        } else if (Main.a.d().l() && !this.bG) {
            this.cR = 0;
            this.cS = this.cS > 0 ? --this.cS : this.be.length - 1;
            aB = rf.b.a("/Image/" + Main.j.cY[this.be[this.cS]].t + ".png");
        } else if (Main.a.d().v() && !this.bG) {
            this.cR = 0;
            this.cS = this.cS < this.be.length - 1 ? ++this.cS : 0;
            aB = rf.b.a("/Image/" + Main.j.cY[this.be[this.cS]].t + ".png");
        } else if ((Main.a.d().i() || Main.a.d().n()) && !this.bG) {
            if (df == 4) {
                if (dp == 70) {
                    if (this.be[this.cS] != -1) {
                        if (Main.j.cY[this.be[this.cS]].an) {
                            bI = true;
                            bF = true;
                            di = Main.j.cY[this.be[this.cS]].aH + "\u5df2\u6b7b\u4ea1\uff01";
                        } else {
                            aB = rf.b.a("/Image/" + Main.j.cY[this.be[this.cS]].t + ".png");
                            int n2 = 0;
                            while (n2 < h.length) {
                                if (h[n2][0] == this.be[this.cS]) {
                                    e = n2;
                                    break;
                                }
                                ++n2;
                            }
                            this.g(cY[this.be[this.cS]]);
                            cY[this.be[this.cS]].b(this.m[0], this.m[1]);
                            this.a(cY[this.be[this.cS]], this.av, 0);
                            this.b(-1);
                            Main.j.dd[0].y = 0;
                            Main.j.dd[1].y = 0;
                            this.by = false;
                        }
                    } else {
                        bI = true;
                        bF = true;
                        di = "\u8bf7\u9009\u62e9\u6218\u6597\u4ed9\u5ba0\uff01";
                    }
                } else {
                    this.a(null, null, 0);
                }
            } else {
                bE = true;
                this.bG = true;
            }
        } else if (Main.a.d().s()) {
            if (this.by) {
                Main.a.d().a();
                return;
            }
            if (!this.bG) {
                aB = rf.b.a("/Image/" + Main.j.cY[Main.j.h[Main.j.e][0]].t + ".png");
                this.b(this.cu);
            } else {
                this.bG = false;
            }
        }
        Main.a.d().a();
    }

    public final void c(Graphics graphics, String string) {
        graphics.setColor(0);
        graphics.fillRect(0, 0, t, s);
        graphics.drawImage(aS, t / 2 - aS.getWidth() / 2, s / 2 - aS.getHeight() / 2, 0);
        graphics.setColor(0xFFFFFF);
        this.b(graphics, string, t - 20, s - 30, 10, s / 2 - Main.k.v * 2, 0xFFFFFF);
    }

    public final void c(rf.e e2) {
        if (e2.ar) {
            this.a(cY[h[e][0]], this.av, 0);
            return;
        }
        if (this.ci) {
            int n;
            int n2 = n = e2.ap == 0 ? e2.aE * 50 / 100 : e2.aE * 20 / 100;
            if (e2.ag < n && e2.ap < 2) {
                e2.ap = (byte)(e2.ap + 1);
                e2.ag = e2.ap <= 1 ? e2.aE : e2.aE * 85 / 100;
                e2.aa = 0;
                db = Main.j.a(Main.k.B[2], 0);
            } else {
                e2.aa = 1;
                this.d(e2);
            }
            return;
        }
        int n = (((100 - 100 * e2.ag / e2.aE) * (100 - 100 * e2.ag / e2.aE) + 20000) * (e2.o * e2.o + 250) - 6000000) / 100000;
        int n3 = Math.abs(this.cJ.nextInt()) % 100;
        if (!e2.aj) {
            n3 = 101;
        }
        if (n3 < n && at == 0 || n3 < n && at == 1 && !this.ci) {
            e2.aa = (byte)2;
            if (at == 0) {
                o.put("fight_Value", "1");
            } else {
                o.put("fight_Value", "3");
            }
            return;
        }
        e2.aa = 1;
        this.d(e2);
    }

    public final void d(rf.e e2) {
        int n = Math.abs(this.cJ.nextInt()) % 9;
        if (e2.aD >= 0 && e2.aD <= 10) {
            if (n >= 0 && n <= 9) {
                e2.at = 0;
            }
        } else if (e2.aD >= 11 && e2.aD <= 30) {
            if (n >= 0 && n <= 1) {
                e2.at = 0;
            } else if (n >= 2 && n <= 9) {
                e2.at = 1;
            }
        } else if (e2.aD >= 31 && e2.aD <= 50) {
            if (n == 0) {
                e2.at = 0;
            } else if (n == 1) {
                e2.at = 1;
            } else if (n >= 2 && n <= 9) {
                e2.at = 2;
            }
        } else if (e2.aD >= 51 && e2.aD <= 70) {
            if (n == 0) {
                e2.at = 1;
            } else if (n == 1) {
                e2.at = 2;
            } else if (n >= 2 && n <= 9) {
                e2.at = 3;
            }
        } else if (e2.aD >= 71 && e2.aD <= 99) {
            if (n == 0) {
                e2.at = 2;
            } else if (n == 1) {
                e2.at = 3;
            } else if (n >= 2 && n <= 9) {
                e2.at = 4;
            }
        }
        if (!e2.al) {
            e2.at = 0;
        }
        if (cN.equals(cA)) {
            e2.at = 4;
        }
        this.e(e2);
        int n2 = 0;
        while (n2 < Main.k.F.length) {
            if (Main.k.F[n2][0].equals(String.valueOf(e2.n)) && Main.k.F[n2][3].equals(String.valueOf(e2.at))) {
                int n3;
                int n4;
                this.cG = Integer.parseInt(Main.k.F[n2][6]);
                e2.ax -= Integer.parseInt(Main.k.F[n2][8]);
                if (Main.k.F[n2][5].indexOf("-1") != -1) {
                    return;
                }
                n = Math.abs(this.cJ.nextInt()) % 100;
                if (n <= (n4 = Integer.parseInt(Main.k.F[n2][5].substring(0, n3 = Main.k.F[n2][5].indexOf("%"))))) {
                    this.cp = e2.at;
                    if (Main.k.F[n2][4].indexOf("-1") == -1) {
                        if (Main.k.F[n2][4].indexOf("\u9ebb\u75f9") != -1) {
                            this.a(cY[h[e][0]], 0);
                        } else if (Main.k.F[n2][4].indexOf("\u7981\u9522") != -1) {
                            this.a(cY[h[e][0]], 1);
                        }
                        if (Main.k.F[n2][4].indexOf("\u51b0\u51bb") != -1) {
                            this.a(cY[h[e][0]], 2);
                        }
                        if (Main.k.F[n2][4].indexOf("\u71c3\u70e7") != -1) {
                            this.a(cY[h[e][0]], 3);
                        }
                        if (Main.k.F[n2][4].indexOf("\u77f3\u5316") != -1) {
                            this.a(cY[h[e][0]], 4);
                        }
                    }
                }
                return;
            }
            ++n2;
        }
    }

    final void c(Graphics graphics, rf.e e2, rf.e e3) {
        byte[][] byArrayArray;
        rf.e e4 = null;
        if (e3.aa == 1) {
            e4 = e2;
        } else if (e3.aa == -1) {
            e4 = e3;
        }
        if (e4.ai) {
            byte[][] byArrayArray2 = new byte[][]{{-4, -5}, {2, 3}, {-1, -2}, {3, 4}};
            if (this.ag <= byArrayArray2.length - 1) {
                if (e3.aa == 1) {
                    this.ap[0] = this.ap[0] + byArrayArray2[this.ag][0];
                    this.ap[1] = this.ap[1] + byArrayArray2[this.ag][1];
                } else {
                    this.m[0] = this.m[0] + byArrayArray2[this.ag][0];
                    this.m[1] = this.m[1] + byArrayArray2[this.ag][1];
                }
                ++this.ag;
            }
            graphics.drawImage(ba, this.dH - ba.getWidth(), this.dI - 4 * this.S, 0);
            if (this.S < 4) {
                ++this.S;
            } else {
                this.a(e2, e3, 0);
            }
            return;
        }
        Main.j.b(graphics, aK, this.dH - aX.getWidth() / 10, this.dI - 4 * this.S, aK.getWidth() / 2, 0, aK.getWidth() / 2, aK.getHeight());
        rf.b.a(graphics, aX, this.af, this.dH, this.dI - 4 * this.S, 0);
        if (e4.am) {
            graphics.drawImage(aG, this.dH - aG.getWidth(), this.dI, 0);
        }
        if (this.S < 4) {
            ++this.S;
        }
        if (this.ag <= (byArrayArray = new byte[][]{{-4, -5}, {2, 3}, {-1, -2}, {3, 4}}).length - 1) {
            if (e3.aa == 1) {
                this.ap[0] = this.ap[0] + byArrayArray[this.ag][0];
                this.ap[1] = this.ap[1] + byArrayArray[this.ag][1];
            } else {
                this.m[0] = this.m[0] + byArrayArray[this.ag][0];
                this.m[1] = this.m[1] + byArrayArray[this.ag][1];
            }
            ++this.ag;
            return;
        }
        if (e4.ag <= 0 && !e4.an) {
            e4.ag = 0;
            e4.an = true;
            byte[] byArray = new byte[]{7, 10, 15, 16, 19};
            if (e3.aa == 1) {
                db = Main.j.a(Main.k.B[byArray[e4.n]], 0);
                db.b(this.ap[0] + aB.getWidth() / 2, this.ap[1] + aB.getHeight() / 2);
                aB = null;
            } else {
                aC = null;
                db = Main.j.a(Main.k.B[byArray[e4.n]], 0);
                db.b(this.m[0], this.m[1]);
            }
        }
        if (e4.an) {
            db.b(graphics);
            if (db.c()) {
                int n = 0;
                if (e3.aa == -1) {
                    bI = true;
                    bF = true;
                    bJ = true;
                    di = "\u6218\u6597\u80dc\u5229\uff01";
                    Main.l.h = true;
                    Main.l.a = 10000;
                    this.c(e2, e3);
                    o.put("isWin", "true");
                    if (at == 0) {
                        o.put("fight_Value", "1");
                    } else {
                        o.put("fight_Value", "3");
                    }
                    this.a(e2, e3, 8);
                } else if (e3.aa == 1) {
                    bI = true;
                    bF = true;
                    di = Main.j.cY[Main.j.h[Main.j.e][0]].aH + "\u5df2\u6b7b\u4ea1\uff0c\u8bf7\u9009\u62e9\u65b0\u4ed9\u5ba0\uff01";
                    n = 0;
                    int n2 = 0;
                    while (n2 < h.length) {
                        if (h[n2][0] != -1 && Main.j.cY[Main.j.h[n2][0]].ag > 1) {
                            ++n;
                        }
                        ++n2;
                    }
                    if (n == 0) {
                        bF = true;
                        bI = true;
                        di = "\u961f\u4f0d\u5168\u706d\uff01";
                        this.a(null, null, -1);
                        if (cN.equals(cA)) {
                            o.put("isWin", "false");
                            if (at == 0) {
                                o.put("fight_Value", "2");
                            } else {
                                o.put("fight_Value", "4");
                            }
                            this.a(cY[h[e][0]], this.av, 8);
                        } else if (cx == 1) {
                            this.b(72);
                        } else {
                            o.put("isWin", "false");
                            if (at == 0) {
                                o.put("fight_Value", "2");
                            } else {
                                o.put("fight_Value", "4");
                            }
                            this.a(cY[h[e][0]], this.av, 8);
                        }
                        cX = 6;
                    } else {
                        this.a(null, null, 7);
                        bx = true;
                        this.by = true;
                    }
                }
            }
            db.a(true);
            return;
        }
        this.a(e2, e3, 6);
    }

    final void d(Graphics graphics, rf.e e2, rf.e e3) {
        rf.e e4 = null;
        rf.e e5 = null;
        Image image = null;
        if (e3.aa == 1) {
            e4 = e2;
            e5 = e3;
            image = this.aE;
        } else if (e3.aa == -1) {
            e4 = e3;
            e5 = e2;
            image = this.aF;
        }
        if (e4.ao) {
            graphics.drawImage(image, e4.af, e4.aR - 3 * this.ag, 0);
            if (this.ag > 7) {
                e4.ao = false;
                this.a(e2, e3, 0);
            }
            ++this.ag;
            return;
        }
        this.a(e5, e4, 0);
    }

    public final void k() {
        if (bi) {
            int n = Math.abs(this.cJ.nextInt()) % 100;
            if (n < ar && dp == -1 && dF > dD && dF < dE) {
                this.a(3);
                at = 0;
            }
            if (dF >= dE && ar > 0) {
                this.a(3);
                at = 0;
            }
        }
    }

    final void e(Graphics graphics, rf.e e2, rf.e e3) {
        this.ch = true;
        e2.aa = (byte)-1;
        e3.aa = (byte)-1;
        if (this.cm[0] + e2.aG < t - 24) {
            this.cm[0] = this.cm[0] + e2.aG;
        } else {
            this.cm[0] = t - 24;
            this.a(null, null, 1);
        }
        if (this.cm[1] + e3.aG < t - 24) {
            this.cm[1] = this.cm[1] + e3.aG;
            return;
        }
        this.cm[1] = t - 24;
        this.a(null, null, 1);
    }

    final void f(Graphics graphics, rf.e e2, rf.e e3) {
        if (this.cm[0] >= this.cm[1]) {
            if (!bv) {
                ++this.aj;
                bv = true;
                if (this.ch) {
                    M[0].a(0);
                }
            }
            return;
        }
        if (e3.aa == -1) {
            ++this.ak;
            this.c(e3);
        }
        if (e3.aa == 0) {
            if (!bI) {
                Main.j.db.y = 0;
            }
            bI = true;
            bF = true;
            di = "\u8865\u8840\u6210\u529f\uff01";
            db.b(this.m[0], this.m[1]);
            db.a(true);
            if (db.c()) {
                this.a(e2, e3, 0);
            }
            db.b(graphics);
            return;
        }
        if (e3.aa == 1) {
            this.a(null, null, 2);
            return;
        }
        if (e3.aa == 2) {
            bI = true;
            bF = true;
            bE = true;
            di = e3.aH + "\u9003\u8dd1\u6210\u529f\uff01";
            e3.aa = (byte)-1;
            this.a(e2, e3, -1);
            this.b(15);
        }
    }

    final void a(rf.e e2, rf.e e3) {
        if (e2.aa == 1) {
            this.a(null, null, 3);
        }
        if (e3.aa == 1) {
            this.a(null, null, 3);
            return;
        }
        if (e2.aa == 0) {
            this.a(e2, e3, (int)this.ck, this.cS);
            return;
        }
        if (!bI) {
            this.a(null, null, 3);
        }
    }

    final void e(rf.e e2) {
        switch (e2.n) {
            case 0: {
                this.O = new int[]{0, 9, 8, 9, 8};
                break;
            }
            case 1: {
                this.O = new int[]{0, 12, 11, 12, 11};
                break;
            }
            case 2: {
                this.O = new int[]{0, 13, 14, 13, 14};
                break;
            }
            case 3: {
                this.O = new int[]{0, 18, 17, 18, 17};
                break;
            }
            case 4: {
                this.O = new int[]{0, 20, 21, 20, 21};
            }
        }
        dc = Main.j.a(Main.k.B[this.O[e2.at]], 0);
        if (e2.at == 3 || e2.at == 4) {
            dc = Main.j.a(Main.k.B[this.O[e2.at - 2]], 0);
            dc.a(1);
        }
    }

    final void g(Graphics graphics, rf.e e2, rf.e e3) {
        if (this.ck == 17 || this.ck == 18 || this.ck == 19 || this.ck == 20) {
            e3.af = this.m[0];
            e3.aR = this.m[1];
            db.b(e3.af, e3.aR);
            db.b(graphics);
            db.a(true);
            if (db.c()) {
                this.a(e2, e3, 10);
                bI = true;
                bF = true;
            }
            return;
        }
        e2.af = this.ap[0];
        e2.aR = this.ap[1];
        db.b(87, 126);
        db.a(false);
        if (db.c()) {
            this.b(-1);
            e2.b(this.m[0], this.m[1]);
            this.a(e2, e3, 0);
            Main.j.db.y = 0;
            aB = rf.b.a("/Image/guai" + h[e][1] + ".png");
            this.S = 0;
        }
        db.b(graphics);
        if (this.S < 10) {
            ++this.S;
        }
        if (ad != 0) {
            Main.j.b(graphics, aK, 87 - aX.getWidth() / 10, 100 - 4 * this.S, 0, 0, aK.getWidth() / 2, aK.getHeight());
            rf.b.a(graphics, aX, ad, 87, 100 - 4 * this.S, 0);
        }
    }

    final void h(Graphics graphics, rf.e e2, rf.e e3) {
        if (!bI) {
            if (this.bq) {
                this.a(e2, e3, 8);
                return;
            }
            this.a(e2, e3, 0);
        }
    }

    public final int[] c(String string) {
        if (string == null) {
            string = "1";
        }
        int n = string.indexOf("/");
        int[] nArray = new int[2];
        if (n != -1) {
            nArray[0] = Integer.parseInt(string.substring(0, n));
            nArray[1] = Integer.parseInt(string.substring(n + 1, string.length()));
        } else {
            nArray[0] = 1;
            nArray[1] = 1;
        }
        return nArray;
    }

    public static final int f(int n) {
        b b2 = (b)Main.l.d[0].elementAt(n);
        return Integer.parseInt(b2.b);
    }

    public static final String[] g(int n) {
        b b2 = (b)Main.l.d[0].elementAt(n);
        return b2.c;
    }

    public static final j l() {
        if (ay == null) {
            ay = new j();
        }
        return ay;
    }

    public static final rf.e d(String string) {
        int n = 0;
        while (n < u.length) {
            if (Main.j.u[n].t.equals(string)) {
                return u[n];
            }
            ++n;
        }
        return null;
    }

    public static final rf.e e(String string) {
        rf.e e2 = null;
        int n = 0;
        while (n < L.size()) {
            e2 = (rf.e)L.elementAt(n);
            if (e2.t.equals(string)) {
                return e2;
            }
            ++n;
        }
        return e2;
    }

    public final void f(int n, int n2) {
        if (n == -1) {
            cy += n2;
            return;
        }
        if (n <= 20) {
            int n3 = 0;
            while (n3 < n2) {
                this.d(n);
                ++n3;
            }
            return;
        }
        int n4 = 0;
        while (n4 < n2) {
            this.c(n);
            ++n4;
        }
    }

    public final void m() {
        if (GameMidlet.i) {
            if (dC.size() == 0) {
                i i2 = null;
                i2 = new i(21, 0);
                dC.addElement(i2);
            }
            this.a(9);
            return;
        }
        this.a(8);
    }

    public final void f(rf.e e2) {
        e2.Y = -1;
        dl = "";
        e2.ao = false;
        e2.al = true;
        e2.aj = true;
        e2.ak = true;
        e2.ar = false;
        e2.U = "-1";
        e2.X = "-1";
        e2.W = "-1";
        e2.V = "-1";
        int n = 0;
        while (n < bn.length) {
            Main.j.bn[n] = true;
            Main.j.bo[n] = true;
            ++n;
        }
    }

    public final void n() {
        int n = 0;
        while (n < cC.length) {
            int n2 = 0;
            while (n2 < cC[n].length) {
                Main.j.cC[n][n2] = -1;
                ++n2;
            }
            ++n;
        }
        Object var2_3 = null;
        int n3 = 0;
        while (n3 < cC.length) {
            int n4 = 0;
            while (n4 < Main.k.F.length) {
                if (Main.j.cY[n3].aD >= Integer.parseInt(Main.k.F[n4][7]) && Main.j.cY[n3].n == Integer.parseInt(Main.k.F[n4][0])) {
                    int n5 = 0;
                    while (n5 < cC.length) {
                        if (cC[n3][n5] == -1) {
                            Main.j.cC[n3][n5] = (byte)n4;
                            break;
                        }
                        ++n5;
                    }
                }
                ++n4;
            }
            ++n3;
        }
    }

    public static final void o() {
        switch (p) {
            case 0: 
            case 1: {
                Main.a.p = 240;
                Main.a.o = 320;
                return;
            }
            case 3: {
                Main.a.p = 240;
                Main.a.o = 320;
                return;
            }
            case 2: {
                Main.a.p = 240;
                Main.a.o = 320;
                return;
            }
            case 4: 
            case 5: {
                Main.a.p = 240;
                Main.a.o = 320;
                Main.a.d().g = -21;
                Main.a.d().k = -22;
                return;
            }
            case 6: {
                Main.a.p = 320;
                Main.a.o = 240;
            }
        }
    }

    public final void p() {
        ca = new byte[50];
        int n = 0;
        while (n < Main.k.J.length) {
            Main.k.J[n][2] = "0";
            ++n;
        }
        dB.removeAllElements();
        dC.removeAllElements();
        if (dC.size() == 0) {
            i i2 = null;
            i2 = new i(21, 0);
            dC.addElement(i2);
        }
        int n2 = 0;
        while (n2 < cY.length) {
            Main.j.cY[n2] = new rf.e();
            ++n2;
        }
        int n3 = 0;
        while (n3 < cZ.length) {
            Main.j.cZ[n3] = new rf.e();
            ++n3;
        }
        Main.j.cZ[0].t = "guai11";
        Main.j.cZ[0].aD = 10;
        Main.j.cZ[0].ae = 11;
        Main.j.cZ[0].ab = 1;
        Main.j.cZ[0].ag = 63;
        Main.j.cZ[0].ax = 17;
        Main.j.cZ[0].Z = 0;
        this.g(cZ[0]);
        Main.j.cZ[0].ag = Main.j.cZ[0].aE;
        Main.j.cZ[0].ax = Main.j.cZ[0].aF;
        Main.j.cY[1].t = "guai14";
        Main.j.cY[1].aD = 1;
        Main.j.cY[1].ae = 14;
        Main.j.cY[1].ab = 1;
        Main.j.cY[1].ag = 63;
        Main.j.cY[1].ax = 17;
        Main.j.cY[1].Z = 0;
        Main.j.ca[14] = 1;
        this.g(cY[1]);
        Main.j.cY[1].ag = Main.j.cY[1].aE;
        Main.j.cY[1].ax = Main.j.cY[1].aF;
        Main.j.cY[0].t = "guai32";
        Main.j.cY[0].aD = 4;
        Main.j.cY[0].ab = 1;
        Main.j.cY[0].ag = 48;
        Main.j.cY[0].ax = 25;
        Main.j.cY[0].Z = 0;
        Main.j.ca[32] = 1;
        this.g(cY[0]);
        Main.j.cY[0].ag = Main.j.cY[0].aE;
        Main.j.cY[0].ax = Main.j.cY[0].aF;
        Main.j.h[0][0] = 0;
        Main.j.h[0][1] = 32;
    }

    public final void f(String string) {
        Main.c.a(this.getClass().getResourceAsStream("" + string), 0);
    }

    public static final boolean q() {
        return Main.b.a == 3;
    }

    public final void r() {
        bQ = false;
        switch (this.cH) {
            case 0: {
                Main.j.cF[0] = Main.j.u[Main.j.q].af;
                Main.j.cF[1] = Main.j.u[Main.j.q].aR;
                this.ah = Main.j.u[Main.j.q].T;
                int n = 0;
                while (n < cY.length) {
                    Main.j.cY[n].aq = false;
                    ++n;
                }
                if (!this.bz) {
                    this.i();
                }
                ++this.cH;
                return;
            }
            case 1: {
                if (aX == null) {
                    aX = rf.b.a("/Image/numberred.png");
                    rf.b.a("/Image/numberblue.png");
                }
                Main.j.dd[0] = Main.j.a("tx_ke", 0);
                Main.j.dd[1] = Main.j.a("tx_qu", 0);
                aG = rf.b.a("/Image/baoji.png");
                ba = rf.b.a("/Image/shanbi.png");
                bd = rf.b.a("/Image/yingzi3.png");
                ++this.cH;
                return;
            }
            case 2: {
                int n;
                int n2 = Math.abs(this.cJ.nextInt()) % this.au.length;
                if (this.an[1] != this.an[0]) {
                    n = this.an[0] + Math.abs(this.cJ.nextInt()) % (this.an[1] - this.an[0]);
                    this.ci = false;
                } else {
                    n = this.an[0];
                }
                this.av = Main.j.a(this.au[n2], 2);
                this.av.aD = n;
                aC = rf.b.a("/Image/" + this.au[n2] + ".png");
                this.g(this.av);
                this.av.ag = this.av.aE;
                this.av.ax = this.av.aF;
                this.av.b(this.ap[0], this.ap[1]);
                ++this.cH;
                return;
            }
            case 3: {
                int n = 0;
                while (n < h.length) {
                    if (h[n][0] != -1 && !Main.j.cY[Main.j.h[n][0]].an) {
                        e = n;
                        break;
                    }
                    ++n;
                }
                aB = rf.b.a("/Image/" + Main.j.cY[Main.j.h[Main.j.e][0]].t + ".png");
                cY[h[e][0]].b(this.m[0], this.m[1]);
                this.cm[0] = 100;
                this.cm[1] = 100;
                this.cn[0] = s / 2 - 13;
                this.cn[1] = s / 2 - 11;
                try {
                    this.ao = rf.b.a("/Image/" + this.d + ".png");
                    this.am = rf.b.a("/Image/fight_up.png");
                    this.al = rf.b.a("/Image/fight_mid.png");
                    if (t == 320) {
                        this.am = rf.b.a(this.am, t / 2, this.am.getHeight());
                        this.ao = rf.b.a(this.ao, t, (s - this.am.getHeight() * 2) / 2);
                        this.al = rf.b.a(this.al, t, this.al.getHeight() / 2);
                    }
                }
                catch (Exception exception) {
                    Exception exception2 = exception;
                    exception.printStackTrace();
                }
                dp = -1;
                M = new rf.e[1];
                Main.j.M[0] = Main.j.a("ui_fight", 5);
                Main.j.M[0].t = "ui_fight";
                Main.j.M[0].aO = 0;
                N = new rf.e[1];
                Main.j.N[0] = Main.j.a("ui_select", 5);
                Main.j.N[0].t = "ui_select";
                Main.j.N[0].aO = 0;
                this.a(Main.j.cB.c);
                ++this.cH;
                return;
            }
            case 4: {
                this.a(4);
                int n = 0;
                while (n < cY.length) {
                    this.f(cY[n]);
                    ++n;
                }
                this.f(cY[h[e][0]]);
                cO = null;
                Main.l.h = true;
                Main.l.a = 10000;
                bj = false;
                if (g != null) {
                    cB.a("/pak/" + g, (byte)0);
                    cP = new l(Main.j.cB.e, Main.j.cB.n);
                    Main.l.a = -1;
                    this.ch = false;
                    this.cg = false;
                }
                this.a(null, null, 0);
            }
        }
    }

    final void s() {
        switch (this.cH) {
            case 0: {
                aZ = rf.b.a("/Image/rand.png");
                cl = new Image[40];
                int n = 0;
                while (n < cl.length) {
                    Main.j.cl[n] = rf.b.a("/Image/fb" + (n + 1) + ".png");
                    ++n;
                }
                bc = rf.b.a("/Image/wenhao.png");
                rf.b.a("/Image/yingzi.png");
                aM = rf.b.a("/Image/jiantou1.png");
                rf.b.a("/Image/jiantou0.png");
                aY = rf.b.a("/Image/ok.png");
                aJ = rf.b.a("/Image/ad.png");
                aK = rf.b.a("/Image/jiajian.png");
                aH = rf.b.a("/Image/black.png");
                cB = new h();
                de = Main.j.a("start", 0);
                ++this.cH;
                return;
            }
            case 1: {
                cB.a("/t/item1.t", (byte)3);
                ++this.cH;
                return;
            }
            case 2: {
                cB.a("/t/item2.t", (byte)3);
                ++this.cH;
                return;
            }
            case 3: {
                cB.a("/t/item3.t", (byte)3);
                ++this.cH;
                return;
            }
            case 4: {
                cB.a("/t/item4.t", (byte)3);
                ++this.cH;
                return;
            }
            case 5: {
                cB.a("/t/item5.t", (byte)3);
                ++this.cH;
                return;
            }
            case 6: {
                cB.a("/t/item6.t", (byte)3);
                cB.a("/t/item7.t", (byte)3);
                cB.a("/t/item8.t", (byte)3);
                ++this.cH;
                return;
            }
            case 7: {
                int n = 0;
                while (n < h.length) {
                    Main.j.h[n][0] = -1;
                    Main.j.h[n][1] = -1;
                    ++n;
                }
                int n2 = 0;
                while (n2 < cC.length) {
                    int n3 = 0;
                    while (n3 < cC[n2].length) {
                        Main.j.cC[n2][n3] = -1;
                        ++n3;
                    }
                    ++n2;
                }
                if (this.cc) {
                    cs = 100;
                    Enumeration enumeration = o.keys();
                    while (enumeration.hasMoreElements()) {
                        String string = (String)enumeration.nextElement();
                        o.put(string, "0");
                    }
                    if (GameMidlet.i) {
                        o.put("jq", GameMidlet.l);
                    }
                    o.put("taskMain", "0");
                    this.p();
                    this.cc = false;
                    cN = GameMidlet.k;
                } else {
                    rf.b.b(cz[cT]);
                }
                ++this.cH;
                return;
            }
            case 8: {
                if (!this.bz) {
                    this.i();
                }
                if (df == 4) {
                    o.put("fightPut", "1");
                } else {
                    o.put("fightPut", "0");
                }
                cO = null;
                if (GameMidlet.i) {
                    cN = GameMidlet.k;
                }
                this.d();
                cB.a("/pak/" + cN, (byte)0);
                cO = new l(Main.j.cB.e, Main.j.cB.n);
                ++this.cH;
                return;
            }
            case 9: {
                aB = rf.b.a("/Image/guai" + h[e][1] + ".png");
                ++this.cH;
                return;
            }
            case 10: {
                cB.a("/pak/" + cN, (byte)0);
                ++this.cH;
                return;
            }
            case 11: {
                cO = new l(Main.j.cB.e, Main.j.cB.n);
                ++this.cH;
                return;
            }
            case 12: {
                ++this.cH;
            }
        }
    }

    public final void g(rf.e e2) {
        int n = Integer.parseInt(e2.t.substring(4, e2.t.length()));
        e2.aH = Main.k.z[n][0];
        e2.o = Main.k.A[n][0];
        e2.p = Main.k.A[n][1];
        e2.l = Main.k.A[n][2];
        e2.k = Main.k.A[n][3];
        e2.q = Main.k.A[n][4];
        e2.m = Main.k.A[n][5];
        e2.n = Main.k.A[n][6];
        e2.ae = Integer.parseInt(Main.k.z[n][1]);
        e2.aC = (e2.aD + 9 * e2.o * e2.o - 8) * e2.aD;
        this.a(e2);
        this.n();
    }

    final void t() {
        this.cH = 4;
        this.a(8);
    }

    public final void u() {
        if (bv && cP != null && this.cg) {
            cP.a(this);
        }
        if (cO != null) {
            cO.a(this);
        }
        if (!Main.l.h && Main.l.b != 43 && Main.l.b != 49 && Main.l.b != 51 || dp != -1 || Main.b.a == 1 || Main.b.a == 3 && cr == null && Main.l.b != 43 && Main.l.b != 49) {
            Main.a.d().q = false;
        } else {
            Main.a.d().q = true;
            Main.a.d().r = true;
        }
        if (df == 4) {
            Main.a.d().q = true;
        }
        if (bj) {
            Main.a.d().q = false;
            Main.a.d().r = false;
        } else {
            Main.a.d().r = true;
        }
        if (Main.a.d().s) {
            Main.a.d().q = false;
            Main.a.d().r = false;
        }
        if (df == 8 || bO) {
            Main.a.d().q = true;
        }
        switch (df) {
            case 0: {
                return;
            }
            case 3: {
                return;
            }
            case 2: {
                if (this.Q.e == -1 || !Main.a.d().m()) break;
                if (bl) {
                    bl = false;
                }
                Main.l.a(cO.a(Main.j.g(this.Q.e)[4]), 0);
                this.Q.e = -1;
                Main.a.d().a();
            }
        }
    }

    public final void a(int n, String string) {
        int n2 = Integer.parseInt(string);
        if (n2 > 0 && n2 < 20) {
            string = "1";
        } else if (n2 == 20) {
            string = "2";
        }
        Main.k.J[n][2] = string;
    }

    public final void c(String string, String string2) {
        int n = Integer.parseInt(string);
        int n2 = Integer.parseInt(string2);
        this.bA = 0;
        rf.g.c = true;
        rf.g.d = true;
        this.k = n * this.dO;
        this.l = n2 * this.dN;
        this.aw = this.k - (Main.j.b.t + (Main.j.b.k >> 1)) > 0;
        if (this.l - (Main.j.b.A + (Main.j.b.h >> 1)) > 0) {
            this.ax = true;
            return;
        }
        this.ax = false;
    }

    public final void v() {
        this.bA = 3;
        this.k = Main.j.u[Main.j.q].af;
        this.l = Main.j.u[Main.j.q].aR;
        rf.g.c = true;
        rf.g.d = true;
        this.aw = this.k - (Main.j.b.t + (Main.j.b.k >> 1)) > 0;
        if (this.l - (Main.j.b.A + (Main.j.b.h >> 1)) > 0) {
            this.ax = true;
            return;
        }
        this.ax = false;
    }

    public final void a(String string, String string2, int n, int n2) {
        rf.e e2 = Main.j.d(string);
        if (string.equals("player")) {
            if (string2.equals("L")) {
                e2.aL = -4;
                e2.aM = 0;
                e2.T = 3;
            } else if (string2.equals("R")) {
                e2.aL = 4;
                e2.aM = 0;
                e2.T = 4;
            } else if (string2.equals("D")) {
                e2.aM = 4;
                e2.aL = 0;
                e2.T = 2;
            } else if (string2.equals("U")) {
                e2.aM = -4;
                e2.aL = 0;
                e2.T = 1;
            }
            int n3 = 0;
            while (n3 < u.length) {
                if (Main.j.u[n3].t.equals(string)) {
                    dG = n3;
                }
                ++n3;
            }
            e2.R = n * this.dO + 8;
            e2.S = n2 * this.dN + 8;
            this.a(e2, string2);
            Main.j.a(e2, 101, -1);
            return;
        }
        int n4 = 0;
        while (n4 < u.length) {
            if (Main.j.u[n4].t.equals(string)) {
                dG = n4;
            }
            ++n4;
        }
        int n5 = Integer.parseInt(string2.substring(0, 1));
        String string3 = string2.substring(1, 2);
        Main.j.a(e2, n5, string3, -1);
        if (string3.equals("L")) {
            e2.aL = -4;
            e2.aM = 0;
            e2.T = 3;
        } else if (string3.equals("R")) {
            e2.aL = 4;
            e2.aM = 0;
            e2.T = 4;
        } else if (string3.equals("D")) {
            e2.aM = 4;
            e2.aL = 0;
            e2.T = 2;
        } else if (string3.equals("U")) {
            e2.aM = -4;
            e2.aL = 0;
            e2.T = 1;
        }
        e2.R = n * this.dO + 8;
        e2.S = n2 * this.dN + 8;
    }

    public final void w() {
        if (dG != -1) {
            if (Main.j.u[Main.j.dG].aL != 0) {
                if (Main.j.u[Main.j.dG].T == 4 ? Main.j.u[Main.j.dG].af < Main.j.u[Main.j.dG].R : Main.j.u[Main.j.dG].af > Main.j.u[Main.j.dG].R) {
                    Main.j.u[Main.j.dG].af += Main.j.u[Main.j.dG].aL;
                } else {
                    dG = -1;
                    Main.j.i(0);
                    Main.j.a();
                }
                return;
            }
            if (Main.j.u[Main.j.dG].T == 1 ? Main.j.u[Main.j.dG].aR > Main.j.u[Main.j.dG].S : Main.j.u[Main.j.dG].aR < Main.j.u[Main.j.dG].S) {
                Main.j.u[Main.j.dG].aR += Main.j.u[Main.j.dG].aM;
                return;
            }
            dG = -1;
            Main.j.i(0);
            Main.j.a();
        }
    }

    public final void x() {
        try {
            Main.c.a[0].setLoopCount(-1);
            Main.c.a[0].start();
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public final void r(Graphics graphics) {
        if (this.bP) {
            if (bV) {
                ++this.V;
                if (this.V % 2 == 0) {
                    graphics.setColor(0);
                    graphics.fillRect(0, 0, t, s);
                }
            }
            this.Q.a(graphics, 0, db);
            db.a(this.T);
            if (db.c()) {
                this.bP = false;
                bV = false;
                Main.b.a(0);
                ++Main.l.a;
            }
        }
    }

    protected final void y() {
        int n;
        if (cd) {
            if (++bh > 3) {
                cd = false;
                bh = 0;
            }
            n = bh % 2 == 0 ? 1 : -1;
            this.Q.a(0, 0, -16 * n, 16 * n);
        }
        if (br) {
            if (++bh > 3) {
                br = false;
                bh = 0;
            }
            n = bh % 2 == 0 ? 1 : -1;
            this.Q.a(0, 0, 2 * n, 0);
        }
        if (this.bA == 0 || this.bA == 3) {
            n = this.k - (Main.j.b.t + (Main.j.b.k >> 1));
            int n2 = this.l - (Main.j.b.A + (Main.j.b.h >> 1));
            if ((this.aw ? n > 0 : n < 0) && rf.g.c || (this.ax ? n2 > 0 : n2 < 0) && rf.g.d) {
                if ((this.aw ? n > 0 : n < 0) && rf.g.c) {
                    this.Q.a(0, 0, this.aw ? 5 : -5, 0);
                }
                if ((this.ax ? n2 > 0 : n2 < 0) && rf.g.d) {
                    this.Q.a(0, 0, 0, this.ax ? 5 : -5);
                }
            }
            if (!((this.aw ? n > 0 : n < 0) && rf.g.c || (this.ax ? n2 > 0 : n2 < 0) && rf.g.d)) {
                this.bA = this.bA == 3 ? 2 : 1;
                Main.b.a(0);
                ++Main.l.a;
            }
            return;
        }
        if (this.bA == 1) {
            return;
        }
        if (this.bA == 2 && u != null && u[q] != null) {
            n = Main.j.u[Main.j.q].af - (Main.j.b.t + (Main.j.b.k >> 1));
            int n3 = Main.j.u[Main.j.q].aR - (Main.j.b.A + (Main.j.b.h >> 1));
            if (this.bN) {
                this.bN = false;
                this.Q.a(0, 0, n / 6, n3 / 6);
                return;
            }
            this.Q.a(0, 0, n / 6, n3 / 6);
        }
    }

    public final void s(Graphics graphics) {
        try {
            if (bO) {
                this.i(graphics);
                return;
            }
            switch (df) {
                case 12: {
                    this.e(graphics);
                    break;
                }
                case 8: {
                    this.f(graphics);
                    break;
                }
                case 15: {
                    this.h(graphics);
                    break;
                }
                case 9: {
                    graphics.setColor(0);
                    graphics.fillRect(0, 0, t, s);
                    graphics.drawImage(aT, -aT.getWidth() + this.cH * t / cI, s * 2 / 3, 0);
                    this.b(graphics, this.dg, t - 20, s, 10, s * 2 / 3 - rf.b.f * (rf.b.b + 5) - 10, 0xFFFFFF);
                    graphics.setClip(0, 0, t, s);
                    this.s();
                    break;
                }
                case 13: {
                    cI = 4;
                    graphics.setColor(0);
                    graphics.fillRect(0, 0, t, s);
                    graphics.drawImage(aT, -aT.getWidth() + this.cH * t / cI, s * 2 / 3, 0);
                    this.t();
                    break;
                }
                case 0: {
                    graphics.setColor(0);
                    graphics.fillRect(0, 0, t, s);
                    this.b(graphics, this.dg, t - 20, s, 10, s * 2 / 3 - rf.b.f * (rf.b.b + 5) - 10, 0xFFFFFF);
                    graphics.setClip(0, 0, t, s);
                    graphics.drawImage(aT, -aT.getWidth() + this.cH * t / cI, s * 2 / 3, 0);
                    this.h();
                    this.b(-1);
                    this.a(null, null, -1);
                    Main.b.a(0);
                    break;
                }
                case 3: {
                    graphics.setColor(0);
                    graphics.fillRect(0, 0, t, s);
                    graphics.setColor(0xFFFFFF);
                    this.b(graphics, this.dg, t - 20, s, 10, s * 2 / 3 - rf.b.f * (rf.b.b + 5) - 10, 0xFFFFFF);
                    graphics.setClip(0, 0, t, s);
                    graphics.drawImage(aT, -aT.getWidth() + this.cH * t / cI, s * 2 / 3, 0);
                    this.r();
                    break;
                }
                case 5: {
                    int n = Integer.parseInt(String.valueOf(o.get("jq")));
                    String[] stringArray = new String[]{"l0", "l5", "o0", "p0", "q1", "r5"};
                    if (n >= 41) {
                        stringArray = new String[]{"l0", "n1", "o0", "p0", "q1", "r5"};
                    } else if (n >= 18) {
                        stringArray = new String[]{"l0", "n1", "o0", "p0", "q1", "r5"};
                    }
                    int[][] nArrayArray = new int[][]{{183, 215}, {57, 159}, {201, 68}, {50, 233}, {49, 3}, {105, 84}};
                    int[][] nArrayArray2 = new int[][]{{215, 224}, {34, 173}, {210, 102}, {17, 250}, {20, 40}, {131, 110}};
                    int[][] nArrayArray3 = new int[][]{{199, 253}, {57, 182}, {198, 135}, {43, 261}, {49, 52}, {105, 121}};
                    int[][] nArrayArray4 = new int[][]{{0, 0}, {9, 1}, {18, 2}, {33, 3}, {41, 4}, {45, 5}};
                    if (t == 320) {
                        nArrayArray = new int[][]{{238, 156}, {76, 115}, {268, 46}, {65, 177}, {34, 19}, {147, 57}};
                        nArrayArray2 = new int[][]{{-500, -500}, {-500, -500}, {-500, -500}, {-500, -500}, {-500, -500}, {-500, -500}};
                        nArrayArray3 = new int[][]{{280, 189}, {122, 144}, {274, 96}, {104, 202}, {105, 13}, {146, 92}};
                    }
                    graphics.drawImage(aD, 0, 0, 0);
                    graphics.drawImage(aL, nArrayArray[cv][0], nArrayArray[cv][1] + this.Y, 0);
                    int n2 = nArrayArray4.length - 1;
                    while (n2 >= 0) {
                        if (n == 41) {
                            db.b(nArrayArray3[0][0], nArrayArray3[0][1]);
                            db.b(graphics);
                            db.a(true);
                            Main.j.b(graphics, aJ, nArrayArray2[0][0], nArrayArray2[0][1], 0 * aJ.getWidth() / 6, 0, aJ.getWidth() / 6, aJ.getHeight());
                            break;
                        }
                        if (n >= 48) {
                            db.b(nArrayArray3[4][0], nArrayArray3[4][1]);
                            db.b(graphics);
                            db.a(true);
                            Main.j.b(graphics, aJ, nArrayArray2[4][0], nArrayArray2[4][1], 4 * aJ.getWidth() / 6, 0, aJ.getWidth() / 6, aJ.getHeight());
                            break;
                        }
                        if (n >= nArrayArray4[n2][0]) {
                            db.b(nArrayArray3[n2][0], nArrayArray3[n2][1]);
                            db.b(graphics);
                            db.a(true);
                            Main.j.b(graphics, aJ, nArrayArray2[n2][0], nArrayArray2[n2][1], n2 * aJ.getWidth() / 6, 0, aJ.getWidth() / 6, aJ.getHeight());
                            break;
                        }
                        --n2;
                    }
                    int n3 = nArrayArray4.length - 1;
                    while (n3 >= 0) {
                        if (n >= nArrayArray4[n3][0]) {
                            Main.j.b(graphics, aJ, nArrayArray2[n3][0], nArrayArray2[n3][1], n3 * aJ.getWidth() / 6, 0, aJ.getWidth() / 6, aJ.getHeight());
                        }
                        --n3;
                    }
                    if (Main.a.d().k() || Main.a.d().w()) {
                        cv = cv > 0 ? --cv : stringArray.length - 1;
                    } else if (Main.a.d().u() || Main.a.d().e()) {
                        cv = cv < stringArray.length - 1 ? ++cv : 0;
                    } else if (Main.a.d().h()) {
                        int n4 = nArrayArray4.length - 1;
                        while (n4 >= 0) {
                            if (n >= nArrayArray4[n4][0]) {
                                if (cv <= nArrayArray4[n4][1]) {
                                    o.put("mapIndex", String.valueOf(cv));
                                    Main.b.a(0);
                                    ++Main.l.a;
                                    this.a(0);
                                    cN = stringArray[cv] + ".p";
                                    cQ = stringArray[cv] + ".p";
                                    this.h();
                                    this.Y = 0;
                                    break;
                                }
                                if (n4 == 0) {
                                    bF = true;
                                    bI = true;
                                    di = "\u8be5\u573a\u666f\u672a\u5f00\u542f";
                                    break;
                                }
                            }
                            --n4;
                        }
                    }
                    graphics.setColor(0xFF0000);
                    graphics.drawString("" + cv + ":" + stringArray[cv], 10, 10, 0);
                    if (bI && di != null) {
                        Main.e.a().a(graphics, di);
                        if (++cw > 20) {
                            cw = 0;
                            bI = false;
                        }
                    }
                    this.Y = this.Y < 3 ? ++this.Y : 0;
                    Main.a.d().a();
                    break;
                }
                case 7: {
                    graphics.setColor(0);
                    graphics.fillRect(0, 0, t, s);
                    graphics.drawImage(this.aI, t / 2 - this.aI.getWidth() / 2, 0, 0);
                    this.a(graphics, "^^" + this.dk + "^", t - 20, s - this.aI.getHeight() - 20, 10, this.aI.getHeight(), 0xFFFFFF);
                    graphics.setColor(0xFFFFFF);
                    graphics.drawString(this.dk, 0, 0, 0);
                    if (Main.a.d().r()) {
                        this.a(2);
                        Main.b.a(0);
                        ++Main.l.a;
                        Main.a.d().a();
                    }
                    graphics.setClip(0, 0, t, s);
                    rf.b.a(graphics, "\u8df3\u8fc7", t - Main.e.a.stringWidth("\u8df3\u8fc7"), s - Main.k.v, 0, 0xFFFFFF, 0);
                    break;
                }
                case 14: {
                    if (cx == 1) {
                        graphics.setColor(0);
                        graphics.fillRect(0, 0, t, s);
                        if (this.aI == null) {
                            this.aI = rf.b.a("/Image/CG2.png");
                        }
                        graphics.drawImage(this.aI, t / 2 - this.aI.getWidth() / 2, 0, 0);
                        this.a(graphics, "^^\u540e\u9762\u66f4\u52a0\u7cbe\u5f69\uff0c\u671f\u5f85\u60a8\u7684\u4f53\u9a8c\uff01^", t - 20, s - this.aI.getHeight() - 20, 10, this.aI.getHeight(), 0xFFFFFF);
                        graphics.setColor(0xFFFFFF);
                        graphics.drawString(this.dk, 0, 0, 0);
                        if (Main.a.d().r()) {
                            this.a(8);
                            Main.a.d().a();
                        }
                        graphics.setClip(0, 0, t, s);
                        rf.b.a(graphics, "\u8df3\u8fc7", t - Main.e.a.stringWidth("\u8df3\u8fc7"), s - Main.k.v, 0, 0xFFFFFF, 0);
                        break;
                    }
                    this.a(8);
                    Main.a.d().a();
                    break;
                }
                case 4: {
                    this.bw = true;
                    this.a(graphics, cY[h[e][0]], this.av);
                    this.b(graphics, cY[h[e][0]], this.av);
                    graphics.drawImage(aL, this.cm[0], this.cn[0], 0);
                    graphics.drawImage(aN, this.cm[1], this.cn[1], 0);
                    if (bv && dp == -1) {
                        this.a(graphics, cY[h[e][0]]);
                    }
                    switch (dp) {
                        case 7: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.e(graphics, 0);
                            this.a(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 70: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.e(graphics, 0);
                            this.a(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 13: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.a(cY[h[e][0]], graphics);
                            graphics.setClip(0, 0, t, s);
                            this.a(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 9: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.b(graphics, 0);
                            this.a(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 14: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.b(cY[h[e][0]], graphics);
                            this.a(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 15: {
                            if (bI) break;
                            this.a(0);
                            this.a(null, null, 13);
                            break;
                        }
                        case 72: {
                            this.f(graphics, cX);
                        }
                    }
                    if (this.as == 9) {
                        this.g(graphics, cY[h[e][0]], this.av);
                    }
                    if (bj) {
                        if (dx != -1) {
                            da.b(this.dz[dx] / 2, s - P[13].getHeight() + 12);
                            da.a(graphics, false);
                        }
                        this.w(graphics);
                    }
                    Main.a.d().b = -99;
                    Main.a.d();
                    if (bI && di != null) {
                        Main.e.a().a(graphics, di);
                        if (!bJ) {
                            if (++cw > 20) {
                                cw = 0;
                                bI = false;
                            }
                        } else if (Main.a.d().m()) {
                            cw = 0;
                            bI = false;
                            bJ = false;
                        }
                    }
                    if (bU && di != null) {
                        if (this.bm) {
                            graphics.setColor(0);
                            graphics.fillRect(0, 0, t, s);
                        }
                        Main.e.a().a(graphics, di);
                        if (++cw > 10) {
                            cw = 0;
                            bU = false;
                            this.bm = false;
                            Main.b.a(0);
                            ++Main.l.a;
                        }
                    }
                    if (this.ce) {
                        this.b(graphics, do);
                    }
                    Main.a.d().a();
                    break;
                }
                case 2: {
                    this.bw = false;
                    if (this.Q != null && this.dR != null) {
                        this.Q.a(graphics, 0);
                        this.w();
                    }
                    if (q != -1 && Main.j.u[Main.j.q].aS) {
                        this.f();
                    }
                    if (this.Q != null && u != null) {
                        this.Q.a(graphics, 0, u);
                        if (bu) {
                            bu = false;
                        }
                        int n = 0;
                        while (n < u.length) {
                            if (Main.j.u[n].P != -1) {
                                if (u[n].c()) {
                                    ++Main.j.u[n].aN;
                                }
                                if (Main.j.u[n].P != -1 && Main.j.u[n].P <= Main.j.u[n].aN) {
                                    Main.j.u[n].aN = 0;
                                    Main.j.u[n].P = -1;
                                    if (Main.j.u[n].t.equals("player")) {
                                        Main.j.a(u[q], 100, -1);
                                    } else {
                                        u[n].a(cs, true);
                                    }
                                }
                            }
                            if (Main.j.u[n].aQ != null && Main.j.u[n].aI == 1 && Main.j.u[n].g != -1) {
                                if (this.Q.e == -1 && db.c()) {
                                    Main.j.u[n].g = -1;
                                }
                                db.a(graphics, true);
                                db.a(true);
                            }
                            u[n].a(true);
                            if (Main.j.u[n].aQ != null && Main.j.u[n].aI == 0 && Main.j.u[n].g != -1) {
                                if (this.Q.e == -1 && db.c()) {
                                    Main.j.u[n].g = -1;
                                }
                                db.a(graphics, true);
                                db.a(true);
                            }
                            ++n;
                        }
                        graphics.drawImage(this.aQ, 3, s - this.aQ.getHeight() - 2, 0);
                        if (Main.a.d().h()) {
                            this.b(5);
                            Main.a.d().a();
                        } else if (Main.a.d().r() && cx == 1) {
                            this.b(71);
                            Main.a.d().a();
                        }
                    }
                    switch (dp) {
                        case 4: {
                            if (dx != -1) {
                                da.b(this.dz[dx] / 2, s - P[13].getHeight() + 12);
                                da.a(graphics, false);
                            }
                            this.v(graphics);
                            break;
                        }
                        case 71: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.t(graphics);
                            break;
                        }
                        case 72: {
                            this.f(graphics, cX);
                            break;
                        }
                        case 3: {
                            this.u(graphics);
                            break;
                        }
                        case 5: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.n(graphics);
                            this.a(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 12: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.o(graphics);
                            this.a(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 7: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.e(graphics, 0);
                            this.a(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 11: {
                            this.j(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 8: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.d(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 9: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.b(graphics, 0);
                            this.a(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 21: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.b(graphics, 3);
                            this.a(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 10: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.b(graphics, 1);
                            this.a(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 6: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.p(graphics);
                            graphics.setClip(0, 0, t, s);
                            this.l(graphics);
                            break;
                        }
                        case 14: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.b(cY[h[e][0]], graphics);
                            if (this.ce) {
                                this.b(graphics, do);
                            }
                            this.a(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 16: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.a(graphics, 0);
                            this.a(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 17: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.c(graphics, 0);
                            this.a(graphics);
                            this.l(graphics);
                            break;
                        }
                        case 18: {
                            Main.e.a().a(graphics, 0, 0, t, s);
                            this.d(graphics, 0);
                            this.a(graphics);
                            this.l(graphics);
                        }
                    }
                    if (bS) {
                        Main.e.a().a(graphics, 0, 0, t, s);
                        this.k(graphics);
                    } else if (cb) {
                        Main.e.a().a(graphics, 0, 0, t, s);
                        this.q(graphics);
                    } else if (bX) {
                        this.m(graphics);
                    } else if (bC) {
                        this.a(graphics, this.dm);
                    } else if (bs) {
                        this.b(graphics);
                    }
                    Main.a.d().c = -99;
                    if (bj) {
                        if (dx != -1) {
                            da.b(this.dz[dx] / 2, s - P[13].getHeight() + 12);
                            da.a(graphics, false);
                        }
                        this.w(graphics);
                    }
                    Main.a.d().b = -99;
                    this.r(graphics);
                    if (bI && di != null) {
                        Main.e.a().a(graphics, di);
                        if (++cw > 20) {
                            cw = 0;
                            bI = false;
                        }
                    }
                    if (bU && di != null) {
                        if (this.bm) {
                            graphics.setColor(0);
                            graphics.fillRect(0, 0, t, s);
                        }
                        Main.e.a().a(graphics, di);
                        if (++cw > 10) {
                            cw = 0;
                            bU = false;
                            this.bm = false;
                            Main.b.a(0);
                            ++Main.l.a;
                        }
                    }
                    this.A();
                    this.y();
                }
            }
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.printStackTrace();
            return;
        }
    }

    public static final String a(String string, String string2, String string3) {
        if (string == null) {
            return null;
        }
        int n = 0;
        n = string.indexOf(string2, 0);
        if (n >= 0) {
            char[] cArray = string.toCharArray();
            char[] cArray2 = string3.toCharArray();
            int n2 = string2.length();
            StringBuffer stringBuffer = new StringBuffer(cArray.length);
            stringBuffer.append(cArray, 0, n).append(cArray2);
            int n3 = n += n2;
            while ((n = string.indexOf(string2, n)) > 0) {
                stringBuffer.append(cArray, n3, n - n3).append(cArray2);
                n3 = n += n2;
            }
            stringBuffer.append(cArray, n3, cArray.length - n3);
            return stringBuffer.toString();
        }
        return string;
    }

    public static final void d(String string, String string2) {
        int n = Integer.parseInt(string);
        switch (p) {
            case 4: 
            case 5: {
                if (n == -6) {
                    n = -21;
                } else if (n == -7) {
                    n = -22;
                }
                string = String.valueOf(n);
                break;
            }
            case 6: {
                if (n == 48) {
                    n = 109;
                } else if (n == -4) {
                    n = 104;
                } else if (n == -2) {
                    n = 98;
                }
                string = String.valueOf(n);
            }
        }
        cr = string;
        dn = string2;
    }

    public final void g(int n, int n2) {
        if (n2 == 0) {
            return;
        }
        cy += n2 * Integer.parseInt(Main.k.E[n][3]);
        d d2 = null;
        if (dB.size() != 0) {
            int n3 = 0;
            while (n3 < dB.size()) {
                d2 = (d)dB.elementAt(n3);
                if (d2.b == n) {
                    d2.a -= n2;
                    if (d2.a > 0) break;
                    dB.removeElementAt(n3);
                    break;
                }
                ++n3;
            }
        }
        i i2 = null;
        if (dC.size() != 0) {
            int n4 = 0;
            while (n4 < dC.size()) {
                i2 = (i)dC.elementAt(n4);
                if (i2.b == n) {
                    i2.a -= n2;
                    if (i2.a > 0) break;
                    dC.removeElementAt(n4);
                    break;
                }
                ++n4;
            }
        }
        bI = true;
        bF = true;
        di = Main.k.E[n][0] + "x" + n2 + "\u5df2\u7ecf\u5356\u51fa\u83b7\u5f97" + n2 * Integer.parseInt(Main.k.E[n][3]) + "\u91d1";
    }

    public final void h(int n) {
        cv = n;
        aD = rf.b.a("/Image/bigMap.png");
        if (t == 320) {
            aD = rf.b.a(aD, t, s);
        }
        db = Main.j.a("paopao8", 0);
        this.a(5);
    }

    public static final void b(Graphics graphics, Image image, int n, int n2, int n3, int n4, int n5, int n6) {
        graphics.setClip(n, n2, n5, n6);
        graphics.clipRect(n, n2, n5, n6);
        graphics.drawImage(image, n - n3, n2 - n4, 0);
        graphics.setClip(0, 0, t, s);
    }

    final void a(rf.e e2, String string) {
        if (string.equals("U")) {
            e2.T = 1;
            Main.j.a(e2, cE, -1);
            return;
        }
        if (string.equals("D")) {
            e2.T = 2;
            Main.j.a(e2, cE, -1);
            return;
        }
        if (string.equals("L")) {
            e2.T = 3;
            e2.a((byte)2);
            Main.j.a(e2, cE, -1);
            return;
        }
        if (string.equals("R")) {
            e2.T = 4;
            Main.j.a(e2, cE, -1);
        }
    }

    public static final void i(int n) {
        Main.b.a(n);
    }

    public final void e(String string, String string2) {
        if (u != null) {
            Main.j.d(string);
            return;
        }
        Main.j.e(string);
    }

    public final void a(String string, int n, int n2, String string2) {
        int n3 = 0;
        while (n3 < u.length) {
            if (Main.j.u[n3].t.equals(string)) {
                if (string.equals("player")) {
                    if (string2.equals("L")) {
                        Main.j.u[n3].T = 3;
                    } else if (string2.equals("R")) {
                        Main.j.u[n3].T = 4;
                    } else if (string2.equals("D")) {
                        Main.j.u[n3].T = 2;
                    } else if (string2.equals("U")) {
                        Main.j.u[n3].T = 1;
                    }
                    u[n3].b(n * this.dO + 8, n2 * this.dN + 8);
                    this.a(u[n3], string2);
                    return;
                }
                int n4 = Integer.parseInt(string2.substring(0, 1));
                String string3 = string2.substring(1, 2);
                Main.j.a(u[n3], n4, string3, -1);
                if (string3.equals("L")) {
                    Main.j.u[n3].T = 3;
                } else if (string3.equals("R")) {
                    Main.j.u[n3].T = 4;
                } else if (string3.equals("D")) {
                    Main.j.u[n3].T = 2;
                } else if (string3.equals("U")) {
                    Main.j.u[n3].T = 1;
                }
                u[n3].b(n * this.dO + 8, n2 * this.dN + 8);
                Main.j.a(u[n3], n4, string3, -1);
                return;
            }
            ++n3;
        }
    }

    public final void g(String string) {
        this.ds = Long.parseLong(string);
        this.az = System.currentTimeMillis();
        this.aA = 0;
        bZ = true;
        o.put("task_value", "-1");
    }

    public final void b(String string, String string2, String string3, String string4, String string5, String string6) {
        bV = string.equals("tx_jin_ld");
        int n = Integer.parseInt(string2);
        int n2 = Integer.parseInt(string3);
        int n3 = Integer.parseInt(string4);
        int n4 = Integer.parseInt(string5);
        this.T = string6.equals("true");
        db = Main.j.a(string, 0);
        db.b(n * this.dO + n3, n2 * this.dN + n4);
        db.a(0);
        this.bP = true;
        if (string.equals("tx_huo_fs") || string.equals("tx_jin_ld") || string.equals("tx_jin_jf") || string.equals("tx_mu_dw")) {
            cd = true;
        }
    }

    public final void a(String string, boolean bl) {
        int n = 0;
        while (n < u.length) {
            if (Main.j.u[n].t.equals(string)) {
                if (string.equals("player")) {
                    Main.j.u[Main.j.q].aS = bl;
                    Main.j.u[n].aS = bl;
                    return;
                }
                Main.j.u[n].aS = bl;
                return;
            }
            ++n;
        }
    }

    public final void t(Graphics graphics) {
        int n = bb.getHeight() + 30;
        int n2 = t / 2 - P[12].getWidth() / 2;
        int n3 = s / 2 - n / 2 - P[12].getHeight() * 2;
        Main.e.a().b(graphics, n2, n3, n);
        if (System.currentTimeMillis() - this.i >= this.j) {
            this.i = System.currentTimeMillis();
            if (ab < 3) {
                ++ab;
            }
        }
        int n4 = 0;
        while (n4 < ab) {
            ac = n4++;
            Main.e.a().a(graphics, bb, 6, n2, n3 + P[12].getHeight(), P[12].getWidth(), n, this.cR);
        }
        if (Main.a.d().x()) {
            Main.j.N[0].y = 0;
            --this.cR;
            if (this.cR < 0) {
                this.cR = 5;
            }
        } else if (Main.a.d().f()) {
            Main.j.N[0].y = 0;
            ++this.cR;
            if (this.cR > 5) {
                this.cR = 0;
            }
        } else if (Main.a.d().i()) {
            if (this.cR == 5) {
                this.b(14);
            } else {
                cX = this.cR;
                this.b(72);
            }
            ab = 0;
        } else if (Main.a.d().s()) {
            this.b(-1);
            this.i = 0L;
            ab = 0;
            this.cR = 0;
            Main.j.N[0].y = 0;
            ab = 0;
            this.cR = 0;
        }
        if (!Main.a.d().n()) {
            Main.a.d().a();
        }
    }

    public final void u(Graphics graphics) {
        boolean bl = false;
        boolean bl2 = false;
        Main.e.a().b(graphics, 20, 20, 150);
        Main.e.a().a(graphics, this.cV, 20, 35, P[12].getWidth(), 155, this.cR, true, 1);
        if (Main.a.d().x()) {
            --this.cR;
        } else if (Main.a.d().f()) {
            ++this.cR;
        } else if (Main.a.d().q()) {
            Main.j.i(0);
            Main.j.a();
            o.put("select", String.valueOf(this.cR));
            this.b(-1);
        }
        if (this.cR > this.cV.length - 1) {
            this.cR = 0;
        }
        if (this.cR < 0) {
            this.cR = this.cV.length - 1;
        }
        Main.a.d().a();
    }

    public final void b(String string, boolean bl) {
        bF = true;
        bU = true;
        di = string;
        this.bm = bl;
        cw = 0;
    }

    public final void v(Graphics graphics) {
        boolean bl = false;
        int n = this.dK - 0;
        int n2 = 0;
        int n3 = this.dJ - P[13].getHeight();
        Main.e.a().a(graphics, 0, n3, this.dK);
        n2 = P[13].getWidth() + 3;
        P[13].getHeight();
        boolean bl2 = false;
        int n4 = Main.g.a().a(this.dS, graphics, n -= n2 * 2, n2 + Main.k.w / 2 + 0, n3 += 8, 3217408, this.dP);
        ++W;
        if (n4 != 0 && Main.a.d().o()) {
            this.dP = n4 + 1;
            if (this.dP >= this.dS.length) {
                bj = false;
                this.b(-1);
                this.dP = 0;
                Main.b.a(0);
                ++Main.l.a;
            }
            Main.a.d().d = -99;
            Main.a.d().a();
        }
    }

    public final void w(Graphics graphics) {
        graphics.setClip(0, 0, t, s);
        boolean bl = false;
        int n = this.dK - 0;
        int n2 = 0;
        int n3 = this.dJ - P[13].getHeight();
        Main.e.a().a(graphics, 0, n3, this.dK);
        n2 = P[13].getWidth() + 3;
        P[13].getHeight();
        boolean bl2 = false;
        int n4 = Main.g.a().a(this.dS, graphics, n -= n2 * 2, n2 + Main.k.w / 2 + 0, n3 += 8, 3217408, this.dP);
        if (n4 != 0 && Main.a.d().o()) {
            this.dP = n4 + 1;
            if (this.dP >= this.dS.length) {
                bj = false;
                this.dP = 0;
                Main.b.a(0);
                ++Main.l.a;
            }
            Main.a.d().d = -99;
            Main.a.d().a();
        }
    }

    public final void f(String string, String string2) {
        this.dS = string2.toCharArray();
        String[] stringArray = new String[]{"playerface", "npc0face", "npc3face", "npc1face"};
        if (string.equals("-1")) {
            string = "aaa0";
        }
        String string3 = string.substring(0, string.length() - 1);
        dy = Integer.parseInt(string.substring(string.length() - 1, string.length()));
        int n = 0;
        while (n < stringArray.length) {
            if (stringArray[n].equals(string3)) {
                dx = n;
                break;
            }
            dx = -1;
            ++n;
        }
        if (dx != -1) {
            da = Main.j.a(stringArray[dx], 5);
            da.a(dy);
        }
    }

    public final void f(Graphics graphics, int n) {
        String string = "";
        switch (n) {
            case 0: {
                string = "111";
                break;
            }
            case 1: {
                string = "222";
                break;
            }
            case 2: {
                string = "333";
                break;
            }
            case 3: {
                string = "44";
                break;
            }
            case 4: {
                if (Main.e.h == 0) {
                    string = "555";
                    break;
                }
                if (Main.e.h != 1) break;
                string = "555aaaa";
                break;
            }
            case 5: {
                string = "\u5267\u60c5\u6536\u8d39";
                break;
            }
            case 6: {
                string = "\u662f\u5426\u539f\u5730\u590d\u6d3b";
                break;
            }
            case 7: {
                string = cy >= 10000 ? "\u8be5\u6cd5\u672f\u53ef\u7acb\u5373\u6d88\u706d\u602a" : "\u91d1\u94b1\u4e0d\u8db3\uff0c\u8be5\u6cd5\u672f\u81f3\u5c11\u898110000\u91d1\u94b1\u3002";
            }
        }
        if (Main.a.d().i() || Main.a.d().n()) {
            System.out.println("vvsd=" + n);
            switch (n) {
                case 0: {
                    bt = 2;
                    bU = true;
                    bF = true;
                    di = "\u8d2d\u4e70\u53cc\u500d\u7ecf\u9a8c\u6210\u529f";
                    break;
                }
                case 1: {
                    bK = 2;
                    bU = true;
                    bF = true;
                    di = "\u8d2d\u4e70\u53cc\u500d\u91d1\u94b1\u6210\u529f";
                    break;
                }
                case 2: {
                    int n2 = 0;
                    while (n2 < cY.length) {
                        Main.j.cY[n2].aD += 3;
                        this.a(cY[n2]);
                        this.n();
                        ++n2;
                    }
                    bU = true;
                    bF = true;
                    di = "\u8d2d\u4e70\u8fde\u5347\u4e09\u7ea7\u6210\u529f";
                    break;
                }
                case 3: {
                    cy += 500;
                    bU = true;
                    bF = true;
                    di = "\u8d2d\u4e70500\u91d1\u6210\u529f";
                    break;
                }
                case 4: {
                    int n3 = 0;
                    bU = true;
                    bF = true;
                    di = "\u8d2d\u4e70\u9752\u9f99\u6210\u529f";
                    this.av = Main.j.a("guai9", 2);
                    this.av.aD = 20;
                    this.g(this.av);
                    Main.j.ca[9] = 1;
                    this.av.ag = this.av.aE;
                    n3 = this.a(cY, this.av);
                    this.av.ax = this.av.aF;
                    if (n3 != 0) break;
                    di = di + "\u80cc\u5305\u5df2\u6ee1\u6682\u65f6\u5b58\u5230\u5546\u4eba\u4e2d";
                    n3 = this.a(cZ, this.av);
                    if (n3 != 0) break;
                    di = "\u5b58\u50a8\u5df2\u6ee1\uff01\u8bf7\u5148\u653e\u751f\u4ed9\u5ba0";
                    break;
                }
                case 5: {
                    o.put("sms", "1");
                    Main.b.a(0);
                    ++Main.l.a;
                    break;
                }
                case 6: {
                    int n4 = 0;
                    while (n4 < cY.length) {
                        Main.j.cY[n4].ag = Main.j.cY[n4].aE;
                        Main.j.cY[n4].an = false;
                        ++n4;
                    }
                    this.a(3);
                    this.cH = 3;
                    break;
                }
                case 7: {
                    if ((cx != 0 || cy < 10000) && cx != 1) break;
                    if (cx == 0) {
                        cy -= 10000;
                    }
                    bQ = true;
                    bv = false;
                    bQ = true;
                    Main.j.cY[Main.j.h[Main.j.e][0]].aa = 1;
                    this.a(cY[h[e][0]], this.av, 5);
                    this.ci = false;
                }
            }
            if (df == 2) {
                if (n == 5) {
                    this.b(-1);
                } else if (Main.l.b == 48) {
                    this.b(-1);
                } else {
                    this.b(71);
                }
            } else if (n == 7) {
                this.b(-1);
            } else {
                this.b(14);
            }
        } else if (Main.a.d().s()) {
            bF = true;
            bE = true;
            if (n == 5) {
                o.put("sms", "0");
                Main.b.a(0);
                ++Main.l.a;
                this.b(-1);
            } else if (n == 6) {
                o.put("isWin", "false");
                if (at == 0) {
                    o.put("fight_Value", "2");
                } else {
                    o.put("fight_Value", "4");
                }
                this.a(cY[h[e][0]], this.av, 8);
            } else if (df == 2) {
                this.b(71);
            } else if (n == 7) {
                this.b(-1);
            } else {
                this.b(14);
            }
        }
        Main.e.a().a(graphics, 10, 10, string);
        Main.j.b(graphics, P[10], 10, s - P[10].getHeight() - 10, 0, 0, P[10].getWidth() / 2, P[10].getHeight());
        Main.j.b(graphics, P[10], t - P[10].getWidth() / 2 - 10, s - P[10].getHeight() - 10, P[10].getWidth() / 2, 0, P[10].getWidth() / 2, P[10].getHeight());
    }

    public static final void z() {
        try {
            if (Main.c.a[0] != null) {
                Main.c.a[0].stop();
                Main.c.a[0].close();
                Main.c.a[0] = null;
            }
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public final void b(rf.e e2, rf.e e3) {
        int n = Math.abs(this.cJ.nextInt()) % 100;
        int n2 = e2.o;
        int n3 = e3.aB;
        int[] nArray = this.d(e2, e3);
        this.af = bQ ? this.av.ag : e2.ay * nArray[0] / nArray[1] * (this.cG + n2 * 3) / 10 - n3;
        if (this.af > e3.ag) {
            this.af = e3.ag;
        }
        if (this.af <= 0) {
            int n4;
            this.af = n4 = Math.abs(this.cJ.nextInt()) % 2 + 1;
        }
        if (n < e3.az / 8 && Main.j.M[0].aO != 3 && !bQ) {
            e3.ai = true;
        } else if (n <= e2.aA / 8 && !bQ) {
            this.af *= 2;
            e3.ag -= this.af;
            e3.am = true;
        } else {
            e3.am = false;
            e3.ag -= this.af;
        }
        this.a(e3);
        this.n();
    }

    public final void A() {
        if (bZ) {
            if (System.currentTimeMillis() - this.az > 1000L) {
                ++this.aA;
                this.az = System.currentTimeMillis();
            }
            if ((long)this.aA > this.ds) {
                this.a(0);
                cQ = "task100.pak";
                cN = "task100.pak";
                this.h();
                bZ = false;
            }
            if (o.containsKey("task_value") && o.get("task_value").equals("100")) {
                bZ = false;
            }
        }
    }

    public final void B() {
        if (Main.j.u[Main.j.q].T == 1) {
            this.a("player", "D", Main.j.u[Main.j.q].af, Main.j.u[Main.j.q].aR / this.dN + 1);
            return;
        }
        if (Main.j.u[Main.j.q].T == 2) {
            this.a("player", "U", Main.j.u[Main.j.q].af, Main.j.u[Main.j.q].aR / this.dN - 1);
            return;
        }
        if (Main.j.u[Main.j.q].T == 3) {
            this.a("player", "R", Main.j.u[Main.j.q].af / this.dO + 1, Main.j.u[Main.j.q].aR);
            return;
        }
        if (Main.j.u[Main.j.q].T == 4) {
            this.a("player", "L", Main.j.u[Main.j.q].af / this.dO - 1, Main.j.u[Main.j.q].aR);
        }
    }

    public final void a(rf.e e2, rf.e e3, int n, int n2) {
        int n3 = Math.abs(this.cJ.nextInt()) % 100;
        int n4 = 0;
        switch (n) {
            case 0: {
                e2.ag += e2.aE * 20 / 100;
                bI = true;
                di = "\u8865\u884020%";
                ad = e2.aE * 20 / 100;
                break;
            }
            case 1: {
                e2.ag += e2.aE * 40 / 100;
                bI = true;
                di = "\u8865\u884040%";
                ad = e2.aE * 40 / 100;
                break;
            }
            case 2: {
                e2.ag += e2.aE * 60 / 100;
                bI = true;
                di = "\u8865\u884060%";
                ad = e2.aE * 60 / 100;
                break;
            }
            case 3: {
                e2.ag += e2.aE * 80 / 100;
                bI = true;
                di = "\u8865\u884080%";
                ad = e2.aE * 80 / 100;
                break;
            }
            case 4: {
                e2.ax += e2.aF * 20 / 100;
                bI = true;
                di = "\u6cd5\u672f\u56de\u590d20%";
                ad = e2.aF * 20 / 100;
                break;
            }
            case 5: {
                e2.ax += e2.aF * 40 / 100;
                bI = true;
                di = "\u6cd5\u672f\u56de\u590d40%";
                ad = e2.aF * 40 / 100;
                break;
            }
            case 6: {
                e2.ax += e2.aF * 60 / 100;
                bI = true;
                di = "\u6cd5\u672f\u56de\u590d60%";
                ad = e2.aF * 60 / 100;
                break;
            }
            case 7: {
                e2.ax += e2.aF * 80 / 100;
                bI = true;
                di = "\u6cd5\u672f\u56de\u590d80%";
                ad = e2.aF * 80 / 100;
                break;
            }
            case 8: {
                e2.an = false;
                e2.ag = e2.aE * 20 / 100;
                bI = true;
                di = "\u590d\u6d3b\u6210\u529f\uff01\u5e76\u52a0\u884020%";
                ad = e2.aE * 20 / 100;
                break;
            }
            case 9: {
                e2.an = false;
                e2.ag = e2.aE * 40 / 100;
                bI = true;
                di = "\u590d\u6d3b\u6210\u529f\uff01\u5e76\u52a0\u884040%";
                ad = e2.aE * 40 / 100;
                break;
            }
            case 10: {
                e2.an = false;
                e2.ag = e2.aE * 60 / 100;
                bI = true;
                di = "\u590d\u6d3b\u6210\u529f\uff01\u5e76\u52a0\u884060%";
                ad = e2.aE * 60 / 100;
                break;
            }
            case 11: {
                e2.al = true;
                e2.aj = true;
                e2.ak = true;
                bF = true;
                bI = true;
                di = "\u9ebb\u75f9\u89e3\u9664";
                e2.Y = -1;
                dl = "";
                ad = 0;
                break;
            }
            case 12: {
                e2.aj = true;
                e2.V = "-1";
                bF = true;
                bI = true;
                di = "\u7981\u9522\u89e3\u9664";
                e2.Y = -1;
                this.f(e2);
                dl = "";
                ad = 0;
                break;
            }
            case 13: {
                bF = true;
                bI = true;
                di = "\u51b0\u51bb\u89e3\u9664";
                e2.Y = -1;
                this.f(e2);
                ad = 0;
                break;
            }
            case 14: {
                bF = true;
                bI = true;
                di = "\u71c3\u70e7\u89e3\u9664";
                e2.Y = -1;
                this.f(e2);
                ad = 0;
                break;
            }
            case 15: {
                e2.ar = false;
                e2.al = true;
                e2.aj = true;
                e2.ak = true;
                bF = true;
                bI = true;
                di = "\u77f3\u5316\u89e3\u9664";
                e2.Y = -1;
                this.f(e2);
                ad = 0;
                break;
            }
            case 16: {
                e2.ar = false;
                e2.al = true;
                e2.aj = true;
                e2.ak = true;
                e2.V = "-1";
                bF = true;
                bI = true;
                bF = true;
                di = "\u5f02\u5e38\u72b6\u6001\u5168\u89e3\u9664";
                e2.Y = -1;
                this.f(e2);
                ad = 0;
                break;
            }
            case 17: {
                boolean bl = false;
                n4 = (1400 - 1000 * (e3.ag / e3.aE + 1) + 980 - 20 * (e3.o + 2) * (e3.o + 2) - 20 * e3.aD) / 10;
                break;
            }
            case 18: {
                boolean bl = false;
                n4 = (1400 - 1000 * (e3.ag / e3.aE + 1) + 1280 - 20 * (e3.o + 2) * (e3.o + 2) - 20 * e3.aD) / 10;
                break;
            }
            case 19: {
                boolean bl = false;
                n4 = (1400 - 1000 * (e3.ag / e3.aE + 1) + 1620 - 20 * (e3.o + 2) * (e3.o + 2) - 20 * e3.aD) / 10;
                break;
            }
            case 20: {
                boolean bl = false;
                n4 = (1400 - 1000 * (e3.ag / e3.aE + 1) + 2000 - 20 * (e3.o + 2) * (e3.o + 2) - 20 * e3.aD) / 10;
                break;
            }
            case 21: {
                this.a(e2);
                bI = true;
                bF = true;
                if (e2.au != -1) {
                    di = "\u5378\u8f7d" + Main.k.E[e2.au][0] + "\u6210\u529f\uff01";
                    break;
                }
                di = "\u6ca1\u6709\u53ef\u5378\u8f7d\u7684\u6cd5\u5b9d";
                break;
            }
            case 22: {
                e2.aE += e2.aE * 5 / 100;
                ad = 0;
                break;
            }
            case 23: {
                e2.aE += e2.aE * 10 / 100;
                ad = 0;
                break;
            }
            case 24: {
                e2.aF += e2.aF * 5 / 100;
                ad = 0;
                break;
            }
            case 25: {
                e2.aF += e2.aF * 10 / 100;
                ad = 0;
                break;
            }
            case 26: {
                e2.aw = 40;
                ad = 0;
                break;
            }
            case 27: {
                e2.aw = 60;
                ad = 0;
                break;
            }
            case 28: {
                e2.ay += 5;
                ad = 0;
                break;
            }
            case 29: {
                e2.ay += 10;
                ad = 0;
                break;
            }
            case 30: {
                e2.aA += 5;
                ad = 0;
                break;
            }
            case 31: {
                e2.aA += 10;
                ad = 0;
                break;
            }
            case 32: {
                e2.aB += 5;
                ad = 0;
                break;
            }
            case 33: {
                e2.aB += 10;
                ad = 0;
                break;
            }
            case 34: {
                e2.az += 5;
                ad = 0;
                break;
            }
            case 35: {
                e2.az += 10;
                ad = 0;
                break;
            }
            case 36: {
                e2.aG += 5;
                ad = 0;
                break;
            }
            case 37: {
                e2.aG += 10;
                ad = 0;
                break;
            }
            case 38: {
                e2.av += e2.av * 20 / 100;
                ad = 0;
                break;
            }
            case 39: {
                e2.av += e2.av * 30 / 100;
                ad = 0;
            }
        }
        if (n >= 22) {
            bI = true;
            bF = true;
            di = "\u88c5\u5907" + Main.k.E[n][0] + "\u6cd5\u5b9d\u6210\u529f\uff01";
        }
        if (e2.aE > 999) {
            e2.aE = 999;
        }
        if (e2.aF > 999) {
            e2.aF = 999;
        }
        if (e2.ay > 99) {
            e2.ay = 99;
        }
        if (e2.aA > 99) {
            e2.aA = 99;
        }
        if (e2.aB > 99) {
            e2.aB = 99;
        }
        if (e2.az > 99) {
            e2.az = 99;
        }
        if (e2.aG > 99) {
            e2.aG = 99;
        }
        if (e2.ag > e2.aE) {
            e2.ag = e2.aE;
        }
        if (e2.ax > e2.aF) {
            e2.ax = e2.aF;
        }
        if (n == 17 || n == 18 || n == 19 || n == 20) {
            if (e3.V.equals("125/100")) {
                n4 = n4 * 125 / 100;
            }
            if (n4 < 0) {
                n4 = 0;
            } else if (n4 > 100) {
                n4 = 100;
            }
            if (n3 < n4 && !this.ci) {
                int n5 = 0;
                di = e3.aH + "\u6293\u53d6\u6210\u529f\uff01";
                n5 = this.a(cY, e3);
                if (n5 == 0) {
                    di = e3.aH + "\u6293\u53d6\u6210\u529f\uff01\u80cc\u5305\u5df2\u6ee1\u6682\u65f6\u5b58\u5230\u5546\u4eba\u4e2d";
                    n5 = this.a(cZ, e3);
                    if (n5 == 0) {
                        di = "\u5b58\u50a8\u5df2\u6ee1\uff01\u8bf7\u5148\u653e\u751f\u4ed9\u5ba0";
                    }
                }
                this.bq = true;
                aC = null;
                bI = true;
                bF = true;
            } else {
                bI = true;
                bF = true;
                this.bq = false;
                di = e3.aH + "\u6293\u53d6\u5931\u8d25\uff01";
            }
        }
        d d2 = null;
        int n6 = 0;
        while (n6 < dB.size()) {
            d2 = (d)dB.elementAt(n6);
            if (d2.b == n && d2.a > 0) {
                --d2.a;
                if (d2.a <= 0) {
                    dB.removeElementAt(n6);
                }
            }
            ++n6;
        }
        i i2 = null;
        int n7 = 0;
        while (n7 < dC.size()) {
            i2 = (i)dC.elementAt(n7);
            if (n == 21) {
                if (e2.au != -1) {
                    if (i2.b == e2.au) {
                        ++i2.a;
                        e2.au = -1;
                        break;
                    }
                    if (n7 == dC.size() - 1) {
                        i2 = new i(e2.au, 1);
                        dC.addElement(i2);
                        e2.au = -1;
                        break;
                    }
                }
            } else if (i2.b == n && i2.a > 0) {
                --i2.a;
                if (i2.a <= 0) {
                    dC.removeElementAt(n7);
                }
                e2.au = n;
                break;
            }
            ++n7;
        }
        this.a(e2);
        this.a(null, null, 9);
    }

    public final void c(rf.e e2, rf.e e3) {
        int n;
        int n2 = 0;
        if (e3.aD >= 0 && e3.aD <= 20) {
            n2 = 0;
        } else if (e3.aD >= 21 && e3.aD <= 40) {
            n2 = 1;
        } else if (e3.aD >= 41 && e3.aD <= 50) {
            n2 = 2;
        } else if (e3.aD >= 51 && e3.aD <= 70) {
            n2 = 3;
        } else if (e3.aD >= 71 && e3.aD <= 90) {
            n2 = 4;
        } else if (e3.aD >= 91 && e3.aD <= 99) {
            n2 = 5;
        }
        Main.j.ca[e3.ae] = 1;
        int n3 = 0;
        while (n3 < cY.length) {
            n = 0;
            while (n < h.length) {
                if (h[n][0] == n3) {
                    Main.j.cY[Main.j.h[n][0]].Q = (4 * e3.o - 1) * e3.aD + 17;
                    if (Main.j.cY[Main.j.h[n][0]].Q == 0) {
                        Main.j.cY[Main.j.h[n][0]].Q = 1;
                    }
                    Main.j.cY[Main.j.h[n][0]].Z += Main.j.cY[Main.j.h[n][0]].Q * bt;
                    if (Main.j.cY[Main.j.h[n][0]].Z < Main.j.cY[Main.j.h[n][0]].aC && bQ) {
                        Main.j.cY[Main.j.h[n][0]].Z = Main.j.cY[Main.j.h[n][0]].aC + 10;
                    }
                    while (Main.j.cY[Main.j.h[n][0]].Z >= Main.j.cY[Main.j.h[n][0]].aC) {
                        Main.j.cY[Main.j.h[n][0]].aq = true;
                        ++Main.j.cY[Main.j.h[n][0]].aD;
                        Main.j.cY[Main.j.h[n][0]].Z -= Main.j.cY[Main.j.h[n][0]].aC;
                        this.a(cY[h[n][0]]);
                        Main.j.cY[Main.j.h[n][0]].ag = Main.j.cY[Main.j.h[n][0]].aE;
                        Main.j.cY[Main.j.h[n][0]].ax = Main.j.cY[Main.j.h[n][0]].aF;
                        Main.j.cY[Main.j.h[n][0]].an = false;
                        this.n();
                    }
                    break;
                }
                if (n == h.length - 1 && Main.j.cY[n3].aw != 0) {
                    Main.j.cY[n3].Q = (4 * e3.o - 1) * e3.aD + 17;
                    if (Main.j.cY[n3].aw != 0) {
                        Main.j.cY[n3].Q = Main.j.cY[n3].Q * Main.j.cY[n3].aw / 100;
                    }
                    if (Main.j.cY[Main.j.h[n][0]].Q == 0) {
                        Main.j.cY[Main.j.h[n][0]].Q = 1;
                    }
                    Main.j.cY[n3].Z += Main.j.cY[n3].Q * bt;
                    while (Main.j.cY[n3].Z >= Main.j.cY[n3].aC) {
                        Main.j.cY[n3].aq = true;
                        ++Main.j.cY[n3].aD;
                        Main.j.cY[n3].Z -= Main.j.cY[n3].aC;
                        this.a(cY[n3]);
                        this.n();
                    }
                }
                ++n;
            }
            ++n3;
        }
        n = 0;
        while (n < 50) {
            if (e3.t.equals("guai" + n)) {
                byte by = Main.k.x[n][n2];
                this.ae = Main.k.y[n][n2];
                cy += this.ae * bK;
                this.d(by);
                return;
            }
            ++n;
        }
    }

    final int[] d(rf.e e2, rf.e e3) {
        int n = e2.n;
        int n2 = e3.n;
        int[] nArray = new int[2];
        int[] nArray2 = nArray;
        nArray[0] = Main.k.K[n2][n * 2] * 100;
        nArray2[1] = Main.k.K[n2][n * 2 + 1] * 100;
        return nArray2;
    }
}

