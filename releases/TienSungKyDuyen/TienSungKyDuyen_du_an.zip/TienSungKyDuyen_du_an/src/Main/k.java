/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Font
 */
package Main;

import java.util.Random;
import javax.microedition.lcdui.Font;

public interface k {
    public static final int v;
    public static final int w;
    public static final byte[][] x;
    public static final short[][] y;
    public static final String[][] z;
    public static final byte[][] A;
    public static final String[] B;
    public static final String[] C;
    public static final Font D;
    public static final String[][] E;
    public static final String[][] F;
    public static final String[] G;
    public static final String[] H;
    public static final String[][] I;
    public static final String[][] J;
    public static final byte[][] K;

    static {
        D = Font.getFont((int)0, (int)0, (int)8);
        w = D.stringWidth("\u989d");
        v = D.getHeight();
        String[] stringArray = new String[]{"player", "kulou", "boss"};
        C = new String[]{"ui_corner", "ui_choiser", "ui_uititle", "ui_playerface", "ui_shuxing1", "ui_shuxing2", "ui_blood", "ui_num1", "ui_num2", "ui_gang", "ui_yesno", "ui_corner2", "ui_zhou_w", "ui_zhou_h", "ui_zhou_bian", "ui_system", "ui_life", "ui_lifeword", "ui_corner3", "number1", "ball", "ui_money", "ui_jt", "ui_pro", "ui_system2"};
        new Random();
        B = new String[]{"putong_gj", "tx_chuxian", "tx_huifu", "tx_ke", "tx_qu", "tx_men", "tx_zhuaguai", "tx_jin_die", "tx_jin_jf", "tx_jin_ld", "tx_mu_die", "tx_mu_dw", "tx_mu_tt", "tx_shui_bc", "tx_shui_bz", "tx_shui_sw", "tx_huo_die", "tx_huo_fs", "tx_huo_mb", "tx_tu_die", "tx_tu_ls", "tx_tu_pp", "paopao0", "paopao1", "paopao2", "paopao3", "paopao4", "paopao5", "paopao6", "paopao7", "start", "paopao8"};
        A = new byte[50][8];
        z = new String[50][3];
        x = new byte[50][6];
        E = new String[40][4];
        I = new String[20][3];
        J = new String[30][3];
        y = new short[50][6];
        K = new byte[][]{{1, 1, 1, 2, 1, 1, 3, 2, 1, 1}, {3, 2, 1, 1, 1, 1, 1, 1, 1, 2}, {1, 1, 1, 1, 1, 1, 1, 2, 3, 2}, {1, 2, 1, 1, 3, 2, 1, 1, 1, 1}, {1, 1, 3, 2, 1, 2, 1, 1, 1, 1}};
        F = new String[25][9];
        G = new String[]{"\u63090\u952e\u53ef\u4ee5\u5207\u6362\u5df2\u62e5\u6709\u7684\u5404\u79cd\u9a91\u5ba0", "\u4ed9\u5ba0\u4e2d\u80fd\u529b\u6700\u5f3a\u8005\u975e\u9752\u9f99\u83ab\u5c5e\uff0c\u5176\u8fd8\u80fd\u817e\u4e91\u9a7e\u96fe\uff0c\u5230\u8fbe\u4efb\u4f55\u4e00\u5904\u5730\u65b9", "\u6cd5\u5b9d\u529f\u80fd\u5f3a\u5927\uff0c\u53ef\u4ee4\u5347\u7ea7\u548c\u6218\u6597\u53d8\u5f97\u66f4\u52a0\u5bb9\u6613", "\u53ef\u5728\u201c\u4ed9\u5ba0\u5927\u5168\u201d\u91cc\u67e5\u770b\u5f53\u524d\u5df2\u9047\u8fc7\u7684\u6240\u6709\u4ed9\u5ba0", "\u795e\u517d\u90a3\u91cc\u6700\u591a\u53ef\u5bc4\u5b58\u4e94\u5341\u53ea\u4ed9\u5ba0\uff0c\u518d\u591a\u4e86\u7684\u8bdd\u5c31\u53ea\u6709\u653e\u751f\u4e86", "\u6e38\u620f\u4e2d\u9690\u85cf\u8981\u7d20\u4f17\u591a\uff0c\u9700\u8981\u4ed4\u7ec6\u5bfb\u627e", "\u5927\u87f9\u53ef\u4ee5\u8f7d\u4eba\u4e0b\u6c34", "\u706b\u9f20\u53ef\u4ee5\u8f7d\u4eba\u8df3\u4e0a\u9ad8\u53f0\uff0c\u6216\u8005\u8df3\u5165\u5ca9\u6d46", "\u706b\u9f20\u53ef\u4ee5\u8f7d\u4eba\u8df3\u4e0a\u9ad8\u53f0\uff0c\u6216\u8005\u8df3\u5165\u5ca9\u6d46"};
        H = new String[]{"\u91d1\u514b\u6728\uff0c\u6728\u514b\u571f\uff0c\u571f\u514b\u6c34\uff0c\u6c34\u514b\u706b\uff0c\u706b\u514b\u91d1", "\u4ed9\u5ba0\u5206\u4e3a\u201c\u7532\u201d\u3001\u201c\u4e59\u201d\u3001\u201c\u4e19\u201d\u3001\u201c\u4e01\u201d\u56db\u4e2a\u6863\u6b21\uff0c\u5176\u4e2d\u201c\u4e01\u201d\u7ea7\u6700\u6b21\uff0c\u201c\u7532\u201d\u7ea7\u6700\u4f18", "\u5f02\u5e38\u72b6\u6001\u6700\u5c11\u6301\u7eed\u4e24\u56de\u5408\uff0c\u6700\u591a\u6301\u7eed\u516b\u56de\u5408", "\u6218\u6597\u4e2d\u4ed9\u5ba0\u751f\u547d\u4e3a\u96f6\u5c31\u6fd2\u6b7b\u4e0d\u80fd\u518d\u6218\u6597\u4e86\uff0c\u4f46\u5176\u5728\u6218\u6597\u7ed3\u675f\u540e\u4f1a\u81ea\u52a8\u590d\u6d3b", "\u53ef\u4ee5\u5bf9\u6218\u6597\u4e2d\u6fd2\u6b7b\u7684\u4ed9\u5ba0\u4f7f\u7528\u7075\u829d\uff0c\u4f7f\u5176\u590d\u6d3b\u540e\u7ee7\u7eed\u6218\u6597"};
    }
}

