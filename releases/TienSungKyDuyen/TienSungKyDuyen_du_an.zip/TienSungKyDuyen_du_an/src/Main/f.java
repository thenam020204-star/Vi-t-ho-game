/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Canvas
 *  javax.microedition.lcdui.Display
 *  javax.microedition.lcdui.Displayable
 *  javax.microedition.lcdui.Font
 *  javax.microedition.lcdui.Graphics
 *  javax.microedition.lcdui.Image
 *  javax.microedition.media.Manager
 *  javax.microedition.media.Player
 *  javax.microedition.media.control.VolumeControl
 *  javax.microedition.midlet.MIDlet
 */
package Main;

import Main.GameMidlet;
import Main.a;
import Main.j;
import java.io.InputStream;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.media.Manager;
import javax.microedition.media.Player;
import javax.microedition.media.control.VolumeControl;
import javax.microedition.midlet.MIDlet;
import rf.b;

public final class f
extends Canvas
implements Runnable {
    public static Font a;
    static int b;
    static int c;
    int d;
    Displayable e;
    Image f = null;
    public static boolean g;
    Image h;
    int[] i;
    int[] j;
    public static int k;
    boolean l;
    long m = 0L;
    int n = -6;
    Image[] o;
    int[][] p;
    Player q;
    int r = -7;
    int s;
    int t;
    private volatile Thread C;
    public static boolean u;
    public static boolean v;
    public static boolean w;
    public static int x;
    MIDlet y;
    Image z = null;
    Image A = null;
    int[] B = new int[]{35, 88, 140};

    static {
        g = false;
        v = true;
        u = true;
        w = true;
        x = 40;
        k = 0;
        a = Font.getFont((int)0, (int)0, (int)8);
        c = a.stringWidth("\u5979");
        b = a.getHeight() - 1;
    }

    public f(MIDlet mIDlet, Displayable displayable) {
        this.i = new int[]{16, 14, 5, 1, -3, -2, 2};
        int[] nArray = new int[]{16, 12, 2, -8, -12};
        this.j = new int[]{18, 15, -2, 0};
        this.p = new int[][]{{2, this.i[6], 0, this.i[6], 1, this.i[6], 500}, {2, this.i[2], 0, this.i[2], 1, this.i[2], x}, {2, this.i[1], 0, this.i[1], 1, this.i[1], x}, {2, this.i[0], 0, this.i[0], 1, this.i[0], x, 2}, {-1, this.j[0], -1, this.j[0], -1, this.j[0], x}, {-1, this.j[0], 5, this.j[0], -1, this.j[0], x}, {-1, this.j[0], 5, this.j[1], -1, this.j[0], x}, {-1, this.j[0], 5, this.j[2], -1, this.j[0], x}, {-1, this.j[0], 5, this.j[3], -1, this.j[0], x}, {-1, this.j[0], 5, this.j[0], -1, this.j[0], x}, {-1, this.j[0], 5, this.j[1], 5, this.j[0], x, 1}, {-1, this.j[0], 5, this.j[2], 5, this.j[1], x}, {5, this.j[0], 5, this.j[3], 5, this.j[2], x}, {5, this.j[1], 5, this.j[0], 5, this.j[3], x}, {5, this.j[2], 5, this.j[1], 5, this.j[0], x}, {5, this.j[3], 5, this.j[2], 5, this.j[1], x}, {5, this.j[0], 5, this.j[3], 5, this.j[2], x}, {5, this.j[1], 5, this.j[0], 5, this.j[3], x}, {5, this.j[2], 2, this.i[0], 5, this.j[0], x}, {5, this.j[3], 2, this.i[1], 5, this.j[1], x}, {5, this.j[0], 2, this.i[2], 5, this.j[2], x}, {5, this.j[1], 2, this.i[3], 5, this.j[3], x}, {5, this.j[2], 2, this.i[4], 5, this.j[0], x}, {5, this.j[3], 2, this.i[5], 5, this.j[1], x}, {3, this.i[0], 2, this.i[6], 5, this.j[2], x}, {3, this.i[1], 2, this.i[6], 5, this.j[3], x}, {3, this.i[2], 2, this.i[6], 5, this.j[0], x}, {3, this.i[3], 2, this.i[6], 5, this.j[1], x}, {3, this.i[4], 2, this.i[6], 5, this.j[2], x}, {3, this.i[5], 2, this.i[6], 5, this.j[3], x}, {4, this.i[0], 2, this.i[6], 3, this.i[6], x}, {4, this.i[1], 2, this.i[6], 3, this.i[6], x}, {4, this.i[2], 2, this.i[6], 3, this.i[6], x}, {4, this.i[6], 2, this.i[6], 3, this.i[6], 1000}};
        this.setFullScreenMode(true);
        this.y = mIDlet;
        this.e = displayable;
        Main.j.o();
        this.t = Main.a.p;
        this.s = Main.a.o;
        System.out.println("screenWidth=" + this.t);
        this.c();
        this.d();
        Display.getDisplay((MIDlet)this.y).setCurrent((Displayable)this);
        this.C = new Thread(this);
        this.C.start();
    }

    public final synchronized void a() {
        if (this.C != null) {
            this.C = null;
        }
    }

    public final void b() {
        this.h = null;
        this.f = null;
        this.o = null;
        this.z = null;
        this.A = null;
        this.q = null;
    }

    public final void a(Graphics graphics) {
        graphics.setColor(0);
        graphics.fillRect(0, 0, this.t, this.s);
        graphics.translate((this.t - this.f.getWidth()) / 2, (this.s - this.f.getHeight()) / 2);
        graphics.drawImage(this.f, 0, 0, 0);
        int n = 0;
        while (n < 3) {
            if (this.p[k][n * 2] != -1) {
                int n2 = this.B[n];
                if (this.p[k][n * 2] == 3) {
                    n2 = this.B[0];
                } else if (this.p[k][n * 2] == 4) {
                    n2 = this.B[2];
                }
                if (this.p[k][n * 2] == 5) {
                    int[] nArray = new int[]{0, -1, -1};
                    if (this.p[k][n * 2 + 1] == this.j[0]) {
                        graphics.drawImage(this.z, n2 + nArray[n], 73, 17);
                    } else if (this.p[k][n * 2 + 1] == this.j[1]) {
                        graphics.drawImage(this.o[this.p[k][n * 2]], n2, 100, 3);
                    } else if (this.p[k][n * 2 + 1] == this.j[2]) {
                        graphics.drawImage(this.A, n2 + nArray[n], 72, 17);
                    }
                } else {
                    graphics.drawImage(this.o[this.p[k][n * 2]], n2, this.p[k][n * 2 + 1] + 100, 3);
                }
            }
            ++n;
        }
    }

    public static final void a(Graphics graphics, String string, int n, int n2, int n3, int n4, int n5) {
        graphics.setFont(Font.getFont((int)64, (int)0, (int)8));
        if (n3 == n4) {
            graphics.setColor(n3);
            graphics.drawString(string, n, n2, n5);
            return;
        }
        graphics.setColor(n3);
        graphics.drawString(string, n + 1, n2, n5);
        graphics.drawString(string, n - 1, n2, n5);
        graphics.drawString(string, n, n2 + 1, n5);
        graphics.drawString(string, n, n2 - 1, n5);
        graphics.drawString(string, n + 1, n2 + 1, n5);
        graphics.drawString(string, n - 1, n2 - 1, n5);
        graphics.drawString(string, n + 1, n2 - 1, n5);
        graphics.drawString(string, n - 1, n2 + 1, n5);
        graphics.setColor(n4);
        graphics.drawString(string, n, n2, n5);
    }

    public final void c() {
        try {
            w = true;
            this.h = Image.createImage((String)"/Image/menu.png");
            this.h = this.s < 320 ? rf.b.a(this.h, 115, 95) : rf.b.a(this.h, 140, 110);
            this.f = Image.createImage((String)"/Image/bg.png");
            this.o = new Image[6];
            int n = 0;
            while (n < 6) {
                this.o[n] = Image.createImage((String)("/Image/logo" + n + ".png"));
                ++n;
            }
            this.z = Image.createImage((String)"/Image/logo51.png");
            this.A = Image.createImage((String)"/Image/logo52.png");
            return;
        }
        catch (Exception exception) {
            System.out.println("there is a error when init");
            return;
        }
    }

    public final void d() {
        try {
            this.q = Manager.createPlayer((InputStream)this.y.getClass().getResourceAsStream("/Image/xjoy.mid"), (String)"audio/midi");
            this.q.realize();
            VolumeControl volumeControl = (VolumeControl)this.q.getControl("VolumeControl");
            if (volumeControl != null) {
                volumeControl.setLevel(60);
            }
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public final boolean a(int n, int n2, int n3, int n4, int n5, int n6) {
        boolean bl = false;
        if (n >= n3 && n2 >= n4 && n <= n3 + n5 && n2 <= n4 + n6) {
            bl = true;
        }
        return bl;
    }

    public final void a(int n, int n2) {
        if (this.a(n, n2, Main.a.u[0][0], Main.a.u[0][1], Main.a.u[0][2], Main.a.u[0][3])) {
            this.d = -6;
            return;
        }
        if (this.a(n, n2, Main.a.u[1][0], Main.a.u[1][1], Main.a.u[1][2], Main.a.u[1][3])) {
            this.d = -7;
            return;
        }
        if (this.a(n, n2, Main.a.u[2][0], Main.a.u[2][1], Main.a.u[2][2], Main.a.u[2][3])) {
            this.d = -1;
            return;
        }
        if (this.a(n, n2, Main.a.u[3][0], Main.a.u[3][1], Main.a.u[3][2], Main.a.u[3][3])) {
            this.d = -2;
            return;
        }
        if (this.a(n, n2, Main.a.u[4][0], Main.a.u[4][1], Main.a.u[4][2], Main.a.u[4][3])) {
            this.d = -3;
            return;
        }
        if (this.a(n, n2, Main.a.u[5][0], Main.a.u[5][1], Main.a.u[5][2], Main.a.u[5][3])) {
            this.d = -4;
            return;
        }
        if (this.a(n, n2, Main.a.u[6][0], Main.a.u[6][1], Main.a.u[6][2], Main.a.u[6][3])) {
            this.d = 53;
            return;
        }
        if (this.a(n, n2, Main.a.u[7][0], Main.a.u[7][1], Main.a.u[7][2], Main.a.u[7][3])) {
            this.d = 48;
        }
    }

    public final void keyPressed(int n) {
        this.d = n;
        if (w) {
            if (n == this.n || n == -21 || n == 21) {
                g = true;
                v = true;
                w = false;
                Main.j.bY = true;
                return;
            }
            if (n == this.r || n == -22 || n == 22) {
                g = false;
                v = true;
                w = false;
                Main.j.bY = false;
            }
        }
    }

    public final void keyReleased(int n) {
    }

    public final void paint(Graphics graphics) {
        if (Main.j.p == 2) {
            if (this.b(graphics)) {
                return;
            }
            graphics.translate(200, 20);
        }
        graphics.setClip(0, 0, this.t, this.s + 20);
        if (u) {
            graphics.setColor(0);
            graphics.fillRect(0, 0, this.t, this.s);
            if (this.s < 320) {
                graphics.drawImage(this.h, this.t / 2, this.s / 2 - 40, 3);
            } else {
                graphics.drawImage(this.h, this.t / 2, this.s / 2 - 40, 3);
            }
        } else if (w) {
            graphics.setColor(0);
            graphics.fillRect(0, 0, this.t, this.s);
            if (this.s < 320) {
                graphics.drawImage(this.h, this.t / 2, this.s / 2 - 40, 3);
            } else {
                graphics.drawImage(this.h, this.t / 2, this.s / 2 - 40, 3);
            }
            graphics.setColor(0xFFFFFF);
            int n = this.t / 2 - a.stringWidth("\u662f\u5426\u5f00\u542f\u97f3\u4e50") / 2;
            int n2 = this.s - b * 2 - 10;
            Main.f.a(graphics, "\u662f\u5426\u5f00\u542f\u97f3\u4e50", n, n2, 0, 0xFFFFFF, 0);
            graphics.drawImage(this.o[2], this.t / 2 - this.o[2].getWidth() / 2, n2 - b * 2 - this.o[2].getHeight() + 15, 0);
            graphics.setColor(4355720);
            graphics.drawLine(0, n2 += b + 4, this.t, n2);
            graphics.drawLine(0, n2 + 1, this.t, n2 + 1);
            Main.f.a(graphics, "\u662f", 1, this.s - b, 0, 0xFFFFFF, 0);
            Main.f.a(graphics, "\u5426", this.t - c, this.s - b, 0, 0xFFFFFF, 0);
        } else if (v) {
            this.a(graphics);
            graphics.translate(-(this.t - this.f.getHeight()) / 2, -(this.s - this.f.getHeight()) / 2);
            return;
        }
        if (Main.j.p == 2) {
            graphics.translate(-200, -20);
            graphics.setClip(0, 0, 640, 360);
            graphics.drawImage(Main.j.aR, 0, 0, 0);
        }
    }

    public final void e() {
        try {
            if (g) {
                if (this.q != null) {
                    this.q.start();
                }
            } else {
                this.q.close();
                this.q = null;
            }
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    protected final void pointerPressed(int n, int n2) {
        if (Main.j.p == 2) {
            this.a(n, n2);
        }
        if (w) {
            if (this.d == this.n || this.d == -21 || this.d == 21) {
                g = true;
                v = true;
                w = false;
                Main.j.bY = true;
                return;
            }
            if (this.d == this.r || this.d == -22 || this.d == 22) {
                g = false;
                v = true;
                w = false;
                Main.j.bY = false;
            }
        }
    }

    protected final void pointerReleased(int n, int n2) {
        this.d = 0;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public final void run() {
        try {
            if (u) {
                this.repaint();
                this.serviceRepaints();
                Thread.sleep(2000L);
                u = false;
            }
            while (w) {
                this.repaint();
                this.serviceRepaints();
                Thread.sleep(200L);
            }
            while (v) {
                if (k == 0) {
                    this.e();
                }
                this.repaint();
                Thread.sleep(this.p[k][6]);
                ++k;
                if (this.m == 0L) {
                    this.m = System.currentTimeMillis();
                } else {
                    long l2 = System.currentTimeMillis() - this.m;
                    if (l2 < (long)x) {
                        Thread.sleep((long)x - l2);
                    }
                    this.m = System.currentTimeMillis();
                }
                if (k < this.p.length) continue;
                v = false;
            }
            return;
        }
        catch (Exception exception) {
            return;
        }
        finally {
            this.a();
            if (this.e != null) {
                Display.getDisplay((MIDlet)this.y).setCurrent(this.e);
                Main.a.d().a(2);
                new Thread(GameMidlet.b).start();
                this.b();
            }
        }
    }

    public final boolean b(Graphics graphics) {
        if (this.l || this.getWidth() == 360) {
            graphics.setClip(0, 0, 640, 640);
            graphics.setColor(0);
            graphics.fillRect(0, 0, 640, 640);
            graphics.setColor(0xFFFFFF);
            graphics.drawString("\u8be5\u6e38\u620f\u4e0d\u652f\u6301\u7ad6\u5c4f", 180, 320, 17);
            return true;
        }
        return false;
    }

    protected final void sizeChanged(int n, int n2) {
        this.l = n < n2;
        this.repaint();
        if (Main.j.p != 3) {
            this.serviceRepaints();
        }
    }
}

