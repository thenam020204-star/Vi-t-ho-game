/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Canvas
 *  javax.microedition.lcdui.Graphics
 */
package Main;

import Main.GameMidlet;
import Main.b;
import Main.j;
import Main.k;
import Main.l;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;

public final class a
extends Canvas
implements k {
    public static int a;
    int b;
    int c;
    int d;
    int e;
    protected int f = -2;
    protected int g = -6;
    protected int h = -3;
    protected int i = -5;
    protected int j = -4;
    protected int k = -7;
    protected int l = -1;
    public static a m;
    public j n;
    public static int o;
    public static int p;
    public boolean q = true;
    boolean r = true;
    boolean s = false;
    boolean t;
    public static short[][] u;

    static {
        u = new short[][]{{113, 325, 74, 31}, {453, 324, 74, 31}, {75, 60, 55, 70}, {74, 200, 55, 70}, {5, 150, 66, 41}, {130, 149, 66, 41}, {548, 110, 52, 59}, {481, 175, 52, 59}};
    }

    public a() {
        this.setFullScreenMode(true);
        p = 240;
        o = 320;
        if (p <= 176) {
            Main.j.cA = "k1.p";
            return;
        }
        Main.j.cA = "k1.p";
    }

    public final void a(int n) {
        switch (n) {
            case 2: {
                this.n = new j();
                Main.j.cI = GameMidlet.i ? 13 : 10;
            }
        }
        this.n.m();
    }

    public final void a() {
        a = -99;
        this.b = -99;
    }

    public final void a(int n, Graphics graphics) {
        graphics.setColor(n);
        graphics.setClip(0, 0, p, o);
        graphics.fillRect(0, 0, p, o);
    }

    protected final void b() {
        this.repaint();
    }

    protected final void c() {
        this.serviceRepaints();
    }

    public static final a d() {
        if (m == null) {
            m = new a();
        }
        return m;
    }

    public final void hideNotify() {
        if (!GameMidlet.h) {
            this.a();
            if (!Main.j.bL) {
                Main.j.z();
                Main.j.bO = true;
            }
            return;
        }
        GameMidlet.h = false;
    }

    public final boolean e() {
        return a == this.f || a == 56 || a == 98;
    }

    public final boolean f() {
        return this.b == this.f || this.b == 56 || this.b == 98;
    }

    public final boolean g() {
        return this.c == this.f || this.c == 56 || this.c == 98;
    }

    public final boolean h() {
        return a == this.g;
    }

    public final boolean i() {
        return this.b == this.g;
    }

    public final boolean j() {
        return this.c == this.g;
    }

    public final boolean k() {
        return a == this.h || a == 52 || a == 102;
    }

    public final boolean l() {
        return this.b == this.h || this.b == 52 || this.b == 102;
    }

    public final boolean m() {
        return (Main.j.dp != 4 && !Main.j.bj && Main.l.h || Main.j.df == 8) && (a == this.i || a == 53 || a == 103);
    }

    public final boolean n() {
        return Main.j.dp != 4 && !Main.j.bj && Main.l.h && (this.b == this.i || this.b == 53 || this.b == 103);
    }

    public final boolean o() {
        return this.d == this.i || this.d == 53 || this.d == 103;
    }

    public final boolean p() {
        return a == 48 || a == 109;
    }

    public final boolean q() {
        return this.b == this.i || this.b == 53 || this.b == this.g || this.b == 103;
    }

    public final boolean r() {
        return a == this.k;
    }

    public final boolean s() {
        return this.b == this.k;
    }

    public final boolean t() {
        return this.c == this.k;
    }

    public final boolean u() {
        return a == this.j || a == 54 || a == 104;
    }

    public final boolean v() {
        return this.b == this.j || this.b == 54 || this.b == 104;
    }

    public final boolean w() {
        return a == this.l || a == 50 || a == 116;
    }

    public final boolean x() {
        return this.b == this.l || this.b == 50 || this.b == 116;
    }

    public final boolean y() {
        return this.c == this.l || this.c == 50 || this.c == 116;
    }

    public final boolean a(int n, int n2, int n3, int n4, int n5, int n6) {
        boolean bl = false;
        if (n >= n3 && n2 >= n4 && n <= n3 + n5 && n2 <= n4 + n6) {
            bl = true;
        }
        return bl;
    }

    public final void b(int n) {
        this.e = n;
        if (Main.l.h && Main.j.bI && n != this.i && n != 53 && n != 103) {
            Main.j.cw = 0;
            Main.j.bI = false;
        }
        if (Main.l.h && Main.j.bU && n != this.i && n != 53 && n != 103) {
            Main.j.cw = 0;
            Main.j.bU = false;
        }
        if (Main.j.bH) {
            Main.j.bH = false;
            if (Main.j.bj || Main.j.dp == 4) {
                this.d = n;
                return;
            }
            Main.j.cq = n;
            if (Main.j.cr != null && Main.j.cq != Integer.parseInt(Main.j.cr)) {
                Main.j.bI = true;
                Main.j.bF = true;
                Main.j.di = Main.j.dn;
                return;
            }
            this.c = n;
            if (this.q) {
                a = n;
            }
            if (this.r) {
                this.b = n;
            }
            if (n == this.i || n == 53 || n == 103) {
                a = n;
                this.b = n;
            }
            if (Main.b.a == 3 && Main.j.cr != null && this.r) {
                this.r = false;
            }
        }
    }

    public final void a(int n, int n2) {
        int n3 = 0;
        if (this.a(n, n2, u[0][0], u[0][1], u[0][2], u[0][3])) {
            n3 = -6;
        } else if (this.a(n, n2, u[1][0], u[1][1], u[1][2], u[1][3])) {
            n3 = -7;
        } else if (this.a(n, n2, u[2][0], u[2][1], u[2][2], u[2][3])) {
            n3 = -1;
        } else if (this.a(n, n2, u[3][0], u[3][1], u[3][2], u[3][3])) {
            n3 = -2;
        } else if (this.a(n, n2, u[4][0], u[4][1], u[4][2], u[4][3])) {
            n3 = -3;
        } else if (this.a(n, n2, u[5][0], u[5][1], u[5][2], u[5][3])) {
            n3 = -4;
        } else if (this.a(n, n2, u[6][0], u[6][1], u[6][2], u[6][3])) {
            n3 = 53;
        } else if (this.a(n, n2, u[7][0], u[7][1], u[7][2], u[7][3])) {
            n3 = 48;
        }
        this.b(n3);
    }

    protected final void keyPressed(int n) {
        this.e = n;
        if (Main.l.h && Main.j.bI && n != this.i && n != 53 && n != 103) {
            Main.j.cw = 0;
            Main.j.bI = false;
        }
        if (Main.l.h && Main.j.bU && n != this.i && n != 53 && n != 103) {
            Main.j.cw = 0;
            Main.j.bU = false;
        }
        if (Main.j.bH) {
            Main.j.bH = false;
            if (Main.j.bj || Main.j.dp == 4) {
                this.d = n;
                return;
            }
            Main.j.cq = n;
            if (Main.j.cr != null && Main.j.cq != Integer.parseInt(Main.j.cr)) {
                Main.j.bI = true;
                Main.j.bF = true;
                Main.j.di = Main.j.dn;
                return;
            }
            this.c = n;
            if (this.q) {
                a = n;
            }
            if (this.r) {
                this.b = n;
            }
            if (n == this.i || n == 53 || n == 103) {
                a = n;
                this.b = n;
            }
            if (Main.b.a == 3 && Main.j.cr != null && this.r) {
                this.r = false;
            }
        }
    }

    protected final void keyReleased(int n) {
        if (Main.j.cr == null) {
            this.a();
        }
    }

    protected final void paint(Graphics graphics) {
        try {
            Main.j.bH = false;
            graphics.setFont(Main.k.D);
            if (Main.j.p == 2) {
                if (this.a(graphics)) {
                    return;
                }
                graphics.translate(200, 20);
            }
            this.a(0, graphics);
            if (this.n != null) {
                this.n.s(graphics);
                if (Main.j.cr != null && Main.j.cq == Integer.parseInt(Main.j.cr)) {
                    Main.b.a(0);
                    ++Main.l.a;
                }
                this.n.u();
                if (Main.j.cr != null && Main.j.cq == Integer.parseInt(Main.j.cr)) {
                    if (Main.l.b != 51 || Main.j.df == 4 && !Main.j.bv) {
                        Main.j.cw = 0;
                        Main.j.bU = false;
                        Main.j.cw = 0;
                        Main.j.bI = false;
                        Main.j.cr = null;
                    }
                    this.a();
                    Main.j.cq = -99;
                }
                Main.j.bH = true;
            }
            if (Main.j.p == 2) {
                graphics.translate(-200, -20);
                graphics.setClip(0, 0, 640, 360);
                graphics.drawImage(Main.j.aR, 0, 0, 0);
            }
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.printStackTrace();
            return;
        }
    }

    protected final void pointerPressed(int n, int n2) {
        if (Main.j.p == 2) {
            this.a(n, n2);
        }
    }

    protected final void pointerReleased(int n, int n2) {
        if (Main.j.cr == null) {
            this.a();
        }
    }

    public final void showNotify() {
        if (!GameMidlet.h) {
            this.a();
            if (!Main.j.bL) {
                Main.j.z();
                Main.j.bO = true;
            }
            return;
        }
        GameMidlet.h = false;
    }

    public final boolean a(Graphics graphics) {
        if (this.t || this.getWidth() == 360) {
            graphics.setClip(0, 0, 640, 640);
            graphics.setColor(0);
            graphics.fillRect(0, 0, 640, 640);
            graphics.setColor(0xFFFFFF);
            graphics.drawString("\u8be5\u6e38\u620f\u4e0d\u652f\u6301\u7ad6\u5c4f", 180, 320, 17);
            return true;
        }
        return false;
    }

    protected final void sizeChanged(int n, int n2) {
        this.t = n < n2;
        this.b();
        if (Main.j.p != 3) {
            this.c();
        }
    }
}

