# -*- coding: utf-8 -*-
"""Kiem rieng cho f12 (them o T11-tool): python3 selftest_f12.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pixeltext as pt
from pixeltext import container
ok = 0
def T(c, w):
    global ok
    assert c, "FAIL: " + w
    ok += 1
T(12 in pt.SIZES and pt.FONTS[12] == 'f12.bin', "12 co trong SIZES/FONTS")
f = pt.Font.load(12)
T(f.height == 12 and len(f.chars) == 228, "f12: cao 12, 228 ky tu")
T(f.missing("Trò chơi mới Ấ Ẩ Ữ Đ đ ơ ư") == [], "f12 phu chu Viet")
raw = open(next(p for p in (os.path.join(d, pt.FONTS[12]) for d in pt.font.FONT_DIRS if d) if os.path.exists(p)), 'rb').read()
d = container.decode(raw)
T(container.encode(d['chars'], d['height'], d['widths'], d['rows']) == raw[:len(container.encode(d['chars'], d['height'], d['widths'], d['rows']))], "f12 round-trip byte-exact")
T(f.ambiguous_in("TRÒ ƯƠNG ẮẰẲẴ Il1|") == [], "f12: chu hoa co dau, I/l/1 phan biet")
T(pt.measure("Trò chơi mới", 12)['w'] > 0, "--size 12 measure")
print("selftest_f12: %d kiem tra OK" % ok)
