# Bản test 1: Mộng Hồi Tam Quốc K790 (Việt hoá)
- Máy: Sony Ericsson K790 / máy MIDP2 màn 240x320. Cài bằng .jar (hoặc .jad + .jar).
- Đã có: toàn bộ text (thoại, dẫn truyện, item, kỹ năng, nhiệm vụ, menu) tiếng Việt, font f13c;
  ngắt dòng theo từ, khung thoại 3 dòng; logo game mới; logo khởi động NAMP; 19 ảnh giao diện đã vẽ lại.
- jar_check: PASS (class 45.3, có StackMap, không có StackMapTable).
- Đã chạy thử trên FreeJ2ME: logo → menu → thoại mở đầu → trận đầu, không lỗi.

Đã biết, chưa sửa (sẽ làm ở bản cuối):
- Bộ đếm combo khi đánh còn chữ Hán "击" (ảnh số combo).
- Một số nhãn ảnh bị rút gọn vì ô nhỏ ("Thiết Cốt", "Hổ Oai", "N.vụ", "B.đồ"...).
- Tên kỹ năng "Huyết Chiến Bát Phương" có thể hơi tràn ô danh sách kỹ năng.
- Chưa đo heap trên máy thật: font chiếm ~63 KB mỗi màu chữ (tối đa 4 màu ≈ 252 KB).

Khi test xin ghi lại: màn nào lỗi / chữ tràn / chữ còn tiếng Trung / giật, kèm ảnh chụp nếu được.
