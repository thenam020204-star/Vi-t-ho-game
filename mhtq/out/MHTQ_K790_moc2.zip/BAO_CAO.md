# Mốc 2 (T06) - Mộng Hồi Tam Quốc K790 (240x320): bản dịch Việt + ngắt dòng/khung thoại

## Nội dung
- `MHTQ_K790_moc2.jar/.jad`: MIDlet-Name "Mong Hoi Tam Quoc" (ASCII), MIDlet-Jar-Size khớp. `jar_check` PASS (`jar_check_m2.txt`).
- `text_da_dich.tsv` (1425 dòng, cột dịch đã điền), `thuat-ngu.tsv`, `vai.md`.
- `anh/`: 21 ảnh FreeJ2ME 240x320 + `emu_*.log` (không có exception).
- Dựng lại: `bash mhtq/scripts/build_m2.sh` (t06_fill -> text_pack -> patch_font --overlay -> patch_wrap -> set_manifest -> preverify trong từng patch -> jar_check).

## Đã làm
- Font f13c qua BitmapFont (Mốc 1). Ngắt dòng theo dấu cách bằng ViWrap (k.b / j.a, cache 4 mục, chặn `#` cuối chuỗi); khung thoại 3 dòng/trang (m.a, ViTalk), bước dòng 15px (p.a).
- Dấu cách chuỗi ghép (v/w/m/p/n/b) thêm theo bảng PAD trong `t06_fill.py` (log `logs/t06_fill.txt`).
- `K.n07` (Huyết Chiến Bát Phương, 107px > hộp 101px): ảnh thử (`anh/12`) xác nhận chữ đè viền, nên theo quyết định quản đốc dùng "Huyết Chiến B.Phương" (97px, vừa hộp; xác nhận bằng ảnh thử). Ghi đè ở `OVERRIDE` trong `t06_fill.py`. Chuỗi gốc trong thoại/dẫn truyện không đổi.

## Ảnh chụp đã soát (không cắt giữa từ, không tràn/đè, không exception)
Hộp Có/Không (01), thoại 3 dòng và nhiều trang (03-05, 16), dẫn truyện cuộn (06-07), túi đồ + mô tả item (09-10), kỹ năng (11, 21), nhiệm vụ (13), toast "Nhận vũ khí" (15), hai khung trận đánh (17-18), tên người nói dài nhất "Diệp Vấn Thiên" 65px trong hộp 91px (14; Thủ vệ trưởng 64px, Gia Cát Lượng 62px đo bằng bề rộng glyph).
Ảnh 12 là jar THỬ (chỉ đổi K.n00 thành tên K.n07 rút gọn) để kiểm hộp kỹ năng; jar bàn giao có chuỗi này ở K.n07.

## Còn tiếng Hán (không phải text, là ảnh -> T07)
Logo/tiêu đề + nút "新游戏" ở menu chính (02), nhãn tab (装备/技能/任务/地图), tiêu đề "主动技能/被动技能/任务", trang thuộc tính (属性, 叶问天, 称号:小虾米, 生命/真气/经验, 攻击/防御/暴击/躲闪) đều là ảnh .xng/PNG.

## Màn KHÔNG dò đường vào được bằng phím (chưa chụp)
- Kết quả trận (v.class: "Nhận EXP/vàng", "Lên cấp", Tin cậy/Tình cảm), nhật ký chiến đấu m.class, cửa hàng/SMS/trả phí (l.class), màn đồng đội (tới "Chưa có đồng đội" thì trống), danh sách kỹ năng có K.n07 thật (chưa học).
- Trong trận thử, phím số 1-9 (KP/main) không điều khiển được qua xdotool; phải dùng con trỏ + Return mới đánh được.
- Tooltip mô tả item là dải cuộn ngang một dòng, đo không cắt giữa từ nhưng bị cắt ở mép khi cuộn (hành vi gốc).
- Các chuỗi đo rộng 4.6px/ký tự là ước lượng; text_pack chỉ cảnh báo khi đo thật vượt (hiện 0 cảnh báo).

## Heap
BitmapFont cache 63KB/màu, CACHE=4 (~252KB). ViWrap cache 4 mục. Xem BAO_CAO_M1.
